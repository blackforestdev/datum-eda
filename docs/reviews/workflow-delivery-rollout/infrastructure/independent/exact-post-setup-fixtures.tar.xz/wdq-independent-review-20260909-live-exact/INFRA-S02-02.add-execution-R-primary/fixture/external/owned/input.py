# Actual candidate change in an isolated synthetic lane.
