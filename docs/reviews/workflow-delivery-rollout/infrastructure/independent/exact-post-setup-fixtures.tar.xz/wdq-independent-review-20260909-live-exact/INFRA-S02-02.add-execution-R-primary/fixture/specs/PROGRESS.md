<!-- ACTIVE FRONTIER:START -->
> Generated from `specs/active_frontier.json` by `scripts/project_status.py`; do not hand-edit.

- **Accepted fixture** (`TASK`; `dat-test`).
   Synthetic accepted history *state `landed`; authorization `none`.*
   *Dependencies:* none. *Unblocks:* none. *Governing:* `docs/decisions/PRODUCT_MECHANICS_025_FIXTURE.md`.
- **Align project state** (`NEXT`; `dat-next`).
   Make every agent return the same next task. *state `in_progress`; authorization `execution`; **CANONICAL NEXT**.*
   *Dependencies:* none. *Unblocks:* none. *Governing:* `docs/decisions/PRODUCT_MECHANICS_025_FIXTURE.md`.
   *Completion plan:* `python3 scripts/project_status.py details`.
- **Align project state** (`COLD`; `dat-cold`).
   Make every agent return the same next task. *state `deferred`; authorization `none`.*
   *Dependencies:* none. *Unblocks:* none. *Governing:* `docs/decisions/PRODUCT_MECHANICS_025_FIXTURE.md`.
<!-- ACTIVE FRONTIER:END -->
