# Retained unowned synthetic input.
