"""Sequentially replay and verify the remaining authorized frozen-source batches."""
import json
from pathlib import Path
import subprocess
import time

STORE = Path(__file__).parent
ROOT = Path('/home/bfadmin/Documents/datum-eda')
batches = ['s02-coverage', 's03', 's04', 's05-snapshots', 's06-selection', 's06-headless', 's06-trust']
results = []
for batch in batches:
    for helper in ('run-exact-batch.py', 'verify-exact-batch.py'):
        argv = ['python3', '-I', '-S', '-B', str(STORE / helper), batch]
        started = time.time_ns()
        status = subprocess.run(argv, cwd=ROOT).returncode
        results.append({'batch': batch, 'argv': argv, 'started_ns': started,
                        'finished_ns': time.time_ns(), 'exit_code': status})
        if status:
            with (STORE / 'remaining-standard-failure.json').open('x') as f:
                json.dump(results, f, indent=2)
            raise SystemExit(status)
with (STORE / 'remaining-standard-processes.json').open('x') as f:
    json.dump(results, f, indent=2)
print('Remaining standard replay and verification complete.', flush=True)
