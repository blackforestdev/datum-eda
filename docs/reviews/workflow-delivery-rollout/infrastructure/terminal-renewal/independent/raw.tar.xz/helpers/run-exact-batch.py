"""Explicit pin adaptation of retained independent exact-input replay collector."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/home/bfadmin/Documents/datum-eda')
STORE = Path(__file__).parent
prior = ROOT / '.git/datum-wdq/proposals/independent-sequencing-20260910/run-exact-batch.py'
raw = prior.read_bytes()
code = raw.decode()
changes = {
    'sequencing-repair-20260910': 'terminal-owner-20260910',
    'sequencing-evidence-20260910': 'terminal-rollout-evidence-20260910',
    '1d48f249dc7071fc3718b345a4ab16b366af43be': '9924678c39fe5d176e58ebfd8e25ab6feb213f35',
}
for old, new in changes.items():
    assert old in code, old
    code = code.replace(old, new)
record = STORE / ('adapter-' + sys.argv[1] + '.json')
with record.open('x') as stream:
    json.dump({'template': str(prior), 'template_sha256': hashlib.sha256(raw).hexdigest(),
               'replacements': changes, 'executed_adapter_sha256': hashlib.sha256(code.encode()).hexdigest(),
               'scope': 'Actual source992 replay; final normative applicability is separate.'}, stream, indent=2)
    stream.write('\n')
exec(compile(code, str(prior), 'exec'), {'__name__': '__main__', '__file__': str(Path(__file__))})
