"""Retain actual construction/assessment process commands and terminal output."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

STORE = Path(__file__).parent
ROOT = Path('/home/bfadmin/Documents/datum-eda')
name = sys.argv[1]
assert Path(name).name == name
argv = sys.argv[2:]
assert argv and argv[0] == 'python3'
env = dict(os.environ)
if name == 'construction':
    env['DATUM_WDQ_ASSESSMENT_NAME'] = 'terminal-independent-construction-01'
    env.update(HOME=str(STORE), XDG_CONFIG_HOME=str(STORE), GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null', LANG='C')
def save(suffix, value):
    with (STORE / (name + '-' + suffix + '.json')).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
save('command', {'argv': argv, 'cwd': str(ROOT), 'selected_environment': {k:env.get(k) for k in ('DATUM_WDQ_ASSESSMENT_NAME','HOME','XDG_CONFIG_HOME','GIT_CONFIG_NOSYSTEM','GIT_CONFIG_GLOBAL','LANG','PATH')}})
with (STORE / (name + '-stdout.bin')).open('xb') as out, (STORE / (name + '-stderr.bin')).open('xb') as err:
    started = time.time_ns()
    p = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=out, stderr=err)
    save('started', {'pid':p.pid,'started_ns':started})
    print(json.dumps({'name':name,'pid':p.pid}), flush=True)
    status = p.wait()
save('process', {'pid':p.pid,'started_ns':started,'finished_ns':time.time_ns(),'exit_code':status,
    **{k+'_sha256':hashlib.sha256((STORE/(name+'-'+k+'.bin')).read_bytes()).hexdigest() for k in ('stdout','stderr')}})
print(json.dumps({'name':name,'exit_code':status}), flush=True)
raise SystemExit(status)
