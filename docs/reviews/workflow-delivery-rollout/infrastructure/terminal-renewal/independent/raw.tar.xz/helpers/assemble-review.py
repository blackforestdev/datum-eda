"""Assess actual independent executions against a pinned current producer packet."""
import argparse
import collections
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time

ROOT = Path('/home/bfadmin/Documents/datum-eda')
STORE = Path(__file__).parent
PROPOSALS = ROOT / '.git/datum-wdq/proposals'
RUNTIME = PROPOSALS / 'terminal-owner-20260910'
OBSERVED = '9924678c39fe5d176e58ebfd8e25ab6feb213f35'
FINAL = '0abb325d9f06e7c8e4ea7b36e3a7ea2d8cd6f45c'
SESSION = 'wdq-independent-review-20260906'
PREFIX = 'docs/reviews/workflow-delivery-rollout/infrastructure/terminal-renewal/'
TYPED = PREFIX + 'independent/'
J = lambda p: json.loads(p.read_bytes())
H = lambda raw: hashlib.sha256(raw).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', required=True)
    parser.add_argument('--packet', required=True)
    parser.add_argument('--construction', type=Path, required=True)
    parser.add_argument('--output-name', required=True)
    args = parser.parse_args()
    assert sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode
    assert Path(args.output_name).name == args.output_name
    output = STORE / args.output_name
    output.mkdir()
    started = time.time_ns()
    bootstrap = RUNTIME / 'scripts/workflow_delivery_source_only.py'
    raw = bootstrap.read_bytes()
    assert raw == subprocess.check_output(['git', '--no-replace-objects', 'show', FINAL + ':scripts/workflow_delivery_source_only.py'], cwd=ROOT)
    ns = {'__name__': '_independent_assessment_bootstrap'}
    exec(compile(raw, str(bootstrap), 'exec'), ns)
    ns['install'](bootstrap.parent)
    sys.path.insert(0, str(bootstrap.parent))
    from workflow_delivery_tree import Tree
    from workflow_delivery_io import canonical_json, DeliveryInputError
    from workflow_delivery_authority import authority_sha256
    from workflow_delivery_contract import contract_sha256
    from workflow_delivery_evidence_shapes import review_sha256
    from workflow_delivery_native import validate_correlations, validate_environment
    from workflow_delivery_proof import packet_sha256, validate_proof, read_blob
    from workflow_delivery_review import validate_independent_review, validate_defect_dispositions
    from workflow_delivery_trust import Trust
    base = Tree(ROOT, revision=args.candidate)
    contract = base.json('specs/workflow_delivery/rollout.contract.json')
    producer = validate_proof(base, contract)
    authority = authority_sha256(base, contract)
    assert packet_sha256(contract, producer, authority) == args.packet
    assert producer['source_commit'] == FINAL
    environment = json.loads(read_blob(base, producer['environment']))
    validate_environment(base, producer, environment, contract=contract)
    assert len(validate_correlations(base, contract, producer)) == 6
    class Overlay:
        staged = False
        def __getattr__(self, key): return getattr(base, key)
        def read(self, path, **kwargs):
            p = output / path
            return p.read_bytes() if p.is_file() else base.read(path, **kwargs)
        def json(self, path, **kwargs): return json.loads(self.read(path, **kwargs))
    tree = Overlay()
    def write(path, value):
        p = output / path
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open('xb') as f: f.write(canonical_json(value))
        return {'path': path, 'sha256': H(p.read_bytes())}
    raw_files = {}
    def retain(path, name):
        raw = path.read_bytes()
        assert name not in raw_files or raw_files[name] == raw
        raw_files[name] = raw
    rows = []
    def capture(path, metadata, expected_hash):
        result, invocation = J(path / 'result.json'), J(path / 'invocation.json')
        assert H((path / 'result.json').read_bytes()) == expected_hash
        assert result['invocation_id'] == invocation['invocation_id']
        assert not result['changed_files'] and not result['changed_state_fields']
        assert (path / 'before.json').read_bytes() == (path / 'after.json').read_bytes()
        assert result['pid'] == J(path / 'started.json')['pid']
        for artifact in result['artifacts']:
            assert H((path / artifact['path']).read_bytes()) == artifact['sha256']
        events = [json.loads(line) for line in (path / 'calls.jsonl').read_bytes().splitlines()] if (path / 'calls.jsonl').exists() else []
        selector = metadata['surface'].startswith('S-')
        source = 'scripts/workflow_delivery_selector.py' if selector else 'scripts/check_workflow_delivery.py'
        symbol = 'selector_failures' if selector else 'main'
        calls = [e for e in events if e.get('event') == 'call' and e.get('function') == symbol and Path(e['source']['path']).name == Path(source).name]
        assert len(calls) <= 1
        for e in calls: assert e['source']['sha256'] == H(base.read(source))
        for e in events:
            assert e['pid'] == result['pid']
            assert invocation['started_ns'] <= e['time_ns'] <= result['finished_ns']
        if not calls:
            assert metadata['surface'] == 'H' and result['returncode'] != 0
        archive_prefix = 'captures/' + str(len(rows)).zfill(4)
        for p in sorted(path.iterdir()):
            if p.is_file() and not p.is_symlink(): retain(p, archive_prefix + '/' + p.name)
        for name in ('input-identity.json', 'input-restore.json', 'before-input-restore.json', 'cleanup.json', metadata['surface'] + '-restoration-check.json'):
            p = path.parent / name
            if p.is_file(): retain(p, archive_prefix + '/setup-' + name)
        rows.append({**metadata, 'capture_path': str(path), 'archive_prefix': archive_prefix,
            'observed_source_commit': OBSERVED, 'assessment_source_commit': FINAL,
            'assessment_kind': 'current applicability of actual independent historical execution',
            'invocation_id': result['invocation_id'], 'result_sha256': expected_hash,
            'started_ns': invocation['started_ns'], 'finished_ns': result['finished_ns'], 'pid': result['pid'],
            'observer_event_ids': [e['event_id'] for e in events],
            'observer_invocation_ids': sorted({e['invocation_id'] for e in events}),
            'consumer': 'selector' if selector else 'validator', 'handler_ref': {'path': source, 'symbol': symbol},
            'handler_invoked': bool(calls), 'returncode': result['returncode'], 'result_kind': result['kind'],
            'unavailable_reason': None if calls else (path / 'stderr.bin').read_text().strip()})
    fields = ('case_id', 'captured_case_id', 'surface', 'phase')
    summary = J(STORE / 'raw-replay-complete.json')
    assert summary['observations'] == 1290 and summary['executed_source'] == OBSERVED
    for batch in summary['batches']:
        name = batch['batch']
        folder = STORE / (name + '-exact' if name.startswith('workspace-') else name)
        for saved in J(folder / 'observations.json')['observations']:
            if name.startswith('workspace-'):
                path = folder / saved['directory'] / 'capture'
                metadata = {'case_id': 'INFRA-S05-WORKSPACE-' + saved['case'],
                    'captured_case_id': J(path / 'invocation.json')['case_id'],
                    'surface': {'S': 'S-check', 'D': 'S-details'}.get(saved['surface'], saved['surface']), 'phase': 'compatibility'}
                assert saved['exact_before_state_equal']
            else:
                path = folder / saved['directory'] / 'capture'
                metadata = {k: saved[k] for k in fields}
                assert saved['exact_post_setup_input_identity']
            capture(path, metadata, saved['result_sha256'])
        retain(folder / 'independent-verification.json', 'verification/' + name + '.json')
        for p in sorted(folder.iterdir()):
            if p.is_file() and not p.is_symlink(): retain(p, 'batch-processes/' + name + '/' + p.name)
    assert len(rows) == 1290
    for name, count, phase in (('terminal-owner-independent-02', 60, 'primary'), ('terminal-owner-independent-recovery-01', 50, 'recovery')):
        folder = PROPOSALS / name
        complete = J(folder / 'complete.json')
        assert complete['source'] == OBSERVED and complete['session'] == SESSION
        assert len(complete['observations']) == count
        retain(folder / 'complete.json', 'verification/' + name + '.json')
        for saved in complete['observations']:
            path = folder / saved['variant'] / saved['surface']
            capture(path, {'case_id': saved['case'], 'captured_case_id': J(path / 'invocation.json')['case_id'],
                          'surface': saved['surface'], 'phase': phase}, saved['result_sha256'])
    assert len(rows) == 1400
    original = base.json(PREFIX + 'typed/observations.json')['observations']
    assert collections.Counter(tuple(r[k] for k in fields) for r in rows) == collections.Counter(tuple(r[k] for k in fields) for r in original)
    for r in rows:
        if r['case_id'].startswith('INFRA-S02-05.terminal-'):
            matches = [p for p in original if tuple(p[k] for k in fields) == tuple(r[k] for k in fields)]
            assert len(matches) == 1
            before = J(Path(matches[0]['capture_path']) / 'before.json')
            restored = J(Path(r['capture_path']) / 'before.json')
            for field in ('root','files','index_entries_hex','git_info_exclude','head','symbolic_head','refs','local_trust','untracked_roots'):
                assert before[field] == restored[field], (r['case_id'], r['surface'], field)
            assert all(before['index'][f] == restored['index'][f] for f in ('kind','mode'))
    for r in original:
        path = Path(r['capture_path']) / 'calls.jsonl'
        trace = path.read_bytes() if path.exists() else b''
        if r['trace_sha256']: assert H(trace) == r['trace_sha256']
        events = [json.loads(line) for line in trace.splitlines()]
        r['observer_event_ids'] = [e['event_id'] for e in events]
        r['observer_invocation_ids'] = sorted({e['invocation_id'] for e in events})
    for key in ('invocation_id', 'observer_event_ids', 'observer_invocation_ids'):
        flattened = lambda items: [v for r in items for v in (r[key] if isinstance(r[key], list) else [r[key]])]
        own, old = flattened(rows), flattened(original)
        assert len(own) == len(set(own)) and len(old) == len(set(old))
        assert set(own).isdisjoint(old)
    construction = J(args.construction / 'construction.json')
    receipt = J(args.construction / 'build-receipt.json')
    producer_receipt = json.loads(read_blob(base, producer['build']['receipt']))
    assert receipt == producer_receipt
    assert construction['source_commit'] == FINAL and construction['observed_source_commit'] == OBSERVED
    assert construction['modules_compiled_in_memory'] == 151
    assert construction['input_manifest'] == base.manifest(contract['input_roots'])
    assert construction['runtime_bytes_equal'] and not construction['changed_inputs']
    assert construction['script_sha256'] == base.json(PREFIX + 'typed/construction.json')['script_sha256']
    assert J(STORE / 'construction-process.json')['exit_code'] == 0
    build = write(TYPED + 'build-receipt.json', receipt)
    build_observation = write(TYPED + 'construction.json', construction)
    for name in ('raw-replay-complete.json', 'formatter-before.json', 'formatter-after.json', 'producer-packet-01-review.json'):
        retain(STORE / name, 'verification/' + name)
    for name in ('construction-command.json','construction-started.json','construction-process.json','construction-stdout.bin','construction-stderr.bin'):
        retain(STORE / name, 'verification/' + name)
    for p in sorted(STORE.glob('*.py')):
        retain(p, 'helpers/' + p.name)
    for pattern in ('*-command.json','*-started.json','*-process.json','*-stdout.bin','*-stderr.bin','adapter-*.json','remaining-standard-processes.json'):
        for p in sorted(STORE.glob(pattern)):
            # The current assembly process is retained by its outer process
            # receipt afterward, not read while it is still being written.
            if not p.name.startswith(args.output_name + '-'):
                retain(p, 'outer-processes/' + p.name)
    # Earlier failed terminal attempt is retained, never promoted to a passing case.
    failed = PROPOSALS / 'terminal-owner-independent-01'
    for relative in ('request.json', 'pending/input-restore.json', 'pending/before-input-restore.json', 'pending/C-restoration-check.json'):
        p = failed / relative
        if p.is_file(): retain(p, 'failed-terminal-attempt01/' + relative)
    archive_path = output / (TYPED + 'raw.tar.xz')
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive_path, 'x:xz') as archive:
        for name, raw in sorted(raw_files.items()):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o600
            archive.addfile(info, io.BytesIO(raw))
    archive_blob = {'path': TYPED + 'raw.tar.xz', 'sha256': H(archive_path.read_bytes())}
    inventory_blob = write(TYPED + 'raw-inventory.json', [{'path': name, 'size': len(raw), 'sha256': H(raw)} for name, raw in sorted(raw_files.items())])
    provenance = write(TYPED + 'provenance.json', {'reviewer_session': SESSION, 'producer_candidate': args.candidate,
        'producer_packet_sha256': args.packet, 'assessment_source': FINAL, 'observed_source': OBSERVED,
        'observations': 1400, 'fresh_standard_workspace': 1290, 'previous_independent_terminal_supplement': 110,
        'raw_archive': archive_blob, 'raw_inventory': inventory_blob,
        'independence': 'Reviewer did not author runtime implementation or producer proof; all credited calls are actual independent captures with disjoint identities.',
        'provenance': 'New assessment, not new execution. Original timestamps, source, authority, index metadata and failures remain immutable. Same producer fixture blob identifies the shared reviewed basis.',
        'restoration': 'Standard post-setup identity and workspace same-path full pre-state verified. Terminal supplement uses documented logical restoration with newly observed raw index stat-cache; no cross-run raw-byte identity claimed.',
        'applicability': 'All164 build inputs and executed modules are unchanged 992 to0abb. New normative clause changes phase placement only; original assertions and fixture policy/environment remain historical exact inputs. Final real-roadmap integration is excluded from prerequisite packet, not waived.',
        'not_applicable': [{'scenario_id': s['id'], 'dimension': k, **v} for s in contract['scenarios'] for k,v in s['dimensions'].items() if v['disposition'] == 'not_applicable'],
        'historical_dispositions': 'Old receipts retain original scope; no old REPLAY token approves this newly assembled replay. Prepared terminal fix does not assert installation.',
        'pending': ['Exact final publication delta and strict promotion', 'Producer and independent real-roadmap clean/mixed/restored/inventory integration', 'Installed verification', 'Product adoption and acceptance'],
        'activation_performed': False})
    entries, dispatches = {}, collections.defaultdict(list)
    for r in rows:
        handler, consumer = r['handler_ref'], r['consumer']
        entry = entries.setdefault(consumer, {'dispatch_key': Path(handler['path']).stem + '.' + handler['symbol'],
            'handler_ref': handler, 'entry_surfaces': ['project_status'] if consumer == 'selector' else ['staged_cli','candidate_cli','owner_hook'], 'contexts': {}})
        context = 'invocation-' + r['invocation_id']
        entry['contexts'][context] = {'enabled': r['handler_invoked'], 'reason': 'Retained actual independent handler invocation; current code byte-identical.' if r['handler_invoked'] else r['unavailable_reason']}
        dispatches[r['case_id'][:9]].append({'dispatch_key': entry['dispatch_key'],
            'entry_surface': {'C':'staged_cli','R':'candidate_cli','H':'owner_hook','S-check':'project_status','S-details':'project_status'}[r['surface']],
            'context': context, 'eligible': r['handler_invoked'], 'enabled': r['handler_invoked'], 'invoked': r['handler_invoked'],
            'handler_ref': handler, 'unavailable_reason': r['unavailable_reason'], 'mutation_count': 0})
    registry = write(TYPED + 'registry.json', {'schema_version':1, 'binary_sha256':receipt['binary_sha256'], 'entries':list(entries.values())})
    results = []
    for scenario in contract['scenarios']:
        sid = scenario['id']
        selected = [r for r in rows if r['case_id'].startswith(sid)]
        visible = f'Current independent applicability assessment of {len(selected)} actual source992 independent observations; exits {dict(collections.Counter(str(r["returncode"]) for r in selected))}. Not new execution.'
        state = 'Exact original protected states and expected outcomes verified. Current authority binds assessment only; real-roadmap and installed I04 integration remain mandatory separate receipts.'
        observations = write(TYPED + sid + '-observations.json', {'observed_source':OBSERVED, 'assessment_source':FINAL, 'observations':selected})
        event = write(TYPED + sid + '-events.json', {'schema_version':1,'scenario_id':sid,'producer_session':SESSION,
            'method':scenario['method'],'binary_sha256':receipt['binary_sha256'],'authority_sha256':authority,
            'inputs':scenario['inputs'],'dispatches':dispatches[sid],'actual_visible':visible,'actual_state':state})
        common = [observations, provenance, build_observation, archive_blob, inventory_blob]
        roles = write(TYPED + sid + '-roles.json', {'kind':'datum.workflow-delivery.artifacts/v1','scenario_id':sid,'events':[event],'captures':[],'state':common,'registry':registry})
        observed = {'normal':visible,'invalid':visible,'scope':state,
            'failure_recovery':'All required distinct recovery/restoration observations passed with retained original identities.',
            'accessibility':'Actual text-only diagnostic cases retained; no native GUI accessibility claim.',
            'cancel':'Five actual interrupted subprocesses returned -15, with protected state preserved and valid recoveries.',
            'save_reopen':'Actual fresh-process recovery retained; no native design Save/reopen claim.'}
        defects = next(r['defects'] for r in producer['results'] if r['scenario_id'] == sid)
        assert 'dat-wdq-rollout-implementation-ffy' not in defects
        results.append({'scenario_id':sid,'outcome':'pass','actual_visible':visible,'actual_state':state,
            'assertions':[{'dimension':k,'expected':v['reason'],'observed':observed[k],'outcome':'pass'} for k,v in scenario['dimensions'].items() if v['disposition']=='required'],
            'artifacts':[roles,event,registry,*common],'defects':defects})
    replay = {'schema_version':1,'contract_sha256':contract_sha256(contract),'producer_session':SESSION,'source_commit':FINAL,
        'input_manifest':producer['input_manifest'],'fixture':producer['fixture'],'environment':producer['environment'],
        'build':{'command':receipt['build_command'],'receipt':build,'toolchain':receipt['toolchain'],'source_clean':True},'results':results}
    replay_blob = write(TYPED + 'replay.json', replay)
    trust = Trust(tree, args.candidate, FINAL)
    item = next(i for i in tree.json('specs/active_frontier.json')['frontier'] if i['key']=='WORKFLOW-DELIVERY-IMPLEMENTATION')
    defects = sorted({d for r in results for d in r['defects']} | {'dat-wdq-test-default-branch-apx'})
    assert len(defects) == 6
    review = {'schema_version':1,'packet_sha256':args.packet,'reviewer_session':SESSION,
        'independent_of':sorted(set(trust.enrolled[item['key']]['implementation_sessions']) | {producer['producer_session']}),
        'disposition':'approve','replay':replay_blob,
        'findings':[{'issue_id':d,'severity':'nonblocking' if d=='dat-wdq-test-default-branch-apx' else 'blocking','disposition_ref':None} for d in defects],
        'owner_receipt':None}
    review_blob = write(contract['review_path'], review)
    validate_proof(tree, contract, replay_blob['path'])
    validate_environment(tree, replay, environment, contract=contract)
    assert len(validate_correlations(tree, contract, replay)) == 6
    validate_independent_review(tree, contract, producer, authority, trust, item, environment)
    try:
        validate_defect_dispositions(tree, review, contract['review_path'], trust)
    except DeliveryInputError as error:
        assert error.code == 'WDQ-DEFECT' and 'undisposed defect' in error.detail
        refusal = {'code':error.code,'detail':error.detail}
    else:
        raise AssertionError('Missing exact owner dispositions must refuse')
    write(TYPED + 'validation.json', {'candidate':args.candidate,'packet_sha256':args.packet,'review':review_blob,'replay':replay_blob,
        'review_sha256':review_sha256(review),'observations':1400,'proof_environment_correlations_independent_review':'pass',
        'expected_owner_disposition_refusal':refusal,'pid':os.getpid(),'started_ns':started,'finished_ns':time.time_ns(),
        'scope':'Technical prerequisite bounded proof/replay assessment only. Not final I04 integration, installation or product acceptance.',
        'activation_performed':False})
    inventory = [{'path':p.relative_to(output).as_posix(),'sha256':H(p.read_bytes()),'size':p.stat().st_size} for p in sorted(output.rglob('*')) if p.is_file()]
    result = {'candidate':args.candidate,'packet_sha256':args.packet,'output':str(output),'review':review_blob,'replay':replay_blob,
        'review_sha256':review_sha256(review),'inventory':inventory,'inventory_sha256':H(canonical_json(inventory)),
        'observations':1400,'technical_review':'approve','activation_performed':False}
    with (STORE / (args.output_name + '-result.json')).open('x') as f: json.dump(result, f, indent=2)
    print(json.dumps(result))

if __name__ == '__main__': main()
