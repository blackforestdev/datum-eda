"""Retain the exact command/process for same-path archived workspace replay."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/bfadmin/Documents/datum-eda')
STORE = Path(__file__).parent
batch = sys.argv[1]
assert batch in ('workspace-runtime', 'workspace-policy-legacy', 'workspace-proof-input')
prior = ROOT / '.git/datum-wdq/proposals/independent-sequencing-20260910/replay-workspace-prestates.py'
raw = prior.read_bytes()
code = raw.decode()
changes = {
    'sequencing-repair-20260910': 'terminal-owner-20260910',
    'sequencing-paired-evidence-20260910': 'terminal-rollout-evidence-20260910',
    '1d48f249dc7071fc3718b345a4ab16b366af43be': '9924678c39fe5d176e58ebfd8e25ab6feb213f35',
}
for old, new in changes.items():
    assert old in code
    code = code.replace(old, new)
code = '__file__=' + repr(str(STORE / 'replay-workspace-prestates.py')) + '\n' + code
argv = ['python3', '-I', '-S', '-B', '-c', code, batch]
def save(name, value):
    with (STORE / (batch + '-' + name + '.json')).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
save('command', {'argv': argv, 'cwd': str(ROOT), 'template': str(prior),
                 'template_sha256': hashlib.sha256(raw).hexdigest(), 'replacements': changes})
with (STORE / (batch + '-stdout.bin')).open('xb') as out, (STORE / (batch + '-stderr.bin')).open('xb') as err:
    started = time.time_ns()
    p = subprocess.Popen(argv, cwd=ROOT, stdout=out, stderr=err)
    save('started', {'pid': p.pid, 'started_ns': started})
    print(json.dumps({'batch': batch, 'pid': p.pid}), flush=True)
    status = p.wait()
save('process', {'pid': p.pid, 'exit_code': status, 'started_ns': started, 'ended_ns': time.time_ns(),
                **{k + '_sha256': hashlib.sha256((STORE / (batch + '-' + k + '.bin')).read_bytes()).hexdigest()
                   for k in ('stdout', 'stderr')}})
print(json.dumps({'batch': batch, 'exit_code': status}), flush=True)
raise SystemExit(status)
