"""Aggregate verified raw replay without asserting final-authority applicability."""
import hashlib
import json
from pathlib import Path
import subprocess

STORE = Path(__file__).parent
ROOT = Path('/home/bfadmin/Documents/datum-eda')
PRODUCER = ROOT / '.git/datum-wdq/proposals/terminal-rollout-evidence-20260910'
PIN = '9924678c39fe5d176e58ebfd8e25ab6feb213f35'
FINAL = '0abb325d9f06e7c8e4ea7b36e3a7ea2d8cd6f45c'
COUNTS = {'baseline': 5, 's01': 36, 's02-coverage': 110, 's02-ownership': 190,
          's03': 185, 's04': 175, 's05-snapshots': 39, 's06-selection': 60,
          's06-headless': 95, 's06-trust': 223, 'workspace-runtime': 52,
          'workspace-policy-legacy': 75, 'workspace-proof-input': 45}
J = lambda p: json.loads(p.read_bytes())
H = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
ids = {side: {key: set() for key in ('outer', 'observer', 'events')} for side in ('producer', 'independent')}
reports = []
for batch, count in COUNTS.items():
    workspace = batch.startswith('workspace-')
    own = STORE / (batch + '-exact' if workspace else batch)
    report_path = own / 'independent-verification.json'
    report = J(report_path)
    assert report['candidate'] == PIN
    assert all(report['stats'][s]['observations'] == count for s in ids)
    process = STORE / (batch + '-process.json') if workspace else own / 'collector-result.json'
    assert J(process)['exit_code'] == 0
    reports.append({'batch': batch, 'count': count, 'path': str(report_path), 'sha256': H(report_path)})
    for side in ids:
        directory = PRODUCER / batch if side == 'producer' else own
        if workspace and side == 'producer':
            rows = J(directory / 'renewal-result.json')['invocations']
            captures = [directory / row['capture_directory'] for row in rows]
        else:
            name = 'observations-complete.json' if side == 'producer' and batch == 's01' else 'observations.json'
            rows = J(directory / name)['observations']
            captures = [directory / row['directory'] / 'capture' for row in rows]
        assert len(captures) == count
        for cap in captures:
            inv = J(cap / 'invocation.json')['invocation_id']
            assert inv not in ids[side]['outer']
            ids[side]['outer'].add(inv)
            observers = set()
            trace = cap / 'calls.jsonl'
            for line in trace.read_text().splitlines() if trace.exists() else []:
                event = json.loads(line)
                assert event['event_id'] not in ids[side]['events']
                ids[side]['events'].add(event['event_id'])
                observers.add(event['invocation_id'])
            assert observers.isdisjoint(ids[side]['observer'])
            ids[side]['observer'].update(observers)
for key in ids['producer']:
    assert ids['producer'][key].isdisjoint(ids['independent'][key])
assert sum(COUNTS.values()) == 1290
freeze = J(PRODUCER / 'source-freeze.json')
for member in freeze['input_manifest']:
    blobs = [subprocess.check_output(['git', '--no-replace-objects', 'show', pin + ':' + member['path']], cwd=ROOT)
             for pin in (PIN, FINAL)]
    assert blobs[0] == blobs[1]
    assert hashlib.sha256(blobs[0]).hexdigest() == member['sha256']
before, after = (J(STORE / ('formatter-' + tag + '.json')) for tag in ('before', 'after'))
for field in ('path', 'resolved_path', 'sha256', 'size', 'version_stdout', 'version_stderr', 'exit_code'):
    assert before[field] == after[field]
value = {'reviewer_session': 'wdq-independent-review-20260906', 'executed_source': PIN,
         'observations': 1290, 'standard': 1118, 'workspace': 172, 'batches': reports,
         'unique_ids': {s: {k: len(v) for k, v in keys.items()} for s, keys in ids.items()},
         'cross_batch_and_producer_reviewer_id_disjointness': True,
         'final_source_build_input_comparison': {'source': FINAL, 'count': len(freeze['input_manifest']), 'all_equal': True},
         'formatter_before_after_equal': True,
         'scope': 'Actual exact-input independent raw replay on source992. Normative applicability, typed review, final real-roadmap integration, installation and product acceptance are separate. Earlier terminal-owner110 supplement is not repeated or counted here.',
         'final_authority_approved': False, 'activation_performed': False}
with (STORE / 'raw-replay-complete.json').open('x') as f:
    json.dump(value, f, indent=2)
    f.write('\n')
print(json.dumps(value))
