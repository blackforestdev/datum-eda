"""Retain actual formatter identity before and after the Rust-H observations."""
from pathlib import Path
prior = Path('/home/bfadmin/Documents/datum-eda/.git/datum-wdq/proposals/independent-sequencing-20260910/observe-formatter.py')
exec(compile(prior.read_bytes(), str(prior), 'exec'))
