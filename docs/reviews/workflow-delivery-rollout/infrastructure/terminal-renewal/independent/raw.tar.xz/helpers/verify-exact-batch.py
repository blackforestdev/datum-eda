"""Verify fresh terminal-runtime captures using the retained independent verifier."""
from pathlib import Path
ROOT = Path('/home/bfadmin/Documents/datum-eda')
prior = ROOT / '.git/datum-wdq/proposals/independent-sequencing-20260910/verify-exact-batch.py'
code = prior.read_text()
for old, new in {
    'sequencing-paired-evidence-20260910': 'terminal-rollout-evidence-20260910',
    'sequencing-evidence-20260910': 'terminal-rollout-evidence-20260910',
    'independent-sequencing-20260910': 'independent-terminal-rollout-20260910',
    'sequencing-repair-20260910': 'terminal-owner-20260910',
    '1d48f249dc7071fc3718b345a4ab16b366af43be': '9924678c39fe5d176e58ebfd8e25ab6feb213f35',
}.items():
    assert old in code
    code = code.replace(old, new)
exec(compile(code, str(prior), 'exec'))
