# Synthetic project-state doctrine
<!-- REQ:TASK:R -->
<!-- EVIDENCE-TASK-R -->
<!-- REQ:TASK:I -->
<!-- EVIDENCE-TASK-I -->
<!-- REQ:TASK:V -->
<!-- EVIDENCE-TASK-V -->
<!-- REQ:TASK:A -->
<!-- EVIDENCE-TASK-A -->
<!-- OWNER:TASK:A:A -->
<!-- REQ:NEXT:NEXT-C01 -->

<!-- NEXT-READY-EVIDENCE -->
<!-- REQ:NEXT:NEXT-C02 -->
<!-- OWNER:NEXT:NEXT-C02:AUTHORIZE -->
<!-- REQ:NEXT:NEXT-C03 -->
