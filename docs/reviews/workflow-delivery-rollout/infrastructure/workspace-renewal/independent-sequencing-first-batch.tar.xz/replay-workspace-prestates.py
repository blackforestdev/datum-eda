"""Restore transferred temporary fixture custody and replay exact archived inputs."""
import hashlib,json,os,re,shutil,sys,tarfile,uuid
from pathlib import Path,PurePosixPath
ROOT=Path('/home/bfadmin/Documents/datum-eda')
STORE=Path(__file__).parent
RUNTIME=ROOT/'.git/datum-wdq/proposals/sequencing-repair-20260910'
PIN='1d48f249dc7071fc3718b345a4ab16b366af43be'
batch=sys.argv[1]
assert batch in ('workspace-runtime','workspace-policy-legacy','workspace-proof-input')
producer_name=sys.argv[2] if len(sys.argv)>2 else batch
assert Path(producer_name).name==producer_name
producer=ROOT/'.git/datum-wdq/proposals/sequencing-paired-evidence-20260910'/producer_name
own=STORE/(batch+'-exact');own.mkdir()
J=lambda p:json.loads(p.read_bytes())
H=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
bootstrap=RUNTIME/'scripts/workflow_delivery_source_only.py'
ns={'__name__':'_review_bootstrap'};exec(compile(bootstrap.read_bytes(),str(bootstrap),'exec'),ns);ns['install'](bootstrap.parent)
sys.path.insert(0,str(bootstrap.parent))
from workflow_delivery_capture_command import capture_command
from workflow_delivery_capture_state import protected_state,git
assert J(producer.parent/(producer_name+'-process.json'))['exit_code']==0
assert git(RUNTIME,'rev-parse','HEAD').decode().strip()==PIN
rows=J(producer/'renewal-result.json')['invocations'];results=[]
for row in rows:
    old=producer/row['capture_directory'];inv=J(old/'invocation.json');before=J(old/'before.json');expected=J(old/'result.json')
    fixture=Path(inv['cwd'])
    assert re.fullmatch(r'/tmp/tmp[a-zA-Z0-9_-]+',str(fixture)),str(fixture)
    assert not fixture.exists() and not fixture.is_symlink(),('custody collision',str(fixture))
    descriptor=J(old/'prestate-archive.json');archive=Path(descriptor['path'])
    assert archive.parent==producer and H(archive.read_bytes())==descriptor['sha256']
    out=own/row['capture_directory'];out.mkdir()
    # No overwrite or implicit cleanup: an extraction/capture failure retains
    # this exact transferred fixture and halts the sequence for diagnosis.
    fixture.mkdir(mode=0o700)
    with tarfile.open(archive) as t:
        members=t.getmembers();names={}
        for m in members:
            n=PurePosixPath(m.name)
            assert not n.is_absolute() and '..' not in n.parts
            assert m.isdir() or m.isfile() or m.issym() or m.islnk(),m.name
            if str(n)=='.':continue
            assert str(n) not in names;names[str(n)]=m
        for name,m in names.items():
            assert all(not (str(parent) in names and (names[str(parent)].issym() or names[str(parent)].islnk())) for parent in PurePosixPath(name).parents)
        for name,m in names.items():
            p=fixture/name
            if m.isdir():p.mkdir(parents=True,exist_ok=True)
            elif m.isfile():
                p.parent.mkdir(parents=True,exist_ok=True)
                with p.open('xb') as f:shutil.copyfileobj(t.extractfile(m),f)
                p.chmod(m.mode);os.utime(p,(m.mtime,m.mtime))
        for name,m in names.items():
            p=fixture/name
            if m.issym():p.symlink_to(m.linkname)
            elif m.islnk():
                link=PurePosixPath(m.linkname);assert not link.is_absolute() and '..' not in link.parts
                target=fixture/str(link);assert target.is_file() and not target.is_symlink();os.link(target,p)
        for name,m in names.items():
            if m.isdir():(fixture/name).chmod(m.mode)
    assert (fixture/'.git/datum-wdq-capture-owner').read_text().strip()==inv['fixture_nonce']
    actual=protected_state(fixture,before['untracked_roots']);assert actual==before,(row,'restored pre-state mismatch')
    nonce=str(uuid.uuid4());(fixture/'.git/datum-wdq-capture-owner').write_text(nonce+'\n')
    capture=out/'capture'
    relocate=lambda s:s.replace(str(old),str(capture))
    env={k:relocate(v) for k,v in inv['environment'].items()};env.update(HOME=str(own),XDG_CONFIG_HOME=str(own))
    save(out/'input-identity.json',{'original_fixture':str(fixture),'producer_capture':str(old),
         'archive':descriptor,'exact_before_state_equal':True,'fresh_owner_nonce':True,
         'custody':'Producer terminal and original pathname absent; atomic independent restoration. Absolute cache filenames preserved.'})
    result=capture_command(fixture,capture,[relocate(v) for v in inv['argv']],env,
        fixture_nonce=nonce,case_id=inv['case_id'],surface=inv['surface'],untracked_roots=before['untracked_roots'],
        timeout=inv['timeout_seconds'],interrupt_on_call=inv['interrupt_on_call'])
    assert result['kind']==expected['kind'] and result['returncode']==expected['returncode'],(row,result)
    assert not result['changed_files'] and not result['changed_state_fields']
    oldtext=(old/'stdout.bin').read_bytes()+(old/'stderr.bin').read_bytes()
    text=(capture/'stdout.bin').read_bytes()+(capture/'stderr.bin').read_bytes()
    assert set(re.findall(rb'WDQ-[A-Z]+',text))==set(re.findall(rb'WDQ-[A-Z]+',oldtext)),(row,text)
    record=dict(row,invocation_id=result['invocation_id'],directory=out.name,
        result_sha256=H((capture/'result.json').read_bytes()),exact_before_state_equal=True,states_unchanged=True)
    save(out/'independent-assessment.json',record);results.append(record)
    assert fixture.parent==Path('/tmp') and not fixture.is_symlink()
    assert (fixture/'.git/datum-wdq-capture-owner').read_text().strip()==nonce
    shutil.rmtree(fixture)
    save(out/'cleanup.json',{'path':str(fixture),'restored_owned_fixture_removed':not fixture.exists(),
        'recoverable_from':descriptor,'raw_capture_preserved':True})
    print(json.dumps({'completed':len(results),'batch':batch,'invocation_id':result['invocation_id']}),flush=True)
save(own/'observations.json',{'candidate':PIN,'observations':results,'reviewer_session':'wdq-independent-review-20260906',
     'scope':'Exact same-path pre-state replay under transferred temporary fixture custody; no source/clock/cache regeneration.',
     'independent_recheck_complete':False,'activation_performed':False})
