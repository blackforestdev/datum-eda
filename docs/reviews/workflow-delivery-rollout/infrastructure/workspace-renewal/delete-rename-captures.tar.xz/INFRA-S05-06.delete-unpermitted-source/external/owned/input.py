# Synthetic external baseline.
