"""Reconcile exact later evidence delta and observe actual-main inspection."""
import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/bfadmin/Documents/datum-eda')
HERE=Path(__file__).parent
RUNTIME=ROOT/'.git/datum-wdq/proposals/sequencing-repair-20260910'
BASE='8423a5f7311529d625cf7009d3321bfe973436e9'
CANDIDATE='992ce4f41da6bdeadc9526cceba3c79e819fa3da'
EARLIER_BASE='e54fe5562174ef3f3c6748bb2c9c649626e2f652'
EARLIER_CANDIDATE='ee3425a23d3c220b9303d26ebfa89f0ae6f1b19d'
PRODUCER='06bafeb9979dce91ab710bfaaff7f8f9ca3e72f2'
PREFIX='docs/reviews/workflow-delivery-rollout/infrastructure/workspace-renewal/'
H=lambda raw:hashlib.sha256(raw).hexdigest()
J=lambda p:json.loads(p.read_bytes())
def save(p,value):
    with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git','--no-replace-objects','--no-optional-locks',*args],cwd=ROOT)
bootstrap=RUNTIME/'scripts/workflow_delivery_source_only.py'
assert bootstrap.read_bytes()==git('show','1d48f249dc7071fc3718b345a4ab16b366af43be:scripts/workflow_delivery_source_only.py')
ns={'__name__':'_final_review_bootstrap'}
exec(compile(bootstrap.read_bytes(),str(bootstrap),'exec'),ns);ns['install'](bootstrap.parent)
sys.path.insert(0,str(bootstrap.parent))
from workflow_delivery_tree import Tree
from workflow_delivery_io import canonical_json
from workflow_delivery_capture_state import protected_state
from workflow_delivery_publication_delta import publication_delta
from workflow_delivery_support_store import proposed_local_trust
from workflow_delivery_support_bundle import prepare_bundle
assert git('rev-parse','HEAD').decode().strip()==BASE and not git('status','--porcelain')
assert git('show','-s','--format=%P',CANDIDATE).decode().strip()==BASE
old,live,prior,current,producer=[Tree(ROOT,revision=p) for p in (EARLIER_BASE,BASE,EARLIER_CANDIDATE,CANDIDATE,PRODUCER)]
main_paths=[p for p in git('diff','--name-only','-z',EARLIER_BASE,BASE).decode().split('\0') if p]
candidate_paths=[p for p in git('diff','--name-only','-z',EARLIER_CANDIDATE,CANDIDATE).decode().split('\0') if p]
assert all(p.startswith(PREFIX) or p=='.beads/issues.jsonl' for p in main_paths)
assert all(p.startswith(PREFIX) or p in ('.beads/issues.jsonl','docs/reviews/workflow-delivery-rollout/infrastructure/proof.json','docs/reviews/workflow-delivery-rollout/infrastructure/review.json') for p in candidate_paths)
old_beads=old.read('.beads/issues.jsonl');new_beads=live.read('.beads/issues.jsonl')
assert new_beads.startswith(old_beads)
added=new_beads[len(old_beads):].splitlines();assert len(added)==1
assert json.loads(added[0])['id']=='dat-wdq-test-default-branch-apx' and json.loads(added[0])['status']=='open'
assert current.read('.beads/issues.jsonl')==new_beads
assert old.read('specs/active_frontier.json')==live.read('specs/active_frontier.json')
assert prior.read('specs/active_frontier.json')==current.read('specs/active_frontier.json')
frontiers=[t.json('specs/active_frontier.json')['frontier'] for t in (live,current)]
others=[[item for item in rows if item['key']!='WORKFLOW-DELIVERY-IMPLEMENTATION'] for rows in frontiers]
assert others[0]==others[1] and len(others[0])==55
source=Tree(ROOT,revision='1d48f249dc7071fc3718b345a4ab16b366af43be')
contract=current.json('specs/workflow_delivery/rollout.contract.json')
assert current.manifest(contract['input_roots'])==source.manifest(contract['input_roots'])==prior.manifest(contract['input_roots'])
payload=[]
for path in [contract['proof_path']]+[p for p in git('ls-tree','-r','--name-only',PRODUCER,'--',PREFIX+'paired-real-typed/').decode().splitlines()]:
    assert current.read(path)==producer.read(path);payload.append({'path':path,'sha256':H(current.read(path))})
overlay=HERE/'typed-review-attempt-02'
review_result=J(HERE/'typed-review-attempt-02-result.json')
for row in review_result['inventory']:
    raw=current.read(row['path']);assert H(raw)==row['sha256'] and raw==(overlay/row['path']).read_bytes()
    payload.append({'path':row['path'],'sha256':H(raw)})
assert len(payload)==54
for name in ('first','second','third','fourth'):
    for suffix in ('.json','.tar.xz'):
        path=PREFIX+'independent-sequencing-'+name+'-batch'+suffix
        assert current.read(path)==live.read(path)
delta=publication_delta(ROOT,base=BASE,candidate=CANDIDATE)
assert H(canonical_json(delta))=='62ae9ed72e6c712a1f6770ace3fb5ac4da69cfc96e7f854185567cd39765f73c'
request=J(ROOT/'.git/datum-wdq/proposals/sequencing-evidence-20260910/recheck-live-review-request.json')
state=protected_state(ROOT,request['input_roots'])
assert state['local_trust']==request['prior_local_trust']
request.update(base=BASE,candidate=CANDIDATE,authority=CANDIDATE,
    publication_review={'delta_sha256':H(canonical_json(delta)),'paths':delta['touched_paths']},
    proposed_local_trust=proposed_local_trust(ROOT,authority=CANDIDATE,base=BASE,environment_path=request['environment_path']))
request_path=HERE/'final-live-request.json';save(request_path,request)
save(HERE/'final-delta-reconciliation.json',{'earlier_base':EARLIER_BASE,'earlier_candidate':EARLIER_CANDIDATE,
    'base':BASE,'candidate':CANDIDATE,'main_paths':main_paths,'candidate_paths':candidate_paths,
    'actual_publication_delta':delta,'publication_delta_sha256':H(canonical_json(delta)),
    'exact_evidence_payloads':payload,'other_frontier_lanes_unchanged':55,'runtime_inputs_unchanged':164,
    'beads_delta':'Exact single open apx intake row; every earlier byte retained. No issue closure.',
    'semantic_reconciliation':'Later changes consist of reviewed paired fixture retention, assembler/builder/verifier helpers, exact producer/independent evidence and one test-portability intake. Historical attempts remain; no source/authority/prototype change since prior inspection. Exact54 imported bytes match06ba and own validated overlay; all four raw archives unchanged.',
    'owner_boundary':'No dispositions or activation authorized. Strict final I04 full-evidence validation/owner-controlled promotion remain required.'})
support=prepare_bundle(ROOT,CANDIDATE);save(HERE/'final-uninstalled-support.json',support)
assert state==protected_state(ROOT,request['input_roots'])
template=HERE/'inspect-live.py';code=template.read_text()
replacements={"/'live-review'":"/'final-live-review'",
    "ROOT/'.git/datum-wdq/proposals/sequencing-evidence-20260910/recheck-live-review-request.json'":"Path(__file__).parent/'final-live-request.json'",
    '8f00db36dc99131fccefc6a2b38cf535410966107e3fbda219ab4bb1f14bf56f':H(request_path.read_bytes()),
    EARLIER_BASE:BASE,EARLIER_CANDIDATE:CANDIDATE,
    'independent-sequencing-recheck-20260910.json':'independent-sequencing-final-recheck-20260910.json',
    'Actual supported pre-review source/history inspection; distinct final candidate requires later delta reconciliation and strict I04 inspection.':'Actual supported final RECHECK source/history inspection with explicit prior-to-current delta reconciliation. Strict I04 full-evidence inspection and owner dispositions remain required; later changed candidates require their own reconciliation.'}
for before,after in replacements.items():
    assert before in code,before;code=code.replace(before,after)
exec(compile(code,str(template)+'[final-exact-delta]','exec'),{'__name__':'__main__','__file__':str(template)})
