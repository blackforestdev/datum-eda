"""Verify actual observer identities and retained final inspection bindings."""
import hashlib,json,subprocess
from pathlib import Path
HERE=Path(__file__).parent
ROOT=Path('/home/bfadmin/Documents/datum-eda')
STORE=HERE/'final-live-review'
CANDIDATE='992ce4f41da6bdeadc9526cceba3c79e819fa3da'
H=lambda raw:hashlib.sha256(raw).hexdigest()
J=lambda p:json.loads(p.read_bytes())
process=J(STORE/'process.json');verified=J(STORE/'independent-verification.json')
assert process['exit_code']==0 and verified['exit_code']==0
events=[json.loads(line) for line in (STORE/'calls.jsonl').read_bytes().splitlines()]
earlier=[json.loads(line) for line in (HERE/'live-review/calls.jsonl').read_bytes().splitlines()]
assert len({e['event_id'] for e in events})==len(events)
assert not {e['event_id'] for e in events}&{e['event_id'] for e in earlier}
assert not {e['invocation_id'] for e in events}&{e['invocation_id'] for e in earlier}
assert all(e['pid']==process['pid'] for e in events)
assert [e['event'] for e in events].count('start')==1
assert any(e.get('event')=='call' and e.get('function')=='inspect_review_candidate' for e in events)
bindings=[]
def inspect(value):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and '/scripts/' in value['path'] and 'sha256' in value:
            path='scripts/'+value['path'].split('/scripts/',1)[1]
            raw=subprocess.check_output(['git','--no-replace-objects','show',CANDIDATE+':'+path],cwd=ROOT)
            assert H(raw)==value['sha256'];bindings.append({'path':path,'sha256':H(raw)})
        for child in value.values():inspect(child)
    elif isinstance(value,list):
        for child in value:inspect(child)
inspect(events)
assert bindings
assert (STORE/'before.json').read_bytes()==(STORE/'after.json').read_bytes()
log=Path(verified['log_path']);assert H(log.read_bytes())==verified['log_sha256']
request=HERE/'final-live-request.json';assert H(request.read_bytes())==verified['request_sha256']
record={'candidate':CANDIDATE,'process':process,'observer_events':len(events),
    'observer_invocation_ids':sorted({e['invocation_id'] for e in events}),
    'event_ids_disjoint_from_prior_inspection':True,'source_bindings':bindings,
    'calls_sha256':H((STORE/'calls.jsonl').read_bytes()),'request_sha256':H(request.read_bytes()),
    'log_sha256':H(log.read_bytes()),'protected_state_equal':True,
    'technical_recommendation':'Required independent replay, focused scope and later exact source/history inspection are satisfied for992ce/FA. Root may record RECHECK technical closeout and present I04; this is not owner disposition, final strict I04 inspection or activation.',
    'boundary':'992ce selects RECHECK, not claim-free I04. A later I04 candidate must preserve these exact source/proof/review bytes and reconcile only authorized governance/owner evidence changes; strict final full-evidence inspection remains mandatory.',
    'activation_performed':False}
with (HERE/'final-live-trace-verification.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
