"""Independently observe supported non-authorizing inspection of actual main."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/bfadmin/Documents/datum-eda')
STORE=Path(__file__).parent/'live-review'
RUNTIME=ROOT/'.git/datum-wdq/proposals/sequencing-repair-20260910'
PIN='1d48f249dc7071fc3718b345a4ab16b366af43be'
REQUEST=ROOT/'.git/datum-wdq/proposals/sequencing-evidence-20260910/recheck-live-review-request.json'
SHA='8f00db36dc99131fccefc6a2b38cf535410966107e3fbda219ab4bb1f14bf56f'
H=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
STORE.mkdir()
bootstrap=RUNTIME/'scripts/workflow_delivery_source_only.py'
raw=bootstrap.read_bytes()
assert raw==subprocess.check_output(['git','show',PIN+':scripts/workflow_delivery_source_only.py'],cwd=ROOT)
ns={'__name__':'_independent_bootstrap'};exec(compile(raw,str(bootstrap),'exec'),ns);ns['install'](bootstrap.parent)
sys.path.insert(0,str(RUNTIME/'scripts'))
from workflow_delivery_capture_state import protected_state,git
from workflow_delivery_publication_delta import publication_delta,verify_publication_review
from workflow_delivery_io import canonical_json
from workflow_delivery_tree import Tree
from workflow_delivery_authority import authority_sha256
assert H(REQUEST.read_bytes())==SHA
request=json.loads(REQUEST.read_bytes());save(STORE/'request.json',request)
assert request['kind']=='datum.workflow-delivery.review-inspection-request'
assert request['base']=='e54fe5562174ef3f3c6748bb2c9c649626e2f652'
assert request['candidate']==request['authority']=='ee3425a23d3c220b9303d26ebfa89f0ae6f1b19d'
delta=publication_delta(ROOT,base=request['base'],candidate=request['candidate'])
verify_publication_review(delta,request['publication_review']);save(STORE/'publication-delta.json',delta)
t=Tree(ROOT,revision=request['candidate']);contract=t.json('specs/workflow_delivery/rollout.contract.json')
freeze=json.loads((ROOT/'docs/reviews/workflow-delivery-rollout/infrastructure/workspace-renewal/sequencing-source-freeze.json').read_bytes())
assert t.manifest(contract['input_roots'])==freeze['input_manifest']
assert authority_sha256(t,contract)==freeze['authority_sha256']
assert git(ROOT,'rev-parse','HEAD').decode().strip()==request['base'] and not git(ROOT,'status','--porcelain')
before=protected_state(ROOT,request['input_roots']);save(STORE/'before.json',before)
assert before['local_trust']==request['prior_local_trust']
prepared=ROOT/'.git/datum-wdq/trusted'/request['authority']
output=ROOT/'.git/datum-wdq/logs/independent-sequencing-recheck-20260910.json'
command=[sys.executable,'-I','-S','-B',str(RUNTIME/'scripts/workflow_delivery_observe_python.py'),
 '--script',str(prepared/'scripts/workflow_delivery_preflight_cli.py'),'--source-root',str(prepared),
 '--output',str(STORE/'calls.jsonl'),'--function','main','--function','inspect_review_candidate','--',
 '--inspect-review','--root',str(ROOT),'--request',str(REQUEST),'--request-sha256',SHA,'--output',str(output)]
save(STORE/'command.json',{'argv':command,'cwd':str(ROOT),'scope':'Independent actual-main pre-review inspection only; no owner response or activation.'})
with (STORE/'stdout.bin').open('xb') as out,(STORE/'stderr.bin').open('xb') as err:
    start=time.time_ns();p=subprocess.Popen(command,cwd=ROOT,stdout=out,stderr=err)
    save(STORE/'started.json',{'pid':p.pid,'started_ns':start});print(json.dumps({'pid':p.pid}),flush=True);status=p.wait()
save(STORE/'process.json',{'pid':p.pid,'started_ns':start,'finished_ns':time.time_ns(),'exit_code':status})
after=protected_state(ROOT,request['input_roots']);save(STORE/'after.json',after)
assert before==after
assert git(ROOT,'rev-parse','HEAD').decode().strip()==request['base'] and not git(ROOT,'status','--porcelain')
assert status==0,(STORE/'stdout.bin').read_text()
log=json.loads(output.read_bytes());assert log['ok']
for field in ('evidence_validated','publication_authorized','activation_asserted'):assert log[field] is False
assert log['review_inspection']['selected_step']=='WDQ-RECHECK'
save(STORE/'independent-verification.json',{'source_commit':PIN,'base':request['base'],'candidate':request['candidate'],
 'request_sha256':SHA,'log_path':str(output),'log_sha256':H(output.read_bytes()),'exit_code':status,
 'input_count':164,'authority_sha256':freeze['authority_sha256'],'protected_state_unchanged':True,
 'actual_main_clean_before_after':True,'evidence_validated':False,'activation_asserted':False,
 'publication_authorized':False,'review_complete':False,'scope':'Actual supported pre-review source/history inspection; distinct final candidate requires later delta reconciliation and strict I04 inspection.'})
print(json.dumps({'exit_code':status,'log_sha256':H(output.read_bytes()),'protected_state_unchanged':True}),flush=True)
