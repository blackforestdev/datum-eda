"""Assemble independent process evidence without owner acceptance or publication."""
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path('/home/bfadmin/Documents/datum-eda')
STORE=Path(__file__).parent
RUNTIME=ROOT/'.git/datum-wdq/proposals/sequencing-repair-20260910'
OUTPUT=STORE/'typed-review-attempt-01'
PIN='1d48f249dc7071fc3718b345a4ab16b366af43be'
CANDIDATE='06bafeb9979dce91ab710bfaaff7f8f9ca3e72f2'
BASE='377323b29705ccccd6f8fa91f663d7d91c6d03c4'
PACKET='fa0b802e11d5dc266f7f3e78bde8a1ac91ac6c1ae4165df8858b56b94c158fee'
SESSION='wdq-independent-review-20260906'
PREFIX='docs/reviews/workflow-delivery-rollout/infrastructure/workspace-renewal/'
TYPED=PREFIX+'independent-sequencing-typed/'
H=lambda raw:hashlib.sha256(raw).hexdigest()
J=lambda p:json.loads(p.read_bytes())
bootstrap=RUNTIME/'scripts/workflow_delivery_source_only.py'
ns={'__name__':'_review_source_bootstrap'}
exec(compile(bootstrap.read_bytes(),str(bootstrap),'exec'),ns);ns['install'](bootstrap.parent)
sys.path.insert(0,str(bootstrap.parent))
from workflow_delivery_tree import Tree
from workflow_delivery_io import canonical_json, DeliveryInputError
from workflow_delivery_authority import authority_sha256
from workflow_delivery_contract import contract_sha256
from workflow_delivery_evidence_shapes import review_sha256
from workflow_delivery_native import validate_correlations, validate_environment
from workflow_delivery_proof import packet_sha256, validate_proof, read_blob
from workflow_delivery_review import validate_independent_review, validate_defect_dispositions
from workflow_delivery_trust import Trust

def main():
    started=time.time_ns();OUTPUT.mkdir()
    base=Tree(ROOT,revision=CANDIDATE)
    main_pin=subprocess.check_output(['git','--no-replace-objects','rev-parse','HEAD'],cwd=ROOT).decode().strip()
    committed=Tree(ROOT,revision=main_pin)
    contract=base.json('specs/workflow_delivery/rollout.contract.json')
    producer=validate_proof(base,contract)
    authority=authority_sha256(base,contract)
    assert packet_sha256(contract,producer,authority)==PACKET
    archives=[]
    for batch in ('first','second','third','fourth'):
        for suffix in ('.json','.tar.xz'):
            path=PREFIX+'independent-sequencing-'+batch+'-batch'+suffix
            archives.append({'path':path,'sha256':H(committed.read(path))})
    archive_paths={b['path'] for b in archives}
    class Overlay:
        staged=False
        def __getattr__(self,key):return getattr(base,key)
        def read(self,path,**kwargs):
            p=OUTPUT/path
            return p.read_bytes() if p.is_file() else committed.read(path,**kwargs) if path in archive_paths else base.read(path,**kwargs)
        def json(self,path,**kwargs):return json.loads(self.read(path,**kwargs))
    tree=Overlay()
    def write(path,value):
        p=OUTPUT/path;p.parent.mkdir(parents=True,exist_ok=True)
        with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
        return {'path':path,'sha256':H(p.read_bytes())}
    def capture(path,row):
        result=J(path/'result.json');invocation=J(path/'invocation.json')
        assert result['invocation_id']==invocation['invocation_id']
        assert not result['changed_files'] and not result['changed_state_fields']
        assert (path/'before.json').read_bytes()==(path/'after.json').read_bytes()
        for artifact in result['artifacts']:assert H((path/artifact['path']).read_bytes())==artifact['sha256']
        source='scripts/workflow_delivery_selector.py' if row['surface'].startswith('S-') else 'scripts/check_workflow_delivery.py'
        symbol='selector_failures' if row['surface'].startswith('S-') else 'main'
        events=[json.loads(line) for line in (path/'calls.jsonl').read_bytes().splitlines()] if (path/'calls.jsonl').exists() else []
        calls=[e for e in events if e.get('event')=='call' and e.get('function')==symbol and Path(e['source']['path']).name==Path(source).name]
        assert len(calls)<=1
        for e in calls:assert e['source']['sha256']==H(base.read(source))
        if not calls:assert row['surface']=='H' and result['returncode']!=0 and (path/'stderr.bin').read_bytes().strip()
        return {**row,'capture_path':str(path),'invocation_id':result['invocation_id'],
            'result_sha256':H((path/'result.json').read_bytes()),'artifacts':result['artifacts'],
            'started_ns':invocation['started_ns'],'finished_ns':result['finished_ns'],'pid':result['pid'],
            'observer_invocation_ids':sorted({e['invocation_id'] for e in events}),
            'observer_event_ids':[e['event_id'] for e in events],
            'consumer':'selector' if row['surface'].startswith('S-') else 'validator',
            'handler_ref':{'path':source,'symbol':symbol},'handler_invoked':bool(calls),
            'returncode':result['returncode'],'result_kind':result['kind'],
            'unavailable_reason':None if calls else (path/'stderr.bin').read_text().strip()}
    rows=[];reports=[];fields=('case_id','captured_case_id','surface','phase')
    batches={'s01':36,'s02-coverage':110,'s02-ownership':190,'s03':185,'s04':175,
        's05-snapshots':39,'s06-selection':60,'s06-headless':95,'s06-trust':223,'baseline':5}
    for name,count in batches.items():
        folder=STORE/name;inventory=J(folder/'observations.json')['observations'];assert len(inventory)==count
        for saved in inventory:
            assert saved['exact_post_setup_input_identity'] and saved['states_unchanged']
            row=capture(folder/saved['directory']/'capture',{k:saved[k] for k in fields})
            assert row['result_sha256']==saved['result_sha256'];rows.append(row)
        reports.append(J(folder/'independent-verification.json'))
    extra={'workspace-runtime-exact':52,'workspace-policy-legacy-exact':75,'workspace-proof-input-exact':45,
        'real-roadmap-exact-complete':15,'current-inventory-exact-v2':9}
    for name,count in extra.items():
        folder=STORE/name;inventory=J(folder/'observations.json')['observations'];assert len(inventory)==count
        for saved in inventory:
            assert saved['exact_before_state_equal'] and saved['states_unchanged']
            path=Path(saved['directory']);path=path if path.is_absolute() else folder/path
            original=name=='real-roadmap-exact-complete' and saved['case']=='clean'
            row={'case_id':'INFRA-S04-11' if original else 'INFRA-S05-WORKSPACE-'+saved['case'],
                'captured_case_id':'INFRA-S04-11' if original else J(path/'capture/invocation.json')['case_id'],
                'surface':{'S':'S-check','D':'S-details'}.get(saved['surface'],saved['surface']),
                'phase':'primary' if original else 'compatibility'}
            raw=capture(path/'capture',row)
            assert raw['returncode']==(1 if saved['expected_refusal'] else 0)
            assert raw['result_sha256']==saved['result_sha256'];rows.append(raw)
        reports.append(J(folder/'independent-verification.json'))
    assert len(rows)==1314 and len({r['invocation_id'] for r in rows})==1314
    original=[]
    for scenario in contract['scenarios']:
        original.extend(base.json(PREFIX+'paired-real-typed/'+scenario['id']+'-observations.json')['observations'])
    ident=lambda r:tuple(r[k] for k in fields)
    assert collections.Counter(map(ident,rows))==collections.Counter(map(ident,original))
    for key in ('invocation_id','observer_event_ids','observer_invocation_ids'):
        own=[v for r in rows for v in (r[key] if isinstance(r[key],list) else [r[key]])]
        old={v for r in original for v in (r[key] if isinstance(r[key],list) else [r[key]])}
        assert not set(own)&old
        if key!='observer_invocation_ids':assert len(own)==len(set(own))
    construction=J(STORE/'construction-stdout.bin')
    receipt={'binary_sha256':construction['interpreter']['sha256'],'build_command':construction['command'],
        'toolchain':construction['toolchain'],'input_manifest_sha256':construction['input_manifest_sha256'],'exit_code':0}
    assert receipt==json.loads(read_blob(tree,producer['build']['receipt']))
    assert construction['source_commit']==PIN and construction['modules_compiled_in_memory']==151
    build=write(TYPED+'build-receipt.json',receipt)
    build_observation=write(TYPED+'build-observation.json',construction)
    live=J(STORE/'live-review/independent-verification.json')
    assert live['exit_code']==0 and live['protected_state_unchanged'] and not live['evidence_validated']
    assert H(Path(live['log_path']).read_bytes())==live['log_sha256']
    inspection=write(TYPED+'pre-review-inspection.json',{'verification':live,'raw_log':J(Path(live['log_path']))})
    assert J(STORE/'focused-workspace-v2/process.json')['exit_code']==0
    focused=write(TYPED+'focused-workspace.json',{'first_failure':J(STORE/'focused-workspace/child-observation.json'),
        'passing_explicit_profile':J(STORE/'focused-workspace-v2/verification.json'),
        'issue_id':'dat-wdq-test-default-branch-apx','source_fixed':False,'matrix_credit':0})
    provenance=write(TYPED+'provenance.json',{'reviewer_session':SESSION,'producer_packet_sha256':PACKET,
        'runtime':PIN,'producer_candidate':CANDIDATE,'artifact_main_commit':main_pin,'observations':1314,
        'original_inventory':1123,'additional_workspace':191,'batch_reports':reports,'raw_archives':archives,
        'fixture_identity':'Same producer fixture Blob is the reviewed common basis. Original cases replay exact retained post-setup objects; workspace and real cases restore full exact pre-state bytes at original absolute paths. Local capture nonce changes occur only after exact input comparison. No regenerated history/cache is counted.',
        'timestamps':'Actual raw start/finish timestamps retained; earlier captures are not represented as occurring after closeout.',
        'failed_attempts':'Expired lease, missing bundle-ref seed, original180s hook timeout and default-branch regression retained. Remaining-six exact retry succeeded with unchanged timeout/source. Timeout cause undetermined. Supplemental regenerated172 have zero exact replay credit.',
        'not_applicable_dispositions':[{'scenario_id':s['id'],'dimension':k,'reason':v['reason'],'authority_refs':v['authority_refs']} for s in contract['scenarios'] for k,v in s['dimensions'].items() if v['disposition']=='not_applicable'],
        'independence':'Reviewer did not produce runtime implementation or original producer proof. These artifacts derive only actual reviewer executions and independent inspections.',
        'prior_owner_dispositions':'Five prior owner dispositions remain bound only to their historical source/replay scope; none accepts this review or resolves its five current findings.',
        'publication_boundary':'Earlier actual-main e54fe/ee342 source-history inspection is included. Later evidence/intake/review candidates require explicit distinct delta reconciliation and renewed exact-publication inspection before I04 presentation. Strict final full-evidence I04 inspection/owner dispositions remain mandatory; no earlier packet depends on its own later receipt.',
        'independent_recheck_complete':False,'activation_performed':False})
    entries={};dispatches=collections.defaultdict(list)
    for row in rows:
        handler=row['handler_ref'];consumer=row['consumer']
        entry=entries.setdefault(consumer,{'dispatch_key':Path(handler['path']).stem+'.'+handler['symbol'],
            'handler_ref':handler,'entry_surfaces':['project_status'] if consumer=='selector' else ['staged_cli','candidate_cli','owner_hook'],'contexts':{}})
        context='invocation-'+row['invocation_id'];enabled=row['handler_invoked']
        entry['contexts'][context]={'enabled':enabled,'reason':'Independent handler call observed.' if enabled else row['unavailable_reason']}
        dispatches[row['case_id'][:9]].append({'dispatch_key':entry['dispatch_key'],
            'entry_surface':{'C':'staged_cli','R':'candidate_cli','H':'owner_hook','S-check':'project_status','S-details':'project_status'}[row['surface']],
            'context':context,'eligible':enabled,'enabled':enabled,'invoked':enabled,'handler_ref':handler,
            'unavailable_reason':row['unavailable_reason'],'mutation_count':0})
    registry=write(TYPED+'registry.json',{'schema_version':1,'binary_sha256':receipt['binary_sha256'],'entries':list(entries.values())})
    results=[]
    for scenario in contract['scenarios']:
        sid=scenario['id'];selected=[r for r in rows if r['case_id'].startswith(sid)]
        visible=f'Independent actual {len(selected)} invocations; return codes {dict(collections.Counter(str(r["returncode"]) for r in selected))}; exact case-specific expected outcomes verified.'
        state='All required captures preserved exact protected before/after state and used fresh identities; no main/installed trust mutation.'
        if sid=='INFRA-S05':state+=' Eight workspace groups include exact172, real24/inventory, current-source focused45 and actual-main non-authorizing pre-review inspection. Later distinct publication delta and strict I04 remain separate.'
        observations=write(TYPED+sid+'-observations.json',{'scenario_id':sid,'source_commit':PIN,'observations':selected})
        event=write(TYPED+sid+'-events.json',{'schema_version':1,'scenario_id':sid,'producer_session':SESSION,
            'method':scenario['method'],'binary_sha256':receipt['binary_sha256'],'authority_sha256':authority,
            'inputs':scenario['inputs'],'dispatches':dispatches[sid],'actual_visible':visible,'actual_state':state})
        common=[observations,provenance,build_observation,inspection,focused,*archives]
        roles=write(TYPED+sid+'-roles.json',{'kind':'datum.workflow-delivery.artifacts/v1','scenario_id':sid,
            'events':[event],'captures':[],'state':common,'registry':registry})
        dimension={'normal':visible,'invalid':visible,'scope':state,
            'failure_recovery':'Distinct valid recoveries and exact restorations passed. Failed attempts are separately retained, not overwritten.',
            'accessibility':'Required valid/refused text-pipe cases executed with actual raw diagnostics; no native GUI accessibility claim.',
            'cancel':'Five actual observer-triggered interrupted processes returned -15 without protected-state changes, with valid recoveries.',
            'save_reopen':'Actual fresh-process recovery after refusals/interruption; no native design Save/reopen claim.'}
        defects=['dat-wdq-index-refresh-ogw']
        if sid in ('INFRA-S04','INFRA-S05'):defects.append('dat-wdq-proof-renewal-cycle-qgb')
        if sid=='INFRA-S05':defects+=['dat-wdq-workspace-inputs-zmt','dat-wdq-review-publication-cycle-a1y','dat-wdq-test-default-branch-apx']
        results.append({'scenario_id':sid,'outcome':'pass','actual_visible':visible,'actual_state':state,
            'assertions':[{'dimension':k,'expected':v['reason'],'observed':dimension[k],'outcome':'pass'} for k,v in scenario['dimensions'].items() if v['disposition']=='required'],
            'artifacts':[roles,event,registry,*common],'defects':defects})
    replay={'schema_version':1,'contract_sha256':contract_sha256(contract),'producer_session':SESSION,
        'source_commit':PIN,'input_manifest':producer['input_manifest'],'fixture':producer['fixture'],
        'environment':producer['environment'],'build':{'command':receipt['build_command'],'receipt':build,'toolchain':receipt['toolchain'],'source_clean':True},'results':results}
    replay_blob=write(TYPED+'replay.json',replay)
    trust=Trust(tree,BASE,BASE)
    item=next(i for i in tree.json('specs/active_frontier.json')['frontier'] if i['key']=='WORKFLOW-DELIVERY-IMPLEMENTATION')
    independent_of=sorted(set(trust.enrolled[item['key']]['implementation_sessions'])|{producer['producer_session']})
    findings=[{'issue_id':issue,'severity':'nonblocking' if issue.endswith('-apx') else 'blocking','disposition_ref':None} for issue in
        ['dat-wdq-index-refresh-ogw','dat-wdq-proof-renewal-cycle-qgb','dat-wdq-workspace-inputs-zmt','dat-wdq-review-publication-cycle-a1y','dat-wdq-test-default-branch-apx']]
    review={'schema_version':1,'packet_sha256':PACKET,'reviewer_session':SESSION,'independent_of':independent_of,
        'disposition':'approve','replay':replay_blob,'findings':findings,'owner_receipt':None}
    review_blob=write(contract['review_path'],review)
    validated=validate_proof(tree,contract,replay_blob['path'])
    environment=tree.json(producer['environment']['path'])
    validate_environment(tree,validated,environment,contract=contract)
    events=validate_correlations(tree,contract,validated);assert len(events)==6
    validate_independent_review(tree,contract,producer,authority,trust,item,environment)
    try:validate_defect_dispositions(tree,review,contract['review_path'],trust)
    except DeliveryInputError as error:
        assert error.code=='WDQ-DEFECT' and 'undisposed defect' in error.detail
        owner_refusal={'code':error.code,'detail':error.detail,'path':error.path}
    else:raise AssertionError('Owner disposition must remain required')
    write(TYPED+'validation.json',{'candidate':CANDIDATE,'producer_packet_sha256':PACKET,
        'replay':replay_blob,'review':review_blob,'review_sha256':review_sha256(review),
        'proof_environment_correlations_independent_review':'pass','correlated_event_blobs':len(events),
        'expected_owner_disposition_refusal':owner_refusal,'observations':1314,'pid':os.getpid(),
        'started_ns':started,'finished_ns':time.time_ns(),'helper_sha256':H(Path(__file__).read_bytes()),
        'technical_scope':'Independent review of exact producer packet and frozen runtime. Not final candidate publication or installed activation.',
        'remaining':'Later exact candidate delta/source-history inspection before RECHECK closeout and I04 presentation; five owner dispositions and strict full-evidence I04 inspection.',
        'independent_recheck_complete':False,'publication_authorized':False,'activation_performed':False})
    inventory=[{'path':p.relative_to(OUTPUT).as_posix(),'sha256':H(p.read_bytes()),'size':p.stat().st_size} for p in sorted(OUTPUT.rglob('*')) if p.is_file()]
    summary={'output':str(OUTPUT),'review':review_blob,'replay':replay_blob,'review_sha256':review_sha256(review),
        'inventory':inventory,'inventory_sha256':H(canonical_json(inventory)),'main_artifact_commit':main_pin,
        'observations':1314,'technical_review':'approve','independent_recheck_complete':False}
    with (STORE/'typed-review-attempt-01-result.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
    print(json.dumps(summary))

if __name__=='__main__':main()
