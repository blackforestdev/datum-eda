"""Preserve first schema-assumption failure; read actual producer raw identities."""
from pathlib import Path
HERE=Path(__file__).parent
source=HERE/'assemble-typed-review.py'
code=source.read_text().replace('typed-review-attempt-01','typed-review-attempt-02')
needle="    ident=lambda r:tuple(r[k] for k in fields)\n"
assert code.count(needle)==1
replacement="""    for row in original:
        path=Path(row['capture_path'])/'calls.jsonl'
        raw=path.read_bytes() if path.exists() else b''
        if row['trace_sha256'] is not None:assert H(raw)==row['trace_sha256']
        events=[json.loads(line) for line in raw.splitlines()]
        row['observer_event_ids']=[e['event_id'] for e in events]
        row['observer_invocation_ids']=sorted({e['invocation_id'] for e in events})
    ident=lambda r:tuple(r[k] for k in fields)
"""
code=code.replace(needle,replacement)
exec(compile(code,str(source)+'[schema-v2]','exec'),{'__name__':'__main__','__file__':str(source)})
