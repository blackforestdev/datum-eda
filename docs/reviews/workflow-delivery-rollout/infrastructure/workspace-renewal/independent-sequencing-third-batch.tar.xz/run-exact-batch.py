"""Run previously reviewed exact-object replay with explicit new input pins."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/bfadmin/Documents/datum-eda')
STORE = Path(__file__).parent
RUNTIME = ROOT / '.git/datum-wdq/proposals/sequencing-repair-20260910'
COUNTS = {'s01':36, 'baseline':5, 's02-coverage':110, 's02-ownership':190,
          's03':185, 's04':175, 's05-snapshots':39, 's06-selection':60,
          's06-headless':95, 's06-trust':223}
PIN = '1d48f249dc7071fc3718b345a4ab16b366af43be'

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def main():
    batch = sys.argv[1]
    count = COUNTS[batch]
    producer_name = sys.argv[2] if len(sys.argv) > 2 else 'sequencing-evidence-20260910'
    assert Path(producer_name).name == producer_name
    destination = STORE / batch
    destination.mkdir()
    prior = ROOT / '.git/datum-wdq/proposals/wdq-full-candidate-inspection-20260909/independent-recheck-index-repair-s06-trust-20260910/command.json'
    command = json.loads(prior.read_bytes())['argv']
    code = command[-1]
    code = code.replace("store=base/'independent-recheck-index-repair-s06-trust-20260910'", 'store=pathlib.Path('+repr(str(destination))+')')
    code = code.replace('index-preservation-repair-20260910','sequencing-repair-20260910')
    code = code.replace('index-repair-evidence-20260910',producer_name).replace('s06-trust',batch)
    code = code.replace('assert len(results)==223', 'assert len(results)=='+str(count))
    code = code.replace('4e11d60b6f0ec50aa391c68ed39a0df138adf8cf',PIN)
    if batch == 's01':
        code = code.replace("inventory=J(producer/'observations.json')", "inventory=J(producer/'observations-complete.json')")
    # Source-execute the independently authenticated cache isolation helper
    # before importing any adjacent repository implementation.
    bootstrap = RUNTIME / 'scripts/workflow_delivery_source_only.py'
    raw = bootstrap.read_bytes()
    expected = subprocess.check_output(['git','--no-replace-objects','show',PIN+':scripts/workflow_delivery_source_only.py'],cwd=RUNTIME)
    assert raw == expected
    prefix = 'from pathlib import Path\np=Path('+repr(str(bootstrap))+');ns={"__name__":"_review_bootstrap"};exec(compile(p.read_bytes(),str(p),"exec"),ns);ns["install"](p.parent)\n'
    command = command[:-1] + [prefix+code]
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=RUNTIME).decode().strip()==PIN
    assert not subprocess.check_output(['git','--no-optional-locks','status','--porcelain'],cwd=RUNTIME)
    env = dict(os.environ, PATH='/home/bfadmin/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:/bin:/usr/bin')
    save(destination/'command.json', {'argv':command,'cwd':str(RUNTIME),'template':str(prior),
         'template_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'producer_store':producer_name,
         'source':PIN,'bootstrap_sha256':hashlib.sha256(raw).hexdigest(),'PATH':env['PATH']})
    with (destination/'stdout.bin').open('xb') as out, (destination/'stderr.bin').open('xb') as err:
        started=time.time_ns();p=subprocess.Popen(command,cwd=RUNTIME,env=env,stdout=out,stderr=err)
        save(destination/'started.json',{'pid':p.pid,'started_ns':started})
        print(json.dumps({'batch':batch,'pid':p.pid}),flush=True)
        status=p.wait()
    save(destination/'collector-result.json',{'pid':p.pid,'started_ns':started,'ended_ns':time.time_ns(),'exit_code':status,
         **{k+'_sha256':hashlib.sha256((destination/(k+'.bin')).read_bytes()).hexdigest() for k in ('stdout','stderr')}})
    print(json.dumps({'batch':batch,'exit_code':status}),flush=True)
    raise SystemExit(status)

if __name__=='__main__':
    main()
