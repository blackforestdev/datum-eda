"""Verify independent v2 real replay against original paired observations."""
import sys
from pathlib import Path
batch=sys.argv[1]
assert len(sys.argv)==2 and batch in ('real-roadmap','current-inventory')
template=Path(__file__).with_name('verify-workspace-exact.py')
source=template.read_text()
assert source.count("'renewal-result.json'")==2
source=source.replace("'renewal-result.json'","'observations.json'")
assert source.count("batch+'-exact'")==1
source=source.replace("batch+'-exact'","batch+'-exact-v2'")
sys.argv=[str(template),batch,'owner-reopened/'+batch]
exec(compile(source,str(template)+'[real-v2]','exec'),{'__name__':'__main__'})
