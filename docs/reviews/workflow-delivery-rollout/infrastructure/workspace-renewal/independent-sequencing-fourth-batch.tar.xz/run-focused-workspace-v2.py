"""Supply only the explicit main-branch fixture precondition; retain failed v1."""
from pathlib import Path
original=Path(__file__).with_name('run-focused-workspace.py')
source=original.read_text()
replacements={
    "OUT=STORE/'focused-workspace'":"OUT=STORE/'focused-workspace-v2'",
    "OUT.mkdir()":"OUT.mkdir()\n(OUT/'gitconfig').write_bytes(b'[init]\\n\\tdefaultBranch = main\\n')\n(OUT/'gitconfig').chmod(0o600)",
    "'GIT_CONFIG_GLOBAL':os.devnull":"'GIT_CONFIG_GLOBAL':str(OUT/'gitconfig')",
    "'bootstrap_sha256':H(bootstrap.read_bytes())}":
        "'bootstrap_sha256':H(bootstrap.read_bytes()), 'fixture_gitconfig':{'path':str(OUT/'gitconfig'),'sha256':H((OUT/'gitconfig').read_bytes()),'mode':(OUT/'gitconfig').stat().st_mode & 0o777,'bytes':(OUT/'gitconfig').read_text()}, 'git_binary':{'path':'/usr/bin/git','sha256':H(Path('/usr/bin/git').read_bytes()),'version':subprocess.check_output(['/usr/bin/git','--version']).decode()}}",
    "'matrix_observation_credit':0,":"'prior_attempt':'focused-workspace retained 44 passes and one attached-main refusal; default-branch fixture portability defect is not fixed by this explicit environment.','fixture_environment':'Only reviewer-owned pinned init.defaultBranch=main; no inherited owner config or GIT_CONFIG_COUNT. Runtime Git reads retain their own sanitized environment.','matrix_observation_credit':0,",
}
for old,new in replacements.items():
    assert source.count(old)==1,old
    source=source.replace(old,new)
exec(compile(source,str(original)+'[explicit-fixture-config-v2]','exec'),{'__name__':'__main__','__file__':__file__})
