"""Account for nine original successes plus six exact retry outcomes."""
import hashlib,json,sys
from pathlib import Path
STORE=Path(__file__).parent
ROOT=Path('/home/bfadmin/Documents/datum-eda')
PRODUCER=ROOT/'.git/datum-wdq/proposals/sequencing-paired-evidence-20260910/owner-reopened/real-roadmap'
J=lambda p:json.loads(p.read_bytes())
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert J(STORE/'real-roadmap-exact-v3-process.json')['exit_code']==0
assert len(J(STORE/'real-roadmap-exact-v3/observations.json')['observations'])==6
rows=[]
for index,old in enumerate(J(PRODUCER/'observations.json')['invocations']):
    version='v2' if index<9 else 'v3'
    directory=STORE/('real-roadmap-exact-'+version)/old['capture_directory']
    row=J(directory/'independent-assessment.json')
    assert all(row[k]==old[k] for k in ('case','surface','expected_refusal','returncode'))
    assert row['exact_before_state_equal'] and row['states_unchanged']
    assert H(directory/'capture/result.json')==row['result_sha256']
    assert J(directory/'cleanup.json')['restored_owned_fixture_removed']
    rows.append(dict(row,directory=str(directory),collector_version=version))
assert len(rows)==15 and len({r['invocation_id'] for r in rows})==15
out=STORE/'real-roadmap-exact-complete';out.mkdir()
with (out/'observations.json').open('x') as f:
    json.dump({'candidate':'1d48f249dc7071fc3718b345a4ab16b366af43be','observations':rows,
        'prior_successes':9,'remaining_exact_retry_successes':6,
        'preserved_timeout':str(STORE/'real-roadmap-exact-v2/mixed-unknown-source-H/capture/result.json'),
        'timeout_cause':'Undetermined; original180s retained for all attempts.',
        'raw_directories':'References point to actual original capture directories; no copied or manufactured process observations.',
        'independent_recheck_complete':False,'activation_performed':False},f,indent=2);f.write('\n')
template=STORE/'verify-workspace-exact.py';source=template.read_text()
assert source.count("'renewal-result.json'")==2
source=source.replace("'renewal-result.json'","'observations.json'")
assert source.count("batch+'-exact'")==1
source=source.replace("batch+'-exact'","batch+'-exact-complete'")
source=source.replace('expected refusal/recovery assertions passed, no retries.','expected refusal/recovery assertions passed: nine original successes plus six exact-input retry results; the first180s hook timeout is preserved separately.')
sys.argv=[str(template),'real-roadmap','owner-reopened/real-roadmap']
exec(compile(source,str(template)+'[real-nine-plus-six]','exec'),{'__name__':'__main__'})
