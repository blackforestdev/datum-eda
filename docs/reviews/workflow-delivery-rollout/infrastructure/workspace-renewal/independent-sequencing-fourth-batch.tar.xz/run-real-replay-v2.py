"""Record a distinct collector version; preserve all first-attempt outputs."""
from pathlib import Path
original=Path(__file__).with_name('run-real-replay.py')
source=original.read_text()
assert source.count("'replay-real-prestates.py'")==1
source=source.replace("'replay-real-prestates.py'","'replay-real-prestates-v2.py'")
source=source.replace("batch+'-exact-","batch+'-exact-v2-")
exec(compile(source,str(original)+'[v2]','exec'),{'__name__':'__main__','__file__':str(original)})
