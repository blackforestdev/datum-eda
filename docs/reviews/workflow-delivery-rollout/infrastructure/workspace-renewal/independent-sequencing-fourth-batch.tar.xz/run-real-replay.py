"""Record actual independent real replay process and preserve failures."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
store=Path(__file__).parent
batch=sys.argv[1]
assert len(sys.argv)==2 and batch in ('real-roadmap','current-inventory')
def save(name,value):
    with (store/name).open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
helper=store/'replay-real-prestates.py'
command=[sys.executable,'-I','-S','-B',str(helper),batch]
save(batch+'-exact-command.json',{'command':command,'cwd':str(Path.cwd()),
    'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),
    'scope':'Independent execution; original absolute fixture custody and complete pre-state equality required.'})
with (store/(batch+'-exact-stdout.bin')).open('xb') as out,(store/(batch+'-exact-stderr.bin')).open('xb') as err:
    started=time.time_ns();process=subprocess.Popen(command,stdout=out,stderr=err)
    save(batch+'-exact-started.json',{'pid':process.pid,'started_ns':started})
    print(json.dumps({'batch':batch,'pid':process.pid}),flush=True)
    code=process.wait()
save(batch+'-exact-process.json',{'pid':process.pid,'started_ns':started,'ended_ns':time.time_ns(),'exit_code':code,
    'stdout_sha256':hashlib.sha256((store/(batch+'-exact-stdout.bin')).read_bytes()).hexdigest(),
    'stderr_sha256':hashlib.sha256((store/(batch+'-exact-stderr.bin')).read_bytes()).hexdigest()})
print(json.dumps({'batch':batch,'exit_code':code}),flush=True)
raise SystemExit(code)
