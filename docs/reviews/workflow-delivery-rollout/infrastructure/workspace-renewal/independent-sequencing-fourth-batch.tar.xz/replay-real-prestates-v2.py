"""Preserve clone failure; fetch the bundle's explicit non-head source refs."""
from pathlib import Path
original=Path(__file__).with_name('replay-real-prestates.py')
source=original.read_text()
old="own=STORE/(batch+'-exact')"
assert source.count(old)==1
source=source.replace(old,"own=STORE/(batch+'-exact-v2')")
old="git_seed('clone','--no-checkout',str(BUNDLE),str(seed))"
assert source.count(old)==1
new="""request=J(BUNDLE.with_name('request.json'))
heads={line.split()[1]:line.split()[0] for line in git_seed('bundle','list-heads',str(BUNDLE)).decode().splitlines()}
assert heads[request['source_ref']]==request['source_commit']
assert all(heads[ref]==oid for ref,oid in request['evidence_refs'].items())
git_seed('init','--quiet',str(seed))
git_seed('-C',str(seed),'fetch','--quiet','--no-tags',str(BUNDLE),request['source_ref'],*sorted(request['evidence_refs']))
save(own/'explicit-bundle-fetch.json',{'request_sha256':H(BUNDLE.with_name('request.json').read_bytes()),'bundle_sha256':BUNDLE_SHA,'heads':heads,'source_ref':request['source_ref'],'evidence_refs':request['evidence_refs'],'reason':'Plain clone did not import non-head refs. This attempt fetches the same explicitly recorded bundle refs; no external object source or regenerated commit.'})"""
source=source.replace(old,new)
exec(compile(source,str(original)+'[explicit-bundle-refs-v2]','exec'),{'__name__':'__main__','__file__':str(original)})
