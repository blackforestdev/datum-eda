"""Preserve the exact failed owned restoration and release its original path."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
STORE=Path(__file__).parent
ROOT=Path('/home/bfadmin/Documents/datum-eda')
RUNTIME=ROOT/'.git/datum-wdq/proposals/sequencing-repair-20260910'
CAP=STORE/'real-roadmap-exact-v2/mixed-unknown-source-H/capture'
fixture=ROOT/'.git/datum-wdq/proposals/sequencing-paired-evidence-20260910/owner-reopened/real-roadmap/fixture'
destination=STORE/'real-roadmap-failed-timeout-fixture'
J=lambda p:json.loads(p.read_bytes())
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result,inv=J(CAP/'result.json'),J(CAP/'invocation.json')
assert result['invocation_id']=='1331918b-8f21-444e-894a-3b4dcde1f5b1'
assert result['kind']=='timeout' and result['returncode']==-15 and inv['timeout_seconds']==180
assert not result['changed_files'] and not result['changed_state_fields']
assert Path(inv['cwd'])==fixture and not fixture.is_symlink()
assert not destination.exists() and not destination.is_symlink()
try:os.killpg(result['pid'],0)
except ProcessLookupError:pass
else:raise AssertionError('Failed process group still observed; no fixture move permitted')
handles=subprocess.run(['lsof','+D',str(fixture)],capture_output=True)
assert handles.returncode==1 and not handles.stdout and not handles.stderr
bootstrap=RUNTIME/'scripts/workflow_delivery_source_only.py'
ns={'__name__':'_review_source_bootstrap'};exec(compile(bootstrap.read_bytes(),str(bootstrap),'exec'),ns);ns['install'](bootstrap.parent)
sys.path.insert(0,str(bootstrap.parent))
from workflow_delivery_capture_state import protected_state
expected=J(CAP/'after.json')
actual=protected_state(fixture,expected['untracked_roots'])
assert actual==expected
marker=fixture/'.git/datum-wdq-capture-owner'
assert not marker.is_symlink() and marker.read_text().strip()==inv['fixture_nonce']
os.rename(fixture,destination)
value={'invocation_id':result['invocation_id'],'result_sha256':H(CAP/'result.json'),
    'before_sha256':H(CAP/'before.json'),'after_sha256':H(CAP/'after.json'),
    'actual_failed_fixture_matches_recorded_after':True,'process_group_absent':True,
    'open_handle_check':{'argv':['lsof','+D',str(fixture)],'exit_code':handles.returncode,'stdout':'','stderr':''},
    'original_path':str(fixture),'retired_path':str(destination),'retired_ns':time.time_ns(),
    'source_or_timeout_changed':False,'cause':'Undetermined; no attribution to a later verifier whose start followed the timeout finish.',
    'scope':'Only reviewer-owned failed restoration moved recoverably. Producer retired fixture and all original captures unchanged. Remaining six must restore exact original pre-states anew.',
    'activation_performed':False}
with (STORE/'real-roadmap-timeout-retirement.json').open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(value))
