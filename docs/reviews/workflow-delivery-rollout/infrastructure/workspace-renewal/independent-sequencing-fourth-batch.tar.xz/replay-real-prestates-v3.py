"""Resume only the six cases remaining after the preserved hook timeout."""
from pathlib import Path
original=Path(__file__).with_name('replay-real-prestates-v2.py')
source=original.read_text()
assert source.count("own=STORE/(batch+'-exact-v2')")==1
source=source.replace("own=STORE/(batch+'-exact-v2')","own=STORE/(batch+'-exact-v3')")
needle="exec(compile(source,str(original)+'[explicit-bundle-refs-v2]','exec'),{'__name__':'__main__','__file__':str(original)})"
assert source.count(needle)==1
replacement="""needle="assert len(rows)==(15 if batch=='real-roadmap' else 9)"
assert source.count(needle)==1
source=source.replace(needle,needle+'''\nassert batch=='real-roadmap'
prior=STORE/'real-roadmap-exact-v2'
assert J(STORE/'real-roadmap-exact-v2-process.json')['exit_code']==1
assert J(prior/'mixed-unknown-source-H/capture/result.json')['kind']=='timeout'
for saved in rows[:9]:
    assessment=J(prior/saved['capture_directory']/'independent-assessment.json')
    assert assessment['exact_before_state_equal'] and assessment['states_unchanged']
    assert assessment['returncode']==saved['returncode']
rows=rows[9:]
assert len(rows)==6 and rows[0]['capture_directory']=='mixed-unknown-source-H'
''')
exec(compile(source,str(original)+'[remaining-six-v3]','exec'),{'__name__':'__main__','__file__':str(original)})"""
source=source.replace(needle,replacement)
exec(compile(source,str(original)+'[v3-wrapper]','exec'),{'__name__':'__main__','__file__':str(original)})
