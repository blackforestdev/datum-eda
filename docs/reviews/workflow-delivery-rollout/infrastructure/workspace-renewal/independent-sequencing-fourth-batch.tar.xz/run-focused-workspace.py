"""Current-source independent regression supplement; not matrix observations."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
STORE=Path(__file__).parent
RUNTIME=Path('/home/bfadmin/Documents/datum-eda/.git/datum-wdq/proposals/sequencing-repair-20260910')
PIN='1d48f249dc7071fc3718b345a4ab16b366af43be'
OUT=STORE/'focused-workspace'
MODULES=['test_workflow_delivery_workspace','test_workflow_delivery_workspace_authority',
         'test_workflow_delivery_workspace_consumers','test_workflow_delivery_workspace_entrypoints']
H=lambda b:hashlib.sha256(b).hexdigest()
def save(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
bootstrap=RUNTIME/'scripts/workflow_delivery_source_only.py'
ns={'__name__':'_review_source_bootstrap'};exec(compile(bootstrap.read_bytes(),str(bootstrap),'exec'),ns);ns['install'](bootstrap.parent)
sys.path.insert(0,str(bootstrap.parent))
if sys.argv[1:]==['--child']:
    import unittest
    suite=unittest.defaultTestLoader.loadTestsFromNames(MODULES)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    loaded=[]
    for name,module in sorted(sys.modules.items()):
        path=getattr(module,'__file__',None)
        if path and Path(path).is_relative_to(RUNTIME/'scripts'):
            p=Path(path);assert p.suffix=='.py';loaded.append({'module':name,'path':p.relative_to(RUNTIME).as_posix(),'sha256':H(p.read_bytes())})
    save('child-observation.json',{'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skipped':len(result.skipped),'success':result.wasSuccessful(),'loaded_repository_sources':loaded,
        'source_only_bootstrap_sha256':H(bootstrap.read_bytes()),
        'scope':'Loaded repository Python modules observed after focused tests. Not exhaustive stdlib/shared-library or descendant tracing.'})
    raise SystemExit(not result.wasSuccessful())
assert len(sys.argv)==1
OUT.mkdir()
from workflow_delivery_tree import Tree
def identities():
    head=subprocess.check_output(['git','--no-optional-locks','rev-parse','HEAD'],cwd=RUNTIME).decode().strip()
    status=subprocess.check_output(['git','--no-optional-locks','status','--porcelain'],cwd=RUNTIME)
    assert head==PIN and not status
    tree=Tree(RUNTIME,revision=PIN);contract=tree.json('specs/workflow_delivery/rollout.contract.json')
    expected=tree.manifest(contract['input_roots']);actual=Tree(RUNTIME).manifest(contract['input_roots'])
    assert expected==actual and len(actual)==164
    return {'source_commit':head,'input_manifest':actual,'test_sources':{n:H((RUNTIME/'scripts'/(n+'.py')).read_bytes()) for n in MODULES},
        'interpreter':{'path':str(Path(sys.executable).resolve()),'sha256':H(Path(sys.executable).read_bytes()),'version':sys.version},
        'bootstrap_sha256':H(bootstrap.read_bytes())}
before=identities();save('before.json',before)
environment={**os.environ,'HOME':str(OUT),'XDG_CONFIG_HOME':str(OUT),'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':os.devnull,'LANG':'C',
    'PATH':'/home/bfadmin/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:/bin:/usr/bin'}
command=[sys.executable,'-I','-S','-B',str(Path(__file__).resolve()),'--child']
save('command.json',{'argv':command,'cwd':str(RUNTIME),'environment':{k:environment[k] for k in ('HOME','XDG_CONFIG_HOME','GIT_CONFIG_NOSYSTEM','GIT_CONFIG_GLOBAL','LANG','PATH')},'helper_sha256':H(Path(__file__).read_bytes())})
with (OUT/'stdout.bin').open('xb') as stdout,(OUT/'stderr.bin').open('xb') as stderr:
    started=time.time_ns();process=subprocess.Popen(command,cwd=RUNTIME,env=environment,stdout=stdout,stderr=stderr)
    save('started.json',{'pid':process.pid,'started_ns':started})
    print(json.dumps({'pid':process.pid}),flush=True)
    code=process.wait()
save('process.json',{'pid':process.pid,'started_ns':started,'ended_ns':time.time_ns(),'exit_code':code,
    'stdout_sha256':H((OUT/'stdout.bin').read_bytes()),'stderr_sha256':H((OUT/'stderr.bin').read_bytes())})
after=identities();save('after.json',after)
assert before==after
child=json.loads((OUT/'child-observation.json').read_bytes())
tree=Tree(RUNTIME,revision=PIN)
assert all(H(tree.read(row['path']))==row['sha256'] for row in child['loaded_repository_sources'])
assert code==0 and child['success'] and child['tests_run']==45 and not child['skipped']
save('verification.json',{'reviewer_session':'wdq-independent-review-20260906','source_commit':PIN,'tests':45,
    'source_inputs':164,'input_and_interpreter_before_after_equal':True,'loaded_source_hashes_match_revision':True,
    'groups':'Focused supplement for workspace authority/startup, captured bad/missing state, proof retention and actual preflight CLI.',
    'matrix_observation_credit':0,'independent_recheck_complete':False,'activation_performed':False})
print(json.dumps({'tests':45,'exit_code':code,'scope':'Focused regression supplement only'}),flush=True)
