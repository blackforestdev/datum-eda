"""Independently validate the exact evidence candidate, without publication."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/bfadmin/Documents/datum-eda')
STORE=Path(__file__).parent
RUNTIME=ROOT/'.git/datum-wdq/proposals/sequencing-repair-20260910'
PIN='1d48f249dc7071fc3718b345a4ab16b366af43be'
CANDIDATE='06bafeb9979dce91ab710bfaaff7f8f9ca3e72f2'
BASE='377323b29705ccccd6f8fa91f663d7d91c6d03c4'
PACKET='fa0b802e11d5dc266f7f3e78bde8a1ac91ac6c1ae4165df8858b56b94c158fee'
AUTHORITY='b3130c9322932a9d26e967d6ecb55c8b1591892636d26ac3cdd98e175475ee39'
PREFIX='docs/reviews/workflow-delivery-rollout/infrastructure/workspace-renewal/'
H=lambda raw:hashlib.sha256(raw).hexdigest()
bootstrap=RUNTIME/'scripts/workflow_delivery_source_only.py'
ns={'__name__':'_review_source_bootstrap'};exec(compile(bootstrap.read_bytes(),str(bootstrap),'exec'),ns);ns['install'](bootstrap.parent)
sys.path.insert(0,str(bootstrap.parent))
from workflow_delivery_tree import Tree
from workflow_delivery_authority import authority_sha256
from workflow_delivery_proof import validate_proof,packet_sha256
from workflow_delivery_native import validate_environment,validate_correlations
def git(*args):
    return subprocess.check_output(['git','--no-replace-objects','--no-optional-locks',*args],cwd=ROOT)
started=time.time_ns()
tree,base,source=Tree(ROOT,revision=CANDIDATE),Tree(ROOT,revision=BASE),Tree(ROOT,revision=PIN)
assert git('show','-s','--format=%P',CANDIDATE).decode().strip()==BASE
paths=git('diff','--name-only','-z',BASE,CANDIDATE).decode().split('\0')
paths=[p for p in paths if p]
assert all(p.startswith(PREFIX) or p in ('.beads/issues.jsonl','docs/reviews/workflow-delivery-rollout/infrastructure/proof.json') for p in paths)
assert tree.read('specs/active_frontier.json')==base.read('specs/active_frontier.json')
assert tree.read('specs/PROGRESS.md')==base.read('specs/PROGRESS.md')
prior=base.read('.beads/issues.jsonl');current=tree.read('.beads/issues.jsonl')
assert current.startswith(prior)
added=current[len(prior):].splitlines();assert len(added)==1
issue=json.loads(added[0]);assert issue['id']=='dat-wdq-test-default-branch-apx' and issue['status']=='open'
assert added[0] in git('show','27df01fa:.beads/issues.jsonl').splitlines()
contract=tree.json('specs/workflow_delivery/rollout.contract.json')
manifest=tree.manifest(contract['input_roots'])
assert len(manifest)==164 and manifest==source.manifest(contract['input_roots'])
authority=authority_sha256(tree,contract)
assert authority==AUTHORITY and authority==authority_sha256(source,contract)
proof=validate_proof(tree,contract)
selection=tree.json('specs/workflow_delivery/rollout.environments.json')
selected=[r['environment'] for r in selection['environments'] if r['frontier_key']=='WORKFLOW-DELIVERY-IMPLEMENTATION']
assert selected==[proof['environment']]
environment=tree.json(proof['environment']['path'])
validate_environment(tree,proof,environment,contract=contract)
events=validate_correlations(tree,contract,proof)
assert len(events)==6 and packet_sha256(contract,proof,authority)==PACKET
value={'reviewer_session':'wdq-independent-review-20260906','candidate':CANDIDATE,'parent':BASE,'runtime':PIN,
    'packet_sha256':PACKET,'authority_sha256':authority,'input_count':len(manifest),
    'input_manifest_matches_frozen_source':True,'proof_environment_correlations':'pass','correlated_event_blobs':len(events),
    'changed_paths':paths,'frontier_and_projection_unchanged_from_prospective_baseline':True,
    'beads_delta':'Exact single committed open dat-wdq-test-default-branch-apx row; every baseline byte preserved.',
    'pid':os.getpid(),'argv':sys.argv,'python_flags':{'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.flags.dont_write_bytecode},
    'started_ns':started,'finished_ns':time.time_ns(),'helper_sha256':H(Path(__file__).read_bytes()),
    'scope':'Read-only independent validation of evidence candidate. This is not an actual-main publication delta or installed startup/activation approval.',
    'independent_recheck_complete':False,'activation_performed':False}
with (STORE/'producer-target-independent-verification.json').open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in value.items() if k!='changed_paths'}))
