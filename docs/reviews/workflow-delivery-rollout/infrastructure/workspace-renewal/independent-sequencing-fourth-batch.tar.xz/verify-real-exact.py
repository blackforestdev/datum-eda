"""Apply the inspected artifact verifier to the real observation record shape."""
import sys
from pathlib import Path
batch=sys.argv[1]
assert len(sys.argv)==2 and batch in ('real-roadmap','current-inventory')
template=Path(__file__).with_name('verify-workspace-exact.py')
source=template.read_text()
assert source.count("'renewal-result.json'")==2
source=source.replace("'renewal-result.json'","'observations.json'")
sys.argv=[str(template),batch,'owner-reopened/'+batch]
exec(compile(source,str(template)+'[real-observations-shape]','exec'),{'__name__':'__main__'})
