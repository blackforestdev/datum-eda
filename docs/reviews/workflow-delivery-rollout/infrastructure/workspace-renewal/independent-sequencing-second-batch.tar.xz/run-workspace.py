"""Fresh independent execution of the three retained synthetic workspace recipes."""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys
import time

ROOT=Path('/home/bfadmin/Documents/datum-eda')
STORE=Path(__file__).parent
RUNTIME=ROOT/'.git/datum-wdq/proposals/sequencing-repair-20260910'
PIN='1d48f249dc7071fc3718b345a4ab16b366af43be'

def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')

for batch in ('runtime','policy-legacy','proof-input'):
    name='workspace-'+batch
    record=ROOT/('docs/reviews/workflow-delivery-rollout/infrastructure/workspace-renewal/renewed-'+name+'-observation.json')
    original=shlex.split(json.loads(record.read_bytes())['command'])
    assert original[:5]==['python3','-I','-S','-B','-c'] and len(original)==6
    old=ROOT/('.git/datum-wdq/proposals/wdq-full-candidate-inspection-20260909/renewed-'+name+'-entrypoints-0e5b8064')
    destination=STORE/name
    code=original[-1]
    assert code.count(str(old))==1 and code.count('0e5b8064a9faca407fac43bd2b362ba4d7200327')==1
    code=code.replace(str(old),str(destination)).replace('0e5b8064a9faca407fac43bd2b362ba4d7200327',PIN)
    bootstrap=RUNTIME/'scripts/workflow_delivery_source_only.py'
    assert bootstrap.read_bytes()==subprocess.check_output(['git','show',PIN+':scripts/workflow_delivery_source_only.py'],cwd=RUNTIME)
    prefix='import tempfile\nfrom pathlib import Path\ntempfile.tempdir='+repr(str(STORE))+'\np=Path('+repr(str(bootstrap))+');ns={"__name__":"_review_bootstrap"};exec(compile(p.read_bytes(),str(p),"exec"),ns);ns["install"](p.parent)\n'
    command=original[:-1]+[prefix+code]
    save(STORE/(name+'-command.json'),{'argv':command,'cwd':str(RUNTIME),'record':str(record),
         'record_sha256':hashlib.sha256(record.read_bytes()).hexdigest(),
         'scope':'Fresh synthetic recipe histories, not copies of producer post-setup objects; temporary fixtures remain within the owned store.'})
    with (STORE/(name+'-stdout.bin')).open('xb') as out,(STORE/(name+'-stderr.bin')).open('xb') as err:
        started=time.time_ns();p=subprocess.Popen(command,cwd=RUNTIME,stdout=out,stderr=err)
        save(STORE/(name+'-started.json'),{'pid':p.pid,'started_ns':started})
        print(json.dumps({'batch':name,'pid':p.pid}),flush=True);status=p.wait()
    save(STORE/(name+'-process.json'),{'pid':p.pid,'started_ns':started,'ended_ns':time.time_ns(),'exit_code':status,
         **{k+'_sha256':hashlib.sha256((STORE/(name+'-'+k+'.bin')).read_bytes()).hexdigest() for k in ('stdout','stderr')}})
    print(json.dumps({'batch':name,'exit_code':status}),flush=True)
    if status:raise SystemExit(status)
