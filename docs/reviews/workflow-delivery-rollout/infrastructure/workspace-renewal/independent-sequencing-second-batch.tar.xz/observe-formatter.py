"""Observe the actual selected formatter before/after independent Rust-H cases."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
p=Path('/home/bfadmin/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt')
raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest()
assert digest=='c7d4d911e75fa66321fd04ac81cf6ea1b3a2c759efe39e61caccb10f3c850918'
command=[str(p),'--version'];start=time.time_ns();r=subprocess.run(command,capture_output=True,check=True)
assert p.read_bytes()==raw
value={'path':str(p),'resolved_path':str(p.resolve()),'sha256':digest,'size':len(raw),
       'command':command,'version_stdout':r.stdout.decode(),'version_stderr':r.stderr.decode(),
       'started_ns':start,'finished_ns':time.time_ns(),'exit_code':r.returncode}
with Path(__file__).with_name('formatter-'+sys.argv[1]+'.json').open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(value))
