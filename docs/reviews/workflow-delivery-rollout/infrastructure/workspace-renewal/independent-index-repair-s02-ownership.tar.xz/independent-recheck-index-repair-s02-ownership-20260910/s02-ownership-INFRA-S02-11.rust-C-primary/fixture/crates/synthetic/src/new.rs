// Actual synthetic Rust source, never compiled.
pub fn fixture() {}
