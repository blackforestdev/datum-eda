def read(path):
    return path.read_bytes()
