Fixture-only requirement, not native EDA evidence.
