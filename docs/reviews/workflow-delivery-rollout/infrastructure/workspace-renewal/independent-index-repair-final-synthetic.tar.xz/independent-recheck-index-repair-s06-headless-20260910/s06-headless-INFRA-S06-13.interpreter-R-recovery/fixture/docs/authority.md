<!-- RULE -->
Read-only fixture authority.
