<!-- ACTIVE FRONTIER:START -->
> Generated from `specs/active_frontier.json` by `scripts/project_status.py`; do not hand-edit.

- **Accepted fixture** (`TASK`; `dat-test`).
   Synthetic accepted history *state `landed`; authorization `none`.*
   *Dependencies:* none. *Unblocks:* none. *Governing:* `docs/decisions/PRODUCT_MECHANICS_025_FIXTURE.md`.
- **Align project state** (`NEXT`; `dat-next`).
   Make every agent return the same next task. *state `specified`; authorization `planning`; **CANONICAL NEXT**.*
   *Dependencies:* none. *Unblocks:* none. *Governing:* `docs/decisions/PRODUCT_MECHANICS_025_FIXTURE.md`.
   *Completion plan:* `python3 scripts/project_status.py details`.
- **Synthetic headless infrastructure history** (`INFRA`; `dat-infra`).
   Synthetic accepted history *state `landed`; authorization `none`.*
   *Dependencies:* none. *Unblocks:* none. *Governing:* `docs/decisions/PRODUCT_MECHANICS_025_FIXTURE.md`.
<!-- ACTIVE FRONTIER:END -->
