#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cargo_guard=(python3 "$repo_root/scripts/run_cargo_guarded.py" --workload proof --)
cd "$repo_root"

# PM041 bootstrap: hermetic refusal mechanics and non-accepting diagnostics.
# Trusted authority/base configuration and enforcement remain an owner G06 step.
python3 -m unittest discover -s scripts -p 'test_workflow_delivery_*.py'
python3 scripts/check_workflow_delivery.py --report-only

python3 scripts/test_cargo_resource_policy.py
python3 scripts/check_cargo_resource_policy.py

echo "== rustfmt: workspace formatting gate =="
python3 scripts/test_rustfmt_gate.py
python3 scripts/check_rustfmt.py

echo "== clippy: workspace lint gate (-D warnings) =="
"${cargo_guard[@]}" cargo clippy --workspace --all-targets -- -D warnings

python3 scripts/check_progress_coverage.py
python3 scripts/test_project_status.py
python3 scripts/test_project_status_claim.py
python3 scripts/project_status.py check
python3 scripts/check_spec_parity.py
python3 scripts/check_alignment.py --run-gates
python3 scripts/check_spec_governance.py
python3 scripts/check_project_preferences_tripwire.py
python3 scripts/check_evidence_traceability.py
python3 scripts/test_dependency_authority.py
python3 scripts/check_dependency_authority.py
python3 scripts/check_resolver_raw_loads.py
python3 scripts/check_global_preferences_boundary.py
python3 scripts/test_gui_agent_terminal_convergence.py
python3 scripts/check_gui_agent_terminal_convergence.py
python3 scripts/test_terminal_shell_metadata_boundary.py
python3 scripts/check_terminal_shell_metadata_boundary.py
python3 scripts/test_terminal_split_boundary.py
python3 scripts/check_terminal_split_boundary.py
python3 scripts/test_terminal_transport_boundary.py
python3 scripts/check_terminal_transport_boundary.py
python3 scripts/test_terminal_core_boundary.py
python3 scripts/check_terminal_core_boundary.py
python3 scripts/test_terminal_core_adapter_boundary.py
python3 scripts/check_terminal_core_adapter_boundary.py
python3 scripts/test_terminal_compatibility_matrix.py
python3 scripts/check_terminal_compatibility_matrix.py
python3 scripts/test_terminal_core_renderer_boundary.py
python3 scripts/check_terminal_core_renderer_boundary.py
python3 scripts/test_terminal_native_interaction.py
python3 scripts/check_terminal_native_interaction.py
python3 scripts/test_terminal_kitty_boundary.py
python3 scripts/check_terminal_kitty_boundary.py
python3 scripts/test_terminal_snapshot_boundary.py
python3 scripts/check_terminal_snapshot_boundary.py
python3 scripts/test_terminal_core_proof.py
python3 scripts/check_terminal_core_proof.py
python3 scripts/run_terminal_core_proof.py
python3 scripts/check_gui_design_tokens.py
python3 scripts/check_gui_conformance.py
# check_gui_conformance.py runs the composed-shell visual-parity gate
# (scripts/check_gui_visual_parity.py) as one of its aggregate gates: it captures
# the running app at the canonical command and fails on any regression from the
# owner-approved shell golden. It is invoked there (not a second time here) to
# avoid a duplicate cargo build+capture.
python3 scripts/check_gui_icon_assets.py
# Honest reference-capture gate: FAILS while the board-editor reference image
# docs/gui/reference/board-editor.png is missing or its *.PENDING placeholder
# exists. It is EXPECTED to be RED until the owner captures the reference on a
# machine with a working headless browser — that red is the honest signal that
# the full board-editor.html composition (split view, populated inspector) has no
# owner-approved reference yet and is gated on Phase-2, not a bug to silence.
python3 scripts/check_gui_reference_capture.py
# Decision-022 source health: hermetic checker regressions first, then the full
# tracked+untracked repository scan. CI supplies the trusted PR/push base SHA so
# legacy ceilings and policy can only ratchet downward; local runs still enforce
# current-tree discovery, normal budgets, exact ceilings, and logical includes.
python3 scripts/test_source_health_governance.py
if [[ -n "${SOURCE_HEALTH_BASE_REF:-}" ]]; then
  python3 scripts/check_source_health.py --base-ref "$SOURCE_HEALTH_BASE_REF"
else
  python3 scripts/check_source_health.py
fi
python3 scripts/check_menu_model.py
python3 scripts/menu_model_csv.py check
python3 scripts/check_erc_connectivity_parity.py
python3 scripts/check_pcb_layout_tool_matrix.py
python3 scripts/check_schematic_private_writers.py
python3 scripts/check_daemon_write_parity.py
python3 scripts/check_mcp_public_taxonomy.py
python3 -m unittest discover -s mcp-server -p 'test_context_revision_fence.py'
python3 -m unittest discover -s mcp-server -p 'test_agent_capability.py'
python3 -m unittest discover -s mcp-server -p 'test_agent_session_authority.py'
python3 -m unittest discover -s mcp-server -p 'test_workflow_catalog.py'
python3 scripts/test_agent_workflow_parity.py
python3 scripts/check_agent_workflow_parity.py
"${cargo_guard[@]}" cargo run -q -p datum-verb-registry --bin datum-verb-catalog -- --check
bash scripts/run_migration_proof_gates.sh
python3 scripts/check_cli_module_coverage.py
python3 mcp-server/server.py --self-test
