Unreconciled synthetic readiness source.
