"""Preserve draft attempt one; add proper source-only startup and new finding."""

from pathlib import Path

HERE = Path(__file__).resolve().parent
RUNTIME = HERE.parents[1] / 'index-preservation-repair-20260910'
# HERE is under main proposals/full-candidate-inspection; resolve explicitly.
RUNTIME = Path('/home/bfadmin/Documents/datum-eda/.git/datum-wdq/proposals/index-preservation-repair-20260910')
bootstrap = RUNTIME / 'scripts/workflow_delivery_source_only.py'
namespace = {'__name__': '_datum_source_bootstrap'}
exec(compile(bootstrap.read_bytes(), str(bootstrap), 'exec'), namespace)
namespace['install'](bootstrap.parent)

source = HERE / 'assemble_independent_index_repair_draft.py'
code = source.read_text()
replacements = {
    "'index-repair-independent-draft-20260910'": "'index-repair-independent-draft-v2-20260910'",
    "'index-repair-independent-draft/'": "'index-repair-independent-draft-v2/'",
    "its three open defects.": "its three original current defects or the new inspection-sequencing defect.",
    "if sid == 'INFRA-S05': defects.append('dat-wdq-workspace-inputs-zmt')":
        "if sid == 'INFRA-S05': defects.extend(['dat-wdq-workspace-inputs-zmt', 'dat-wdq-review-publication-cycle-a1y'])",
    "('dat-wdq-index-refresh-ogw','dat-wdq-proof-renewal-cycle-qgb','dat-wdq-workspace-inputs-zmt')":
        "('dat-wdq-index-refresh-ogw','dat-wdq-proof-renewal-cycle-qgb','dat-wdq-workspace-inputs-zmt','dat-wdq-review-publication-cycle-a1y')",
    "'full_review_complete': False, 'activation_performed': False})":
        "'new_finding_absent_from_candidate_beads': 'dat-wdq-review-publication-cycle-a1y', "
        "'ordering_blocker': 'Publication inspection requires completed RECHECK and claim-free I04, but RECHECK requires that inspection first. Owner-approved sequencing reconciliation is necessary; no fabricated completion permitted.', "
        "'prior_attempt': 'Draft v1 reached shape/environment/correlation and expected incomplete-proof refusal, then Trust correctly refused missing verified source-only startup. V1 bytes remain unchanged.', "
        "'full_review_complete': False, 'activation_performed': False})",
}
for before, after in replacements.items():
    assert code.count(before) == 1, before
    code = code.replace(before, after)
exec(compile(code, str(source) + ':draft-v2', 'exec'), {'__name__': '__main__', '__file__': str(source)})
