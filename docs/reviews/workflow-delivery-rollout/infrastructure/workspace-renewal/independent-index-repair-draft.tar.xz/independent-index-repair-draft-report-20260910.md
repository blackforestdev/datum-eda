# Independent replay draft — revise, not approved

Reviewer session: `wdq-independent-review-20260906`. The reviewer authored neither
the production repair nor the original producer proof. This record packages
actual retained reviewer execution; it does not approve owner disposition,
complete WDQ-RECHECK, or authorize activation.

## Exact evidence

Runtime: `4e11d60b6f0ec50aa391c68ed39a0df138adf8cf`.
Reviewed post-closeout candidate: `facf48f8617546c7a711d3b45be0700979a36df6`.
Producer packet: `02ce61ee28c450776a575330ce17aca93f2a8e4edc7e4c704cf299efd69cc8ce`.
Independent draft replay: `63b1128290ea452dd5333ffac0caf7b0ab09855667dbda2fe314133ca9d231cf`.
Independent review file: `a949aeb8d5052231f27bc3a0041cf693d1c7736109c2bde931a0933a8e044c2d`.

The draft binds 1,314 actual independent invocations: the complete original
1,123-case/surface/phase multiset and 191 additional workspace observations.
Raw process timestamps are retained, including captures before producer closeout;
no timestamp is represented as a later execution. All observed expected outcomes
and protected-state checks passed. The new-source independent build repeated
the actual 148-module command with the exact 161-input manifest, toolchain and
interpreter identity. The input and common reviewed fixture Blob hashes equal
the producer's; this does not mean the independent events are producer events.

Original matrix fixtures were exact retained post-setup copies, with documented
local path and capture-nonce relocation. The additional synthetic 172 cases used
explicitly authorized fresh setup histories. The real 24 restored exact
owner-approved fixture `ba318df013ca5c0263c489a9c77187dc4057a7be`. Its 456-path
inventory records actual current Beads bytes and explicitly regenerated derived
caches, not fictitious equality with the earlier historical inventory.

The v2 virtual tree is `index-repair-independent-draft-v2-20260910`. It contains
the canonical review-path draft plus separately named replay, registry, six
event/observation/role sets, provenance, build receipt/process and retained raw
archive references. Twenty-seven not-applicable dimension dispositions remain
enumerated with their original reasons and authority references.

## Actual validator outcomes

- Proof and review shapes, exact selected environment, and six typed correlation
  blobs validate. Producer and reviewer correlated identities are disjoint.
- Full proof validation refuses `WDQ-RESULT` at INFRA-S05: required scenario not
  passing. S05 outcome and scope assertion intentionally remain `unverified`.
- Independent review validation refuses `WDQ-REVIEW`: independent review has not
  approved. The formal disposition is `revise`, not a provisional `approve`.
- Four findings are blocking with null disposition references; owner receipt is
  null. The candidate predates the fourth issue's tracker export, an additional
  prerequisite for eventual complete review validation.

## Blocking ordering defect

`dat-wdq-review-publication-cycle-a1y` is unresolved. The execution plan's
WDQ-RECHECK section requires exact-publication inspection before presenting I04;
INFRA-S05 workspace group 8 includes that inspection. But
`workflow_delivery_activation_preflight.py` lines 22–56 require both publication
views to select claim-free I04 and require RECHECK already complete before the
inspection proceeds. A fabricated complete checkpoint or unqualified approve
would hide the missing required observation.

The owner must reconcile this ordering explicitly in the controlling plan and
inspection boundary: distinguish a non-authorizing pre-completion inspection
from final promotion, or expressly choose another coherent ordering. Preserve
real completion evidence and all final owner-controlled promotion protections.
No runtime fix or policy relaxation is authorized by this report. Assess exact
source/authority/evidence consequences after that choice; this report assumes
neither an automatic full rerun nor automatic reuse under changed identities.

The existing findings `dat-wdq-index-refresh-ogw`,
`dat-wdq-proof-renewal-cycle-qgb`, and `dat-wdq-workspace-inputs-zmt` remain
blocking and undisposed in this new review. The five older owner dispositions
for replay identity, formatter, environment, Git replacement authority, and
promotion delta retain only their original replay/candidate scope. None is
reused as owner approval of this new draft.

## Preserved attempts and limits

Draft v1 remains immutable. It completed shape/environment/correlation checks
and the expected incomplete-proof refusal, then correctly failed `WDQ-TRUST`
because the packaging harness lacked verified source-only startup. V2 executes
the unchanged source-only bootstrap before repository imports and retains that
failed attempt; it does not waive the check. Both helper sources and the v2
process/stdout/stderr records are retained alongside the virtual trees.

Earlier index-mutation capture, preparation failures, missing-reference fixture,
and corrected reviewer audit mistakes remain preserved. No missing observation
has been converted into a pass. Final publication inspection, exact owner defect
disposition, activation, three real adoption cohorts and final acceptance remain
unfinished.
