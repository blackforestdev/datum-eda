"""Package actual frozen reviewer observations; do not approve missing inspection."""

import collections
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path('/home/bfadmin/Documents/datum-eda')
STORE = ROOT / '.git/datum-wdq/proposals/wdq-full-candidate-inspection-20260909'
RUNTIME = ROOT / '.git/datum-wdq/proposals/index-preservation-repair-20260910'
OUTPUT = STORE / 'index-repair-independent-draft-20260910'
PIN = '4e11d60b6f0ec50aa391c68ed39a0df138adf8cf'
CANDIDATE = 'facf48f8617546c7a711d3b45be0700979a36df6'
SESSION = 'wdq-independent-review-20260906'
PREFIX = 'docs/reviews/workflow-delivery-rollout/infrastructure/workspace-renewal/'
TYPED = PREFIX + 'index-repair-independent-draft/'

sys.path.insert(0, str(RUNTIME / 'scripts'))
from workflow_delivery_tree import Tree
from workflow_delivery_io import canonical_json, DeliveryInputError
from workflow_delivery_authority import authority_sha256
from workflow_delivery_contract import contract_sha256
from workflow_delivery_evidence_shapes import proof_shape, review_shape, review_sha256
from workflow_delivery_native import validate_correlations, validate_environment
from workflow_delivery_proof import packet_sha256, validate_proof, read_blob
from workflow_delivery_review import validate_independent_review
from workflow_delivery_trust import Trust


def read(path):
    return json.loads(path.read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    assert not OUTPUT.exists()
    OUTPUT.mkdir()
    base = Tree(ROOT, revision=CANDIDATE)
    contract = base.json('specs/workflow_delivery/rollout.contract.json')
    producer = base.json(contract['proof_path'])
    authority = authority_sha256(base, contract)
    packet = packet_sha256(contract, producer, authority)
    assert packet == '02ce61ee28c450776a575330ce17aca93f2a8e4edc7e4c704cf299efd69cc8ce'

    class Overlay:
        staged = False

        def __getattr__(self, key):
            return getattr(base, key)

        def read(self, path, **kwargs):
            target = OUTPUT / path
            return target.read_bytes() if target.is_file() else base.read(path, **kwargs)

        def json(self, path, **kwargs):
            return json.loads(self.read(path, **kwargs))

    tree = Overlay()

    def blob(path):
        return {'path': path, 'sha256': sha(tree.read(path))}

    def write(path, value):
        target = OUTPUT / path
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('x') as stream:
            json.dump(value, stream, indent=2)
            stream.write('\n')
        return blob(path)

    def capture(capture, row):
        result = read(capture / 'result.json')
        invocation = read(capture / 'invocation.json')
        assert result['invocation_id'] == invocation['invocation_id']
        assert not result['changed_files'] and not result['changed_state_fields']
        assert (capture / 'before.json').read_bytes() == (capture / 'after.json').read_bytes()
        for artifact in result['artifacts']:
            assert sha((capture / artifact['path']).read_bytes()) == artifact['sha256']
        source = 'scripts/workflow_delivery_selector.py' if row['surface'].startswith('S-') else 'scripts/check_workflow_delivery.py'
        symbol = 'selector_failures' if row['surface'].startswith('S-') else 'main'
        events = [json.loads(line) for line in (capture / 'calls.jsonl').read_bytes().splitlines()] if (capture / 'calls.jsonl').exists() else []
        calls = [e for e in events if e.get('event') == 'call' and e.get('function') == symbol and Path(e['source']['path']).name == Path(source).name]
        assert len(calls) <= 1
        for event in calls:
            assert event['source']['sha256'] == sha(base.read(source))
        if not calls:
            assert row['surface'] == 'H' and result['returncode'] != 0
            assert (capture / 'stderr.bin').read_bytes().strip()
        return {**row, 'capture_path': str(capture), 'invocation_id': result['invocation_id'],
                'result_sha256': sha((capture / 'result.json').read_bytes()),
                'artifacts': result['artifacts'], 'started_ns': invocation['started_ns'],
                'finished_ns': result['finished_ns'], 'pid': result['pid'],
                'observer_invocation_ids': sorted({e['invocation_id'] for e in events}),
                'observer_event_ids': [e['event_id'] for e in events],
                'consumer': 'selector' if row['surface'].startswith('S-') else 'validator',
                'handler_ref': {'path': source, 'symbol': symbol}, 'handler_invoked': bool(calls),
                'returncode': result['returncode'], 'result_kind': result['kind'],
                'unavailable_reason': None if calls else (capture / 'stderr.bin').read_text().strip()}

    rows = []
    reports = []
    batches = {'s01': 36, 's02-coverage': 110, 's02-ownership': 190, 's03': 185,
               's04': 175, 's05-snapshots': 39, 's06-selection': 60, 's06-headless': 95,
               's06-trust': 223, 'baseline': 5}
    fields = ('case_id', 'captured_case_id', 'surface', 'phase')
    for batch, count in batches.items():
        store = STORE / ('independent-recheck-index-repair-' + batch + '-20260910')
        inventory = read(store / 'observations.json')
        assert len(inventory['observations']) == count
        for row in inventory['observations']:
            raw = capture(store / row['directory'] / 'capture', {key: row[key] for key in fields})
            assert raw['result_sha256'] == row['result_sha256']
            rows.append(raw)
        reports.append({'path': str(store / 'independent-verification.json'), 'sha256': sha((store / 'independent-verification.json').read_bytes())})
    real = STORE / 'independent-index-repair-reopened-real24-20260910'
    for batch in ('real-roadmap', 'current-inventory'):
        inventory = read(real / batch / 'observations.json')
        assert inventory['fixture_commit'] == 'ba318df013ca5c0263c489a9c77187dc4057a7be'
        for saved in inventory['invocations']:
            cap = real / batch / saved['capture_directory']
            original = batch == 'real-roadmap' and saved['case'] == 'clean'
            row = {'case_id': 'INFRA-S04-11' if original else 'INFRA-S05-WORKSPACE-' + saved['case'],
                   'captured_case_id': 'INFRA-S04-11' if original else read(cap / 'invocation.json')['case_id'],
                   'surface': saved['surface'], 'phase': 'primary' if original else 'compatibility'}
            raw = capture(cap, row)
            assert raw['returncode'] == (1 if saved['expected_refusal'] else 0)
            rows.append(raw)
    workspace = STORE / 'independent-recheck-index-repair-workspace-20260910'
    for name, count in [('workspace-runtime', 52), ('workspace-policy-legacy', 75), ('workspace-proof-input', 45)]:
        store = workspace / name
        inventory = read(store / 'renewal-result.json')
        assert len(inventory['invocations']) == count
        for saved in inventory['invocations']:
            cap = store / saved['capture_directory']
            row = {'case_id': 'INFRA-S05-WORKSPACE-' + saved['case'],
                   'captured_case_id': read(cap / 'invocation.json')['case_id'],
                   'surface': {'S': 'S-check', 'D': 'S-details'}.get(saved['surface'], saved['surface']), 'phase': 'compatibility'}
            raw = capture(cap, row)
            assert raw['returncode'] == (1 if saved['expected_refusal'] else 0)
            rows.append(raw)
    assert len(rows) == 1314 and len({r['invocation_id'] for r in rows}) == 1314
    original_rows = read(STORE / 'index-repair-observations-20260910/dispatch-observations.json')['observations']
    ident = lambda r: tuple(r[k] for k in fields)
    assert collections.Counter(map(ident, rows)) == collections.Counter(map(ident, original_rows))
    assert not {r['invocation_id'] for r in rows} & {r['invocation_id'] for r in original_rows}
    actual_events = [event for row in rows for event in row['observer_event_ids']]
    assert len(actual_events) == len(set(actual_events))

    archive_blobs = []
    for path in sorted((ROOT / PREFIX).glob('independent-index-repair-*')):
        if path.suffix not in ('.json', '.xz'):
            continue
        relative = path.relative_to(ROOT).as_posix()
        raw = Tree(ROOT, revision='8a5beeea').read(relative)
        target = OUTPUT / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        archive_blobs.append(blob(relative))
    receipt = read(STORE / 'independent-recheck-index-repair-s02-coverage-20260910/build-receipt.json')
    receipt = {k: receipt[k] for k in ('binary_sha256', 'build_command', 'toolchain', 'input_manifest_sha256', 'exit_code')}
    original_build = json.loads(read_blob(tree, producer['build']['receipt']))
    assert receipt == original_build
    build = write(TYPED + 'build-receipt.json', receipt)
    build_process = write(TYPED + 'build-process.json', read(STORE / 'independent-recheck-index-repair-s02-coverage-20260910/build-process.json'))
    provenance = write(TYPED + 'provenance.json', {
        'reviewer_session': SESSION, 'producer_packet_sha256': packet, 'runtime': PIN,
        'source_candidate': CANDIDATE, 'observations': 1314, 'original_inventory': 1123,
        'additional_workspace': 191, 'raw_capture_roots': sorted({str(Path(r['capture_path']).parent) for r in rows}),
        'batch_reports': reports, 'raw_archives': archive_blobs,
        'timestamps': 'Actual capture start/finish nanoseconds retained verbatim. Captures occurred before producer closeout; no execution time is rewritten.',
        'fixture_identity': 'Producer fixture Blob is the common reviewed basis. Original matrix uses exact retained post-setup copies with only local-path/capture-nonce relocation; additional synthetic172 use authorized fresh setup histories; real24 restores exact owner-approved ba318 bundle. Independent raw observations are separate, never producer events.',
        'prior_owner_dispositions': 'Five prior closed findings retain only their original candidate/replay scope. They are not approval or resolution of this new replay or its three open defects.',
        'not_applicable_dispositions': [{'scenario_id': scenario['id'], 'dimension': key,
            'reason': value['reason'], 'authority_refs': value['authority_refs']}
            for scenario in contract['scenarios'] for key, value in scenario['dimensions'].items()
            if value['disposition'] == 'not_applicable'],
        'missing_requirement': 'WDQ-INFRA-WORKSPACE group8 renewed exact publication inspection remains unperformed; S05 scope is unverified and review disposition revise.',
        'independence': 'Reviewer authored neither production implementation nor original producer evidence. Review helper only packages existing reviewer process observations.',
        'activation_performed': False, 'full_review_complete': False})
    registry_entries = {}
    dispatches = collections.defaultdict(list)
    for row in rows:
        consumer = row['consumer']; handler = row['handler_ref']
        entry = registry_entries.setdefault(consumer, {'dispatch_key': Path(handler['path']).stem + '.' + handler['symbol'],
            'handler_ref': handler, 'entry_surfaces': ['project_status'] if consumer == 'selector' else ['staged_cli', 'candidate_cli', 'owner_hook'], 'contexts': {}})
        context = 'invocation-' + row['invocation_id']; enabled = row['handler_invoked']
        entry['contexts'][context] = {'enabled': enabled, 'reason': 'Independent exact handler call observed.' if enabled else row['unavailable_reason']}
        dispatches[row['case_id'][:9]].append({'dispatch_key': entry['dispatch_key'],
            'entry_surface': {'C': 'staged_cli', 'R': 'candidate_cli', 'H': 'owner_hook', 'S-check': 'project_status', 'S-details': 'project_status'}[row['surface']],
            'context': context, 'eligible': enabled, 'enabled': enabled, 'invoked': enabled,
            'handler_ref': handler, 'unavailable_reason': row['unavailable_reason'], 'mutation_count': 0})
    registry = write(TYPED + 'registry.json', {'schema_version': 1, 'binary_sha256': receipt['binary_sha256'], 'entries': list(registry_entries.values())})
    results = []
    for scenario in contract['scenarios']:
        sid = scenario['id']; selected_rows = [r for r in rows if r['case_id'].startswith(sid)]
        codes = dict(collections.Counter(str(r['returncode']) for r in selected_rows))
        visible = f'Independent actual {len(selected_rows)} invocations; return codes {codes}; case-specific refusal, positive and recovery assertions passed.'
        state = 'All recorded protected before/after states matched; no main mutation or installed authority change.'
        if sid == 'INFRA-S05':
            state += ' Required renewed exact publication inspection remains unperformed; this is not complete S05 scope.'
        observation = write(TYPED + sid + '-observations.json', {'scenario_id': sid, 'source_commit': PIN, 'observations': selected_rows})
        event = write(TYPED + sid + '-events.json', {'schema_version': 1, 'scenario_id': sid,
            'producer_session': SESSION, 'method': scenario['method'], 'binary_sha256': receipt['binary_sha256'],
            'authority_sha256': authority, 'inputs': scenario['inputs'], 'dispatches': dispatches[sid],
            'actual_visible': visible, 'actual_state': state})
        common = [observation, provenance, build_process, *archive_blobs]
        roles = write(TYPED + sid + '-roles.json', {'kind': 'datum.workflow-delivery.artifacts/v1',
            'scenario_id': sid, 'events': [event], 'captures': [], 'state': common, 'registry': registry})
        observations = {'normal': visible, 'invalid': visible, 'scope': state,
            'failure_recovery': 'Actual matching valid recovery invocations and named workspace restorations passed; no failed capture was overwritten.',
            'accessibility': 'Text-only invalid/valid invocation and diagnostic cases were independently executed; expected usage/errors remained readable in raw pipes. No native accessibility claim.',
            'cancel': 'Five own processes interrupted at the actual observed handler call, return -15, unchanged protected state, followed by fresh valid recoveries.',
            'save_reopen': 'Actual fresh-process recovery after refusal/interruption; no native Save or design reopen claim.'}
        assertions = [{'dimension': k, 'expected': v['reason'], 'observed': observations[k],
            'outcome': 'unverified' if sid == 'INFRA-S05' and k == 'scope' else 'pass'} for k,v in scenario['dimensions'].items() if v['disposition'] == 'required']
        defects = ['dat-wdq-index-refresh-ogw']
        if sid in ('INFRA-S04', 'INFRA-S05'): defects.append('dat-wdq-proof-renewal-cycle-qgb')
        if sid == 'INFRA-S05': defects.append('dat-wdq-workspace-inputs-zmt')
        results.append({'scenario_id': sid, 'outcome': 'unverified' if sid == 'INFRA-S05' else 'pass',
            'actual_visible': visible, 'actual_state': state, 'assertions': assertions,
            'artifacts': [roles,event,registry,*common], 'defects': defects})
    replay = {'schema_version': 1, 'contract_sha256': contract_sha256(contract), 'producer_session': SESSION,
        'source_commit': PIN, 'input_manifest': producer['input_manifest'], 'fixture': producer['fixture'],
        'environment': producer['environment'], 'build': {'command': receipt['build_command'], 'receipt': build,
            'toolchain': receipt['toolchain'], 'source_clean': True}, 'results': results}
    replay_blob = write(TYPED + 'replay.json', replay)
    independent_of = sorted({'codex-wdq-rollout-implementation-20260908', producer['producer_session'], 'wdq-compat-producer-20260909'})
    review = {'schema_version': 1, 'packet_sha256': packet, 'reviewer_session': SESSION,
        'independent_of': independent_of, 'disposition': 'revise', 'replay': replay_blob,
        'findings': [{'issue_id': issue, 'severity': 'blocking', 'disposition_ref': None} for issue in
            ('dat-wdq-index-refresh-ogw','dat-wdq-proof-renewal-cycle-qgb','dat-wdq-workspace-inputs-zmt')], 'owner_receipt': None}
    review_blob = write(contract['review_path'], review)
    proof_shape(replay, replay_blob['path']); review_shape(review, contract['review_path'])
    environment = base.json(producer['environment']['path'])
    validate_environment(tree, replay, environment, contract=contract)
    events = validate_correlations(tree, contract, replay)
    original_events = validate_correlations(tree, contract, producer)
    assert not events & original_events
    try:
        validate_proof(tree, contract, replay_blob['path'])
    except DeliveryInputError as error:
        assert error.code == 'WDQ-RESULT' and 'required scenario not passing' in error.detail
        refusal = {'code': error.code, 'path': error.path, 'detail': error.detail}
    else:
        raise AssertionError('Missing publication inspection must not validate as complete proof')
    item = next(i for i in tree.json('specs/active_frontier.json')['frontier'] if i['key'] == 'WORKFLOW-DELIVERY-IMPLEMENTATION')
    trust = Trust(tree, 'ba318df013ca5c0263c489a9c77187dc4057a7be', 'ba318df013ca5c0263c489a9c77187dc4057a7be')
    try:
        validate_independent_review(tree, contract, producer, authority, trust, item, environment)
    except DeliveryInputError as error:
        assert error.code == 'WDQ-REVIEW'
        review_refusal = {'code': error.code, 'path': error.path, 'detail': error.detail}
    else:
        raise AssertionError('Draft revise review must not pass independent approval')
    write(TYPED + 'validation.json', {'candidate': CANDIDATE, 'producer_packet_sha256': packet,
        'replay': replay_blob, 'review': review_blob, 'review_sha256': review_sha256(review),
        'shape_environment_correlations': 'pass', 'correlated_events': len(events),
        'expected_incomplete_proof_refusal': refusal, 'expected_incomplete_review_refusal': review_refusal,
        'full_review_complete': False, 'activation_performed': False})
    print(json.dumps({'output': str(OUTPUT), 'replay': replay_blob, 'review': review_blob,
        'observations': len(rows), 'correlated_events': len(events), 'draft_only': True}))


if __name__ == '__main__':
    main()
