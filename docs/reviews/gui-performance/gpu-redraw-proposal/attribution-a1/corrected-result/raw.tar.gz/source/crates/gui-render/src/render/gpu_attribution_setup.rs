//! Setup evidence from actual shared prepared state; no timing observations.
use super::*;
pub(super) fn receipt(
    renderer: &Renderer,
    state: &datum_gui_protocol::ReviewWorkspaceState,
    before: &PreparedScene,
    after: &PreparedScene,
    case: usize,
    hover: &datum_gui_protocol::HoverTarget,
) -> anyhow::Result<String> {
    anyhow::ensure!(
        state.ui.layout == datum_gui_protocol::WorkspaceLayout::single(),
        "A1 single layout"
    );
    let panes = after.layout.viewport_panes(&state.ui.layout);
    anyhow::ensure!(
        panes.panes.len() == 1 && panes.panes[0].content == datum_gui_protocol::PaneContent::Board,
        "A1 sole board pane"
    );
    let mut observations = Vec::new();
    for (phase, prepared) in [("before", before), ("after", after)] {
        let (x, y) = prepared
            .crosshair_cursor_screen
            .ok_or_else(|| anyhow::anyhow!("A1 missing prepared crosshair"))?;
        anyhow::ensure!(
            prepared.scene_viewport.contains(x, y),
            "A1 pointer outside board"
        );
        anyhow::ensure!(
            prepared.schematic_scene_viewport.is_none(),
            "A1 unexpected schematic pane"
        );
        let actual_hover = crate::resolve_pane_hover(
            prepared,
            renderer.render_session.board().unwrap(),
            None,
            state,
            x,
            y,
        );
        anyhow::ensure!(
            actual_hover.hover.as_ref() == Some(hover),
            "A1 hit-tested hover differs: {:?}",
            actual_hover.hover
        );
        let rect = prepared.scene_viewport;
        let hit = actual_hover.hover.as_ref().unwrap();
        anyhow::ensure!(hit.object_id.is_ascii(), "A1 ASCII pinned identity");
        observations.push(format!(
            r#"{{"phase":{phase:?},"pointer":[{x},{y}],"hit_tested_hover":{id:?},"hover_surface":"{surface:?}","camera_center_nm":[{cx},{cy}],"camera_zoom":{zoom},"scene_viewport":{rect:?},"board_pane_id":{pane},"crosshair_style":"{style:?}","interaction_vertices":{vertices:?}}}"#,
            id=hit.object_id, surface=hit.surface, cx=prepared.camera.center_x_nm,
            cy=prepared.camera.center_y_nm, zoom=prepared.camera.zoom,
            rect=[rect.x,rect.y,rect.width,rect.height], pane=prepared.board_pane_id.0,
            style=prepared.crosshair_style,
            vertices=prepared.board_interaction_vertices.iter().map(|v| v.pos).collect::<Vec<_>>()
        ));
    }
    let frame = panes.panes[0].rect.frame;
    Ok(format!(
        r#"{{"case":{case},"layout":"single","pane_count":{count},"board_frame":{frame:?},"focus":"{focus:?}","focused_pane":{focused},"selection":"{selection:?}","assigned_hover":{hover:?},"observations":[{observations}]}}"#,
        count = panes.panes.len(),
        frame = [frame.x, frame.y, frame.width, frame.height],
        focus = state.ui.focus,
        focused = state.ui.layout.focused.0,
        selection = state.selection,
        hover = state.ui.hovered_object.as_ref().unwrap().object_id,
        observations = observations.join(",")
    ))
}
