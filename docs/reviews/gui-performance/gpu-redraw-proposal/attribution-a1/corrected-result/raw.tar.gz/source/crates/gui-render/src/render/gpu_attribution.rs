//! Fixed A1 case execution through the shared preparation, upload and painter owners.
use super::*;
use crate::capture_resource::{CaptureReadback, CaptureTarget};
use crate::gpu_surface::PrefixImages;
use crate::renderer_state::damage::regional::Plan;
use gpu_measurements::attribution::Timer;
use std::time::{Duration, Instant};
#[path = "gpu_attribution_conformance.rs"]
mod conformance;
#[path = "gpu_attribution_io.rs"]
mod io;
#[path = "gpu_attribution_manifest.rs"]
mod manifest;
#[path = "gpu_attribution_setup.rs"]
mod setup;

const WIDTH: u32 = 1280;
const HEIGHT: u32 = 800;
const BYTES: u64 = WIDTH as u64 * HEIGHT as u64 * 4;

pub struct AttributionCase {
    old: PreparedScene,
    frozen: PreparedScene,
    plan: Plan,
    old_target: CaptureTarget,
    expected: Vec<u8>,
    hybrid: Vec<u8>,
    images: PrefixImages,
    readback: CaptureReadback,
    timer: Timer,
    next: datum_gui_protocol::ScreenPointPx,
    hover: datum_gui_protocol::HoverTarget,
    frozen_uploads: Option<Vec<(wgpu::Buffer, u64, Vec<u8>)>>,
    pub submissions: usize,
    pub manifest: String,
    pub setup_receipt: String,
}
#[derive(Debug)]
pub struct AttributionObservation {
    pub submission: wgpu::SubmissionIndex,
    pub phases_ms: Vec<(&'static str, f64)>,
    pub ticks: Vec<u64>,
    pub period_ns: f64,
    pub upload_bytes: usize,
    pub image_hash: u64,
    pub gpu_bytes: u64,
    pub tiles: Vec<[u32; 7]>,
}
fn elapsed(start: Instant) -> f64 {
    start.elapsed().as_secs_f64() * 1000.0
}
fn wait(device: &wgpu::Device) -> anyhow::Result<()> {
    device.poll(wgpu::PollType::Wait {
        submission_index: None,
        timeout: Some(Duration::from_secs(2)),
    })?;
    Ok(())
}
fn submit(
    queue: &wgpu::Queue,
    commands: impl IntoIterator<Item = wgpu::CommandBuffer>,
    count: &mut usize,
) -> anyhow::Result<wgpu::SubmissionIndex> {
    anyhow::ensure!(*count < 2200, "A1 submission capacity");
    let receipt = queue.submit(commands);
    *count += 1;
    Ok(receipt)
}
fn extent() -> wgpu::Extent3d {
    wgpu::Extent3d {
        width: WIDTH,
        height: HEIGHT,
        depth_or_array_layers: 1,
    }
}
impl Renderer {
    pub fn attribution_case(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        state: &datum_gui_protocol::ReviewWorkspaceState,
        case: usize,
        mut submissions: usize,
    ) -> anyhow::Result<AttributionCase> {
        use datum_gui_protocol::{CrosshairStyle, HoverTarget, PaneContent, ScreenPointPx};
        let (old, next, id) = match case {
            0 => (
                [499.0, 150.0],
                [500.0, 150.0],
                "zone:bddd9739-252d-5af8-baf9-eec0be6b999d",
            ),
            1 => (
                [700.0, 269.0],
                [700.0, 270.0],
                "zone:b3b2418a-f7a4-5848-aa64-eace29e3cb3a",
            ),
            _ => anyhow::bail!("invalid A1 case"),
        };
        let hover = HoverTarget {
            surface: PaneContent::Board,
            object_id: id.into(),
        };
        let mut state = state.clone();
        state.ui.layout = datum_gui_protocol::WorkspaceLayout::single();
        state.ui.focus =
            datum_gui_protocol::ApplicationFocus::Editor(datum_gui_protocol::PaneId(0));
        // Reproduce archived native closed-dock chrome, not the loader fallback.
        state.ui.terminal.tabs = vec![datum_gui_protocol::TerminalTabState {
            session_id: "a1-archived-shell1".into(),
            previous_session_id: None,
            label: "shell 1".into(),
            event_log_path: String::new(),
            activity_event_count: 0,
            activity_summary: Vec::new(),
            active: true,
            attached: true,
            status: "running".into(),
            restart_count: 0,
            unread_output: false,
            unread_bell_count: 0,
        }];
        state.selection = datum_gui_protocol::SelectionTarget::None;
        state.ui.hovered_object = Some(hover.clone());
        state.ui.cursor_pos = Some(ScreenPointPx {
            x: old[0],
            y: old[1],
        });
        state.ui.crosshair_style = CrosshairStyle::FullViewport;
        let source = crate::render_input::SourceEpoch::default();
        self.prepare_session_workspace(
            &state,
            crate::WorkspaceView {
                source_revision: Some(source.revision()),
                width: WIDTH,
                height: HEIGHT,
                scale: 1.0,
                camera: CameraState {
                    center_x_nm: 151634208.0,
                    center_y_nm: 95122896.0,
                    zoom: 1.0,
                },
                schematic_camera: None,
                include_preferences_overlay: false,
                single_terminal_snapshot: true,
                pane_cameras: &[],
            },
            &[],
        )?;
        let old_target = CaptureTarget::new(device, extent(), self.msaa_format)?;
        loop {
            anyhow::ensure!(submissions < 2200, "A1 setup capacity");
            let plan = self
                .render_session
                .prepare_frame(1, 1, 1, true, WIDTH, HEIGHT)?;
            let frame = self.encode_frame(
                plan,
                device,
                queue,
                &mut submissions,
                &mut |_| {
                    Ok(Some(crate::render_input::FrameTarget::full_texture(
                        &old_target,
                    )?))
                },
                &mut |count, _| {
                    *count += 1;
                },
            )?;
            wait(device)?;
            if let Some(frame) = frame {
                anyhow::ensure!(
                    self.render_session.complete_submitted(frame, 1, 1, 1, true),
                    "A1 initial completion"
                );
                break;
            }
        }
        let old = self.render_session.prepared().unwrap().clone();
        let next = ScreenPointPx {
            x: next[0],
            y: next[1],
        };
        let session = &mut self.render_session;
        anyhow::ensure!(
            session.update_pointer(crate::render_input::PointerUpdate {
                generation: session.pointer_generation(),
                cursor: Some(next),
                hover: Some(&hover),
                style: CrosshairStyle::FullViewport,
            }),
            "A1 source/hover changes cannot use warm pointer path"
        );
        anyhow::ensure!(session.interaction_only_damage(), "A1 strong invalidation");
        let plan = session.regional_plan_for_proof(&old, [WIDTH, HEIGHT]);
        anyhow::ensure!(!plan.is_empty(), "A1 empty pointer plan");
        let frozen = session.prepared().unwrap().clone();
        let setup_receipt = setup::receipt(self, &state, &old, &frozen, case, &hover)?;
        let images = self
            .surface_attachments
            .prefix_images(device)
            .ok_or_else(|| anyhow::anyhow!("A1 prefix images refused"))?;
        let readback = CaptureReadback::new(device, BYTES)?;
        let reference = CaptureTarget::new(device, extent(), self.msaa_format)?;
        // Full reference uses a separate working attachment; it must not discard retained images.
        let candidate = std::mem::take(&mut self.surface_attachments);
        let prefix = std::mem::take(&mut self.render_session.prefix);
        let board = self.render_session.board().unwrap().clone();
        let schematic = self.render_session.schematic().cloned();
        let view = reference.create_view(&Default::default());
        let reference_result = self.render_with_submission(
            device,
            queue,
            &view,
            &frozen,
            &board,
            schematic.as_ref(),
            WIDTH,
            HEIGHT,
            &mut |_| {
                submissions += 1;
            },
        );
        self.surface_attachments = candidate;
        self.render_session.prefix = prefix;
        anyhow::ensure!(
            reference_result?,
            "A1 reference unexpectedly needs cold uploads"
        );
        wait(device)?;
        let (expected, _) = io::read(device, queue, &reference, &readback, &mut submissions)?;
        let mut result = AttributionCase {
            old,
            frozen,
            plan,
            old_target,
            expected,
            hybrid: Vec::new(),
            images,
            readback,
            timer: Timer::new(device, queue)?,
            next,
            hover,
            frozen_uploads: None,
            submissions,
            manifest: String::new(),
            setup_receipt,
        };
        result.manifest = self.attribution_graph_manifest(&result.frozen, &result.plan)?;
        result.reset(self, device, queue)?;
        let mut encoder = device.create_command_encoder(&Default::default());
        result.images.compose_tiles(&mut encoder, &result.plan);
        submit(queue, [encoder.finish()], &mut result.submissions)?;
        wait(device)?;
        // The ablation oracle is old composition with whole selected prefix tiles.
        result.hybrid = io::read_composed(
            device,
            queue,
            &result.images,
            &result.readback,
            &mut result.submissions,
        )?;
        Ok(result)
    }
}
impl AttributionCase {
    pub fn save_reference(&self, path: &std::path::Path) -> anyhow::Result<()> {
        io::save_image(path, &self.expected)
    }

    pub fn save_setup_old(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        path: &std::path::Path,
    ) -> anyhow::Result<()> {
        let (bytes, _) = io::read(
            device,
            queue,
            &self.old_target,
            &self.readback,
            &mut self.submissions,
        )?;
        io::save_image(path, &bytes)
    }

    fn reset(
        &mut self,
        renderer: &mut Renderer,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
    ) -> anyhow::Result<()> {
        let mut encoder = device.create_command_encoder(&Default::default());
        self.images
            .reset_composition(&mut encoder, &self.old_target);
        renderer.encode_regional_composition(
            device,
            &mut encoder,
            &self.frozen,
            WIDTH,
            HEIGHT,
            &self.images,
            &self.plan,
            &mut None,
            composition::RegionalControl {
                omit: 1,
                initialize: true,
            },
            #[cfg(all(test, feature = "visual"))]
            crate::gpu_surface::prefix_negative_control::Fault::None,
        )?;
        let mut uploads = renderer.flush_frame_uploads(device, queue)?;
        submit(
            queue,
            uploads
                .as_mut()
                .map(|b| b.command())
                .into_iter()
                .chain([encoder.finish()]),
            &mut self.submissions,
        )?;
        if let Some(batch) = uploads {
            batch.hold(queue);
        }
        renderer.hold_frame_submission(queue, Some(&self.images));
        self.old_target.hold_submission(queue);
        wait(device)
    }
    pub fn observe(
        &mut self,
        renderer: &mut Renderer,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        target: &wgpu::Texture,
        condition: char,
    ) -> anyhow::Result<AttributionObservation> {
        anyhow::ensure!(
            matches!(condition, 'N' | 'D' | 'M' | 'P' | 'A' | 'B' | 'C'),
            "A1 unknown condition"
        );
        let mut phases = Vec::with_capacity(8);
        let started = Instant::now();
        let (prepared, plan) = if condition == 'P' {
            (self.frozen.clone(), self.plan.clone())
        } else {
            let session = renderer.render_session_mut();
            let accepted = session.update_pointer(crate::render_input::PointerUpdate {
                generation: session.pointer_generation(),
                cursor: Some(self.next),
                hover: Some(&self.hover),
                style: datum_gui_protocol::CrosshairStyle::FullViewport,
            });
            anyhow::ensure!(accepted, "A1 pointer preparation refused");
            (
                session.prepared().unwrap().clone(),
                session.regional_plan_for_proof(&self.old, [WIDTH, HEIGHT]),
            )
        };
        phases.push(("preparation", elapsed(started)));
        anyhow::ensure!(prepared == self.frozen, "A1 D/P prepared payload differs");
        anyhow::ensure!(
            plan.tiles().eq(self.plan.tiles()),
            "A1 D/P ordered tile plan differs"
        );
        let board = renderer.render_session.board().unwrap().clone();
        let schematic = renderer.render_session.schematic().cloned();
        let started = Instant::now();
        let mut upload_submissions = 0;
        let mut acquired = false;
        renderer.render_with_acquisition(
            device,
            queue,
            &prepared,
            &board,
            schematic.as_ref(),
            WIDTH,
            HEIGHT,
            &mut (),
            &mut |_| {
                acquired = true;
                Ok(None::<crate::render_input::FrameTarget>)
            },
            &mut |_, _| {
                upload_submissions += 1;
            },
        )?;
        self.submissions += upload_submissions;
        anyhow::ensure!(
            acquired && upload_submissions == 0,
            "A1 unexpected cold/upload continuation"
        );
        let uploads = renderer.attribution_upload_manifest();
        let upload_bytes = uploads.iter().map(|(_, _, b)| b.len()).sum();
        phases.push(("upload_api", elapsed(started)));
        anyhow::ensure!(
            renderer.attribution_graph_manifest(&prepared, &plan)? == self.manifest,
            "A1 D/P commands/bindings changed"
        );
        if matches!(condition, 'D' | 'P') {
            if let Some(previous) = &self.frozen_uploads {
                anyhow::ensure!(
                    &uploads == previous,
                    "A1 D/P upload bytes/resources/offsets/order differ"
                );
            } else {
                self.frozen_uploads = Some(uploads);
            }
        }
        let started = Instant::now();
        self.reset(renderer, device, queue)?;
        phases.push(("reset", elapsed(started)));
        let started = Instant::now();
        let mut encoder = device.create_command_encoder(&Default::default());
        self.timer.frame = None;
        if condition != 'N' {
            self.timer.start(&mut encoder, condition == 'M');
        }
        if condition == 'M' {
            self.timer.marker(&mut encoder, "upload-leading")?;
        }
        renderer.encode_regional_composition(
            device,
            &mut encoder,
            &prepared,
            WIDTH,
            HEIGHT,
            &self.images,
            &plan,
            &mut self.timer.frame,
            composition::RegionalControl {
                omit: match condition {
                    'A' => 1,
                    'B' => 2,
                    'C' => 3,
                    _ => 0,
                },
                initialize: false,
            },
            #[cfg(all(test, feature = "visual"))]
            crate::gpu_surface::prefix_negative_control::Fault::None,
        )?;
        self.images.present(&mut encoder, target);
        if condition == 'M' {
            self.timer.marker(&mut encoder, "frame-trailing")?;
        }
        if condition != 'N' {
            self.timer.end(&mut encoder)?;
        }
        if condition != 'N' {
            self.timer.resolve(&mut encoder);
        }
        phases.push(("encoding", elapsed(started)));
        let started = Instant::now();
        submit(queue, [encoder.finish()], &mut self.submissions)?;
        renderer.hold_frame_submission(queue, Some(&self.images));
        phases.push(("submit", elapsed(started)));
        wait(device)?;
        phases.push(("completion", elapsed(started)));
        let started = Instant::now();
        let ticks = if condition == 'N' {
            Vec::new()
        } else {
            self.timer.read(device)?
        };
        phases.push(("query_readback", elapsed(started)));
        let started = Instant::now();
        let (bytes, submission) =
            io::read(device, queue, target, &self.readback, &mut self.submissions)?;
        phases.push(("image_readback", elapsed(started)));
        let expected = if matches!(condition, 'A' | 'B' | 'C') {
            &self.hybrid
        } else {
            &self.expected
        };
        if &bytes != expected {
            let root = std::env::var_os("DATUM_A1_ARTIFACT_DIR")
                .ok_or_else(|| anyhow::anyhow!("missing A1 failure artifact directory"))?;
            io::save_image(
                &std::path::Path::new(&root).join("first-failure.png"),
                &bytes,
            )?;
            io::save_image(
                &std::path::Path::new(&root).join("first-failure-expected.png"),
                expected,
            )?;
            anyhow::bail!("A1 exact acquired-target mismatch in {condition}");
        }
        let gpu_bytes = Renderer::gpu_process_reserved_bytes();
        anyhow::ensure!(gpu_bytes <= 512 * 1024 * 1024, "A1 tracked GPU cap");
        Ok(AttributionObservation {
            submission,
            phases_ms: phases,
            ticks,
            period_ns: self.timer.period,
            upload_bytes,
            image_hash: io::hash(&bytes),
            gpu_bytes,
            tiles: self
                .plan
                .tiles()
                .map(|t| {
                    [
                        t.id,
                        t.source[0],
                        t.source[1],
                        t.atlas[0],
                        t.atlas[1],
                        t.extent[0],
                        t.extent[1],
                    ]
                })
                .collect(),
        })
    }
}
