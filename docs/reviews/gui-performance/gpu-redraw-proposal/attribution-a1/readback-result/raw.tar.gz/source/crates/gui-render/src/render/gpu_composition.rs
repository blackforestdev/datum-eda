//! Shared cold, regional, empty and full-fallback image graphs.
use super::*;
#[path = "gpu_regional_composition.rs"]
mod regional;
use crate::gpu_surface::PrefixImages;
use crate::renderer_state::damage::{clip::Clip, regional::Plan};
pub(super) use regional::RegionalControl;

impl Renderer {
    #[allow(clippy::too_many_arguments)]
    pub(super) fn encode_composition(
        &self,
        device: &wgpu::Device,
        encoder: &mut wgpu::CommandEncoder,
        target: &crate::render_input::FrameTarget,
        working: &wgpu::TextureView,
        prepared: &PreparedScene,
        width: u32,
        height: u32,
        images: Option<&PrefixImages>,
        plan: Option<&Plan>,
        measurement: &mut Option<gpu_measurements::FrameQueries>,
        #[cfg(all(test, feature = "visual"))]
        fault: crate::gpu_surface::prefix_negative_control::Fault,
    ) -> anyhow::Result<std::time::Duration> {
        let clear = wgpu::LoadOp::Clear(wgpu::Color {
            r: APP_BG[0] as f64,
            g: APP_BG[1] as f64,
            b: APP_BG[2] as f64,
            a: 1.0,
        });
        let mask = &self.damage_masks.unrestricted;
        mask.set_consumers(self.frame_consumers.all());
        let mut elapsed = std::time::Duration::ZERO;
        if let (Some(images), Some(plan)) = (images, plan) {
            elapsed += self.encode_regional_composition(
                device,
                encoder,
                prepared,
                width,
                height,
                images,
                plan,
                measurement,
                RegionalControl::default(),
                #[cfg(all(test, feature = "visual"))]
                fault,
            )?;
        } else {
            if let Some(images) = images {
                #[cfg(all(test, feature = "visual"))]
                let draw_prefix =
                    fault != crate::gpu_surface::prefix_negative_control::Fault::StaleKey;
                #[cfg(not(all(test, feature = "visual")))]
                let draw_prefix = true;
                if draw_prefix {
                    let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                        label: Some("datum-retained-prefix"),
                        color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                            view: images.prefix_view(),
                            resolve_target: None,
                            depth_slice: None,
                            ops: wgpu::Operations {
                                load: clear,
                                store: wgpu::StoreOp::Store,
                            },
                        })],
                        timestamp_writes: measurement
                            .as_mut()
                            .map(|m| m.pass("frame"))
                            .transpose()?,
                        ..Default::default()
                    });
                    self.draw_frame_prefix(&mut pass, prepared, width, height, measurement)?;
                }
                #[cfg(not(all(test, feature = "visual")))]
                images.copy(encoder);
                #[cfg(all(test, feature = "visual"))]
                fault.copy(
                    device,
                    encoder,
                    images,
                    working,
                    width,
                    height,
                    self.msaa_format,
                );
            }
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("datum-full-composition-resolve"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: working,
                    resolve_target: Some(images.map_or(target.view(), PrefixImages::composed_view)),
                    depth_slice: None,
                    ops: wgpu::Operations {
                        load: if images.is_some() {
                            wgpu::LoadOp::Load
                        } else {
                            clear
                        },
                        store: wgpu::StoreOp::Discard,
                    },
                })],
                timestamp_writes: measurement
                    .as_mut()
                    .map(|m| m.pass(if images.is_some() { "suffix" } else { "frame" }))
                    .transpose()?,
                ..Default::default()
            });
            if images.is_none() {
                self.draw_frame_prefix(&mut pass, prepared, width, height, measurement)?;
            }
            elapsed += self.draw_frame_suffix(
                &mut pass,
                prepared,
                width,
                height,
                &mask.group,
                Clip::full(width, height),
            )?;
        }
        if let Some(images) = images {
            images.present(
                encoder,
                target
                    .copy_destination([width, height], self.msaa_format)
                    .expect("admitted full copy target"),
            );
        }
        Ok(elapsed)
    }
}
