//! Pinned A1 ordering and receipt validation, independent of a GPU.
pub(super) const CONDITIONS: [char; 7] = ['N', 'D', 'M', 'P', 'A', 'B', 'C'];
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct Id {
    pub case: usize,
    pub phase: &'static str,
    pub block: usize,
    pub cycle: usize,
    pub condition: char,
}
pub(super) fn schedule(case: usize, correctness: bool) -> Vec<Id> {
    let mut result = Vec::new();
    if correctness {
        for condition in CONDITIONS {
            result.push(Id {
                case,
                phase: "correctness",
                block: 0,
                cycle: 0,
                condition,
            });
        }
    } else {
        for cycle in 0..4 {
            for condition in CONDITIONS {
                result.push(Id {
                    case,
                    phase: "warmup",
                    block: 0,
                    cycle,
                    condition,
                });
            }
        }
        for block in 0..5 {
            for cycle in 0..8 {
                let mut order = CONDITIONS;
                order.rotate_left((8 * block + cycle) % 7);
                if (block + cycle) % 2 == 1 {
                    order.reverse();
                }
                for condition in order {
                    result.push(Id {
                        case,
                        phase: "measured",
                        block,
                        cycle,
                        condition,
                    });
                }
            }
        }
    }
    result
}
pub(super) fn validate(expected: Id, actual: Id, ticks: &[u64]) -> anyhow::Result<()> {
    anyhow::ensure!(
        expected == actual,
        "A1 reordered/mismatched/duplicate sample"
    );
    if actual.condition == 'N' {
        anyhow::ensure!(ticks.is_empty(), "A1 N has queries");
    } else {
        anyhow::ensure!(
            ticks.len() >= 2 && ticks.len() <= 32 && ticks.windows(2).all(|w| w[0] <= w[1]),
            "A1 missing/reversed queries"
        );
    }
    Ok(())
}
#[test]
fn attribution_offline_negative_controls() {
    let ids = schedule(0, false);
    assert_eq!(ids.len(), 308);
    let d = ids.iter().copied().find(|id| id.condition == 'D').unwrap();
    assert!(validate(d, d, &[]).is_err());
    assert!(validate(ids[0], ids[1], &[1, 2]).is_err());
    assert!(validate(ids[1], ids[0], &[]).is_err());
    assert!(validate(d, d, &[2, 1]).is_err());
    assert!(validate(d, d, &[1, 2]).is_ok());
    let all: Vec<_> = (0..2)
        .flat_map(|case| {
            schedule(case, true)
                .into_iter()
                .chain(schedule(case, false))
        })
        .collect();
    assert_eq!(all.len() + 16, 646);
    for (index, id) in all.iter().enumerate() {
        assert!(!all[..index].contains(id));
    }
}
