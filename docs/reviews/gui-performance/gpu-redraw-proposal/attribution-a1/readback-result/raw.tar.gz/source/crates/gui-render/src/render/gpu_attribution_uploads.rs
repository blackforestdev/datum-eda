//! Exact upload replay descriptors from the shared producer enumeration.
use super::*;
impl Renderer {
    pub(crate) fn attribution_upload_manifest(&self) -> Vec<(wgpu::Buffer, u64, Vec<u8>)> {
        let mut buffers = Vec::new();
        visit_frame_uploads!(self, buffers);
        buffers
            .into_iter()
            .map(|b| (b.buffer.clone(), b.offset, b.bytes.to_vec()))
            .collect()
    }
}
