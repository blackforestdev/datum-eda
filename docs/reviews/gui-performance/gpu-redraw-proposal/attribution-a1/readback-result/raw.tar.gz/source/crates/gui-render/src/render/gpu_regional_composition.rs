//! One regional image graph shared by production and diagnostic ablations.
use super::*;
#[derive(Default)]
pub(crate) struct RegionalControl {
    #[cfg(feature = "gpu-attribution")]
    pub omit: u8,
    #[cfg(feature = "gpu-attribution")]
    pub initialize: bool,
}
impl RegionalControl {
    fn restore(&self) -> bool {
        #[cfg(feature = "gpu-attribution")]
        {
            return self.omit < 2;
        }
        #[cfg(not(feature = "gpu-attribution"))]
        {
            true
        }
    }
    fn resolve(&self) -> bool {
        #[cfg(feature = "gpu-attribution")]
        {
            return self.omit < 3;
        }
        #[cfg(not(feature = "gpu-attribution"))]
        {
            true
        }
    }
    fn suffix(&self) -> bool {
        #[cfg(feature = "gpu-attribution")]
        {
            return self.omit == 0;
        }
        #[cfg(not(feature = "gpu-attribution"))]
        {
            true
        }
    }
    fn initializing(&self) -> bool {
        #[cfg(feature = "gpu-attribution")]
        {
            return self.initialize;
        }
        #[cfg(not(feature = "gpu-attribution"))]
        {
            false
        }
    }
    fn store(&self, production: wgpu::StoreOp) -> wgpu::StoreOp {
        #[cfg(feature = "gpu-attribution")]
        if self.initialize {
            return wgpu::StoreOp::Store;
        }
        production
    }
}
impl Renderer {
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn encode_regional_composition(
        &self,
        device: &wgpu::Device,
        encoder: &mut wgpu::CommandEncoder,
        prepared: &PreparedScene,
        width: u32,
        height: u32,
        images: &PrefixImages,
        plan: &Plan,
        measurement: &mut Option<gpu_measurements::FrameQueries>,
        control: RegionalControl,
        #[cfg(all(test, feature = "visual"))]
        fault: crate::gpu_surface::prefix_negative_control::Fault,
    ) -> anyhow::Result<std::time::Duration> {
        let mask = &self.damage_masks.unrestricted;
        mask.set_consumers(self.frame_consumers.all());
        let mut elapsed = std::time::Duration::ZERO;
        if !plan.is_empty() {
            let (source, destination) = images.restoration_views().expect("admitted aliases");
            #[cfg(all(test, feature = "visual"))]
            let restore = fault != crate::gpu_surface::prefix_negative_control::Fault::StaleWorking;
            #[cfg(not(all(test, feature = "visual")))]
            let restore = true;
            if restore && control.restore() {
                self.damage_masks
                    .restoration
                    .as_ref()
                    .expect("admitted restoration")
                    .encode_regional(
                        device,
                        encoder,
                        source,
                        destination,
                        plan,
                        measurement
                            .as_mut()
                            .map(|m| m.pass("restore"))
                            .transpose()?,
                    );
            }
            if control.resolve() {
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: Some("datum-regional-suffix-resolve"),
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: images.atlas_view(),
                        resolve_target: Some(images.resolved_atlas_view()),
                        depth_slice: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Load,
                            store: control.store(self.surface_attachments.regional_store()),
                        },
                    })],
                    timestamp_writes: measurement.as_mut().map(|m| m.pass("suffix")).transpose()?,
                    ..Default::default()
                });
                for tile in plan.tiles().filter(|_| control.suffix()) {
                    tile.viewport(&mut pass, width, height);
                    let clip = tile.clip();
                    #[cfg(all(test, feature = "visual"))]
                    let clip = if fault
                        == crate::gpu_surface::prefix_negative_control::Fault::MissingSuffixMask
                    {
                        Clip::full(
                            crate::renderer_state::damage::regional::ATLAS,
                            crate::renderer_state::damage::regional::ATLAS,
                        )
                    } else {
                        clip
                    };
                    elapsed += self.draw_frame_suffix(
                        &mut pass,
                        prepared,
                        width,
                        height,
                        &mask.group,
                        clip,
                    )?;
                    #[cfg(all(test, feature = "visual"))]
                    if fault
                        == crate::gpu_surface::prefix_negative_control::Fault::OverlappingSuffix
                    {
                        elapsed += self.draw_frame_suffix(
                            &mut pass,
                            prepared,
                            width,
                            height,
                            &mask.group,
                            clip,
                        )?;
                    }
                }
            }
            if !control.initializing() {
                images.compose_tiles(encoder, plan);
            }
        }
        Ok(elapsed)
    }
}
