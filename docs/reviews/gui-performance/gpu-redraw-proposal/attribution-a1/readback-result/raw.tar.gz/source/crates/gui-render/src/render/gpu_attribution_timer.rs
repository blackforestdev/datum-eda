//! One bounded diagnostic query slot; reuses production resource and marker owners.
use super::*;

pub(crate) struct Timer {
    slot: Slot,
    marker: Tracked<resources::Marker>,
    pub frame: Option<FrameQueries>,
    count: u32,
    pub period: f64,
}
impl Timer {
    pub fn new(device: &wgpu::Device, queue: &wgpu::Queue) -> anyhow::Result<Self> {
        let required =
            wgpu::Features::TIMESTAMP_QUERY | wgpu::Features::TIMESTAMP_QUERY_INSIDE_ENCODERS;
        anyhow::ensure!(
            device.features().contains(required),
            "A1 timestamp features absent"
        );
        let period = f64::from(queue.get_timestamp_period());
        anyhow::ensure!(
            period.is_finite() && period > 0.0,
            "A1 invalid timestamp period"
        );
        let owner = crate::text_gpu::lifetime::Owner::new();
        Ok(Self {
            slot: Slot::new(device, &owner, 1)?,
            marker: resources::Marker::new(device, &owner, 1)?,
            frame: None,
            count: 0,
            period,
        })
    }
    pub fn start(&mut self, encoder: &mut wgpu::CommandEncoder, markers: bool) {
        self.count = 1;
        self.frame = markers.then(|| FrameQueries {
            timeline: Default::default(),
            pass_indices: Vec::with_capacity(4),
            scene_offset: None,
            final_transfer_end: None,
            slot: 0,
            epoch: 1,
            frame: 1,
            submission: 1,
            queries: (*self.slot.queries).clone(),
            resources: self.slot.submission_refs(),
            passes: Vec::with_capacity(4),
            query_count: 1,
            marker_count: 0,
            scene_markers_enabled: false,
            signal: Arc::new(AtomicU8::new(ENCODING)),
            resolved: false,
            submitted: true,
        });
        encoder.write_timestamp(&self.slot.queries, 0);
    }
    pub fn marker(
        &mut self,
        encoder: &mut wgpu::CommandEncoder,
        name: &'static str,
    ) -> anyhow::Result<()> {
        self.frame
            .as_mut()
            .ok_or_else(|| anyhow::anyhow!("marker outside M"))?
            .encode_marker(encoder, &self.marker.view, name)
    }
    pub fn end(&mut self, encoder: &mut wgpu::CommandEncoder) -> anyhow::Result<()> {
        let index = self.frame.as_ref().map_or(1, |f| f.query_count);
        anyhow::ensure!(index < QUERIES, "A1 query capacity");
        encoder.write_timestamp(&self.slot.queries, index);
        self.count = index + 1;
        Ok(())
    }
    pub fn resolve(&self, encoder: &mut wgpu::CommandEncoder) {
        encoder.resolve_query_set(&self.slot.queries, 0..self.count, &self.slot.resolve, 0);
        encoder.copy_buffer_to_buffer(
            &self.slot.resolve,
            0,
            &self.slot.readback,
            0,
            u64::from(self.count) * 8,
        );
    }
    pub fn read(&self, device: &wgpu::Device) -> anyhow::Result<Vec<u64>> {
        let bytes = self.slot.readback.slice(..u64::from(self.count) * 8);
        let (tx, rx) = std::sync::mpsc::channel();
        bytes.map_async(wgpu::MapMode::Read, move |r| {
            let _ = tx.send(r);
        });
        device.poll(wgpu::PollType::Wait {
            submission_index: None,
            timeout: Some(Duration::from_secs(2)),
        })?;
        rx.recv_timeout(Duration::from_secs(2))??;
        let mapped = bytes.get_mapped_range();
        let ticks = mapped
            .chunks_exact(8)
            .map(|b| u64::from_le_bytes(b.try_into().unwrap()))
            .collect::<Vec<_>>();
        drop(mapped);
        self.slot.readback.unmap();
        anyhow::ensure!(
            ticks.len() == self.count as usize && ticks.windows(2).all(|w| w[0] <= w[1]),
            "A1 incomplete/reversed timestamps"
        );
        Ok(ticks)
    }
}
