//! The fixed sixteen A1 clock/operation observations, no alternate timing method.
use super::*;
use crate::text_gpu::budget::GpuReservation;
use crate::text_gpu::lifetime::{Kind, Owner};
use wgpu::util::DeviceExt;
impl Renderer {
    pub fn attribution_conformance(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        mut emit: impl FnMut(usize, usize, Vec<u64>, f64) -> anyhow::Result<()>,
    ) -> anyhow::Result<usize> {
        let owner = Owner::new();
        let mut submissions = 0;
        let mut timer = Timer::new(device, queue)?;
        let size = 4 * 1024 * 1024;
        let source_charge = GpuReservation::new(size, vec![])?;
        let source = owner.track_reserved(
            device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("a1-known-copy-source"),
                size,
                usage: wgpu::BufferUsages::COPY_SRC,
                mapped_at_creation: true,
            }),
            1,
            Kind::Readback,
            source_charge,
        );
        source.slice(..).get_mapped_range_mut().fill(0x5a);
        source.unmap();
        let middle_charge = GpuReservation::new(size, vec![])?;
        let middle = owner.track_reserved(
            device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("a1-known-copy-middle"),
                size,
                usage: wgpu::BufferUsages::COPY_SRC | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            }),
            1,
            Kind::Readback,
            middle_charge,
        );
        let buffer = CaptureReadback::new(device, size)?;
        let target = CaptureTarget::new(device, extent(), self.msaa_format)?;
        let working = self.ensure_msaa(device, WIDTH, HEIGHT)?.clone();
        self.uniform_buffer.sync(
            queue,
            ScreenUniform {
                resolution: [WIDTH as f32, HEIGHT as f32],
                _pad: [0.0; 2],
            },
        );
        let mut upload = self.flush_frame_uploads(device, queue)?;
        if let Some(batch) = &mut upload {
            submit(queue, [batch.command()], &mut submissions)?;
        }
        if let Some(batch) = upload {
            batch.hold(queue);
        }
        wait(device)?;
        let mut vertices: Vec<Vertex> = [
            [0.0, 0.0],
            [1280.0, 0.0],
            [0.0, 800.0],
            [0.0, 800.0],
            [1280.0, 0.0],
            [1280.0, 800.0],
        ]
        .into_iter()
        .map(|position| Vertex {
            pos: position,
            color: [1.0, 0.0, 0.0],
        })
        .collect();
        vertices.extend(vertices.clone().into_iter().map(|mut v| {
            v.color = [0.0, 0.0, 1.0];
            v
        }));
        let reservation =
            GpuReservation::new(std::mem::size_of_val(vertices.as_slice()) as u64, vec![])?;
        let quad = owner.track_reserved(
            device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: Some("a1-known-quad"),
                contents: bytemuck::cast_slice(&vertices),
                usage: wgpu::BufferUsages::VERTEX,
            }),
            1,
            Kind::Readback,
            reservation,
        );
        for repeat in 0..2 {
            for case in 0..8 {
                let mut encoder = device.create_command_encoder(&Default::default());
                if case != 7 {
                    timer.start(&mut encoder, case == 6);
                }
                match case {
                    0 => (),
                    1 | 4 | 5 => {
                        for pass_index in 0..if case == 5 { 2 } else { 1 } {
                            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                                    view: &working,
                                    resolve_target: Some(&target.create_view(&Default::default())),
                                    depth_slice: None,
                                    ops: wgpu::Operations {
                                        load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                                        store: wgpu::StoreOp::Store,
                                    },
                                })],
                                ..Default::default()
                            });
                            if case != 1 {
                                pass.set_pipeline(&self.pipeline);
                                pass.set_bind_group(0, &self.uniform_bind_group, &[]);
                                pass.set_bind_group(1, &self.damage_masks.unrestricted.group, &[]);
                                pass.set_vertex_buffer(0, quad.slice(..));
                                pass.draw(pass_index * 6..pass_index * 6 + 6, 0..1);
                            }
                        }
                    }
                    2 | 7 => encoder.copy_buffer_to_buffer(&source, 0, &buffer, 0, size),
                    3 => {
                        encoder.copy_buffer_to_buffer(&source, 0, &middle, 0, size);
                        encoder.copy_buffer_to_buffer(&middle, 0, &buffer, 0, size);
                    }
                    6 => timer.marker(&mut encoder, "a1-production-marker")?,
                    _ => unreachable!(),
                }
                if case != 7 {
                    timer.end(&mut encoder)?;
                    timer.resolve(&mut encoder);
                }
                submit(queue, [encoder.finish()], &mut submissions)?;
                wait(device)?;
                let ticks = if case == 7 {
                    Vec::new()
                } else {
                    timer.read(device)?
                };
                if matches!(case, 2 | 3 | 7) {
                    let slice = buffer.slice(..);
                    let (tx, rx) = std::sync::mpsc::channel();
                    slice.map_async(wgpu::MapMode::Read, move |r| {
                        let _ = tx.send(r);
                    });
                    wait(device)?;
                    rx.recv_timeout(Duration::from_secs(2))??;
                    anyhow::ensure!(
                        slice.get_mapped_range().iter().all(|b| *b == 0x5a),
                        "A1 conformance copy bytes"
                    );
                    buffer.unmap();
                }
                if matches!(case, 1 | 4 | 5) {
                    let (bytes, _) = io::read(device, queue, &target, &buffer, &mut submissions)?;
                    let expected = if case == 1 {
                        [0, 0, 0, 255]
                    } else if case == 5 {
                        [255, 0, 0, 255]
                    } else {
                        [0, 0, 255, 255]
                    };
                    anyhow::ensure!(
                        bytes.chunks_exact(4).all(|p| p == expected),
                        "A1 exact8 conformance pixels"
                    );
                }
                emit(repeat, case, ticks, timer.period)?;
            }
        }
        Ok(submissions)
    }
}
