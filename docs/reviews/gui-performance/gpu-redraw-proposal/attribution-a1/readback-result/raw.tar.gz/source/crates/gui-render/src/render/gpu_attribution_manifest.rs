//! Fixed-fixture command descriptors; every admitted painter path is explicit.
use super::*;
impl Renderer {
    pub(super) fn attribution_graph_manifest(
        &self,
        prepared: &PreparedScene,
        plan: &Plan,
    ) -> anyhow::Result<String> {
        anyhow::ensure!(
            prepared.schematic_overlay_vertices().is_empty()
                && prepared.console_overlay_vertices().is_empty()
                && prepared.menu_overlay_vertices().is_empty()
                && prepared.terminal_graphics.is_empty(),
            "A1 fixture has an unpinned schematic/console/menu/terminal painter"
        );
        let mut commands = vec![
            "restore:T clear0 store;prefix UNORM view;restoration pipeline;bind0=A".to_string(),
        ];
        for tile in plan.tiles() {
            commands.push(format!(
                "restore clip={:?}/{:?};draw=0..3;instance={}..{}",
                tile.atlas,
                tile.extent,
                tile.id,
                tile.id + 1
            ));
        }
        commands.push("suffix:T load/resolveR/discard".into());
        for tile in plan.tiles() {
            let clip = tile.clip();
            commands.push(format!("viewport={:?}->{:?}/1280x800;clip={:?};pipeline={:?};bind0={:?};bind1=unrestricted",
                tile.source,tile.atlas,clip.intersect([0,0,WIDTH,HEIGHT]),self.pipeline,self.uniform_bind_group));
            for (vertices, viewport, buffer) in [
                (
                    prepared.viewport_overlay_vertices(),
                    Some(prepared.scene_viewport),
                    self.viewport_overlay_gpu.buffer(),
                ),
                (
                    prepared.board_interaction_vertices(),
                    prepared.painted_interaction_viewport(SceneSurface::Board),
                    self.board_interaction_gpu.buffer(),
                ),
            ] {
                if let Some(viewport) = viewport
                    && !vertices.is_empty()
                    && let Some(clip) =
                        clip.intersect(immediate_admission::screen_admission::scissor(viewport))
                {
                    commands.push(format!(
                        "clip={clip:?};vertex0={buffer:?};draw=0..{};instances=0..1",
                        vertices.len()
                    ));
                }
            }
            if prepared.has_workspace_text() {
                commands.push(format!("clip={:?}", clip.intersect([0, 0, WIDTH, HEIGHT])));
                commands.extend(
                    self.text_renderer
                        .attribution_commands(&self.atlas, TextLayer::Workspace),
                );
            }
            commands.push(format!(
                "console empty;pipeline={:?};bind0={:?};bind1=unrestricted",
                self.pipeline, self.uniform_bind_group
            ));
            if prepared.has_workspace_text() {
                commands.push(format!("clip={:?}", clip.intersect([0, 0, WIDTH, HEIGHT])));
                commands.extend(
                    self.text_renderer
                        .attribution_commands(&self.atlas, TextLayer::Foreground),
                );
            }
        }
        for tile in plan.tiles() {
            commands.push(format!(
                "copy R{:?}->C{:?}:{:?}",
                tile.atlas, tile.source, tile.extent
            ));
        }
        commands.push("copy C[0,0,1280,800]->acquired[0,0,1280,800]".into());
        Ok(commands.join("\n"))
    }
}
