//! Bounded exact raw-byte readback, outside the attributed graph interval.
use super::*;
pub(super) fn read(
    device: &wgpu::Device,
    queue: &wgpu::Queue,
    texture: &wgpu::Texture,
    buffer: &CaptureReadback,
    submissions: &mut usize,
) -> anyhow::Result<(Vec<u8>, wgpu::SubmissionIndex)> {
    anyhow::ensure!(
        texture.usage().contains(wgpu::TextureUsages::COPY_SRC),
        "A1 target lacks COPY_SRC"
    );
    let mut encoder = device.create_command_encoder(&Default::default());
    encoder.copy_texture_to_buffer(
        texture.as_image_copy(),
        wgpu::TexelCopyBufferInfo {
            buffer,
            layout: wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(WIDTH * 4),
                rows_per_image: Some(HEIGHT),
            },
        },
        extent(),
    );
    let submission = submit(queue, [encoder.finish()], submissions)?;
    buffer.hold_submission(queue);
    let slice = buffer.slice(..BYTES);
    let (tx, rx) = std::sync::mpsc::channel();
    slice.map_async(wgpu::MapMode::Read, move |r| {
        let _ = tx.send(r);
    });
    wait(device)?;
    rx.recv_timeout(Duration::from_secs(2))??;
    let bytes = slice.get_mapped_range().to_vec();
    buffer.unmap();
    Ok((bytes, submission))
}
pub(super) fn read_composed(
    device: &wgpu::Device,
    queue: &wgpu::Queue,
    images: &PrefixImages,
    buffer: &CaptureReadback,
    submissions: &mut usize,
) -> anyhow::Result<Vec<u8>> {
    Ok(read(
        device,
        queue,
        images.composed_texture(),
        buffer,
        submissions,
    )?
    .0)
}
pub(super) fn hash(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |h, b| {
        (h ^ u64::from(*b)).wrapping_mul(0x100000001b3)
    })
}

pub(super) fn save_image(path: &std::path::Path, bytes: &[u8]) -> anyhow::Result<()> {
    let mut rgba = bytes.to_vec();
    for pixel in rgba.chunks_exact_mut(4) {
        pixel.swap(0, 2);
    }
    image::RgbaImage::from_raw(WIDTH, HEIGHT, rgba)
        .ok_or_else(|| anyhow::anyhow!("A1 reference image extent"))?
        .save(path)?;
    Ok(())
}
