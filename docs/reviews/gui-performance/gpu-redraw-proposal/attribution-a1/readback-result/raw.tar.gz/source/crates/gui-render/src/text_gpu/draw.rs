//! Original instance-based glyph drawing over Datum's texture-page owner.
use super::staging_vec::StagingVec;
use std::ops::Range;

use super::raster::Raster as SwashCache;
use glyphon::{Color, LayoutRun, TextBounds};

use super::atlas::Atlas;
use super::lifetime::{Kind, RetirementReason, SubmissionRef, Tracked};

pub(crate) struct Area<'a, R> {
    pub layer: crate::TextLayer,
    pub rich_spans: &'a [crate::TextRunSpan],
    pub rows: R,
    pub left: f32,
    pub top: f32,
    pub scale: f32,
    pub bounds: TextBounds,
    pub default_color: Color,
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct Instance {
    rect: [f32; 4],
    tex: [u32; 4],
    color: u32,
    is_color: u32,
}

/// Counts from the last successful glyph preparation, not raster-visible pixels.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct GlyphPreparationCounts {
    pub areas: usize,
    pub layout_rows: usize,
    pub shaped_instances: usize,
    pub row_culled_instances: usize,
    pub clipped_instances: usize,
    pub without_raster_instances: usize,
    pub prepared_instances: usize,
    pub draw_batches: usize,
}

pub(crate) struct Draw {
    screen_budget: std::sync::Arc<super::budget::Budget>,
    generation_budget: std::sync::Arc<super::budget::Budget>,
    pipeline: wgpu::RenderPipeline,
    instances: Option<Tracked<wgpu::Buffer>>,
    batches: StagingVec<(usize, crate::TextLayer, Range<u32>)>,
    snapshot: StagingVec<Instance>,
    pending_instances: Option<StagingVec<Instance>>,
    generation: Option<u64>,
    pub upload_bytes: u64,
    pub preparation_counts: Option<GlyphPreparationCounts>,
}

impl Draw {
    pub fn new(
        device: &wgpu::Device,
        atlas: &Atlas,
        format: wgpu::TextureFormat,
        samples: u32,
        screen_budget: std::sync::Arc<super::budget::Budget>,
    ) -> Self {
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("datum-glyph-shader"),
            source: wgpu::ShaderSource::Wgsl(
                crate::renderer_state::damage::shader(include_str!("glyph.wgsl"), 1).into(),
            ),
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("datum-glyph-pipeline-layout"),
            bind_group_layouts: &[
                &atlas.layout,
                &crate::renderer_state::damage::layout(device),
            ],
            immediate_size: 0,
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("datum-glyph-pipeline"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vertex"),
                buffers: &[wgpu::VertexBufferLayout {
                    array_stride: std::mem::size_of::<Instance>() as u64,
                    step_mode: wgpu::VertexStepMode::Instance,
                    attributes: &wgpu::vertex_attr_array![0 => Float32x4, 1 => Uint32x4, 2 => Uint32, 3 => Uint32],
                }],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fragment"),
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: None,
            multisample: wgpu::MultisampleState { count: samples, ..Default::default() },
            multiview_mask: None,
            cache: None,
        });
        Self::with_pipeline(pipeline, screen_budget, super::budget::Budget::new(2))
    }

    // A second batch owner for the same renderer/atlas needs separate instances,
    // uploads and generation allowance, but the immutable pipeline is identical.
    // On recovery clone only the newly created owner's pipeline, never the old
    // device's pipeline; preserve the previous batch's retirement allowance.
    pub fn new_batch_owner(&self, previous: Option<&Self>) -> Self {
        Self::with_pipeline(
            self.pipeline.clone(),
            self.screen_budget.clone(),
            previous.map_or_else(
                || super::budget::Budget::new(2),
                |old| old.generation_budget.clone(),
            ),
        )
    }

    fn with_pipeline(
        pipeline: wgpu::RenderPipeline,
        screen_budget: std::sync::Arc<super::budget::Budget>,
        generation_budget: std::sync::Arc<super::budget::Budget>,
    ) -> Self {
        Self {
            screen_budget,
            generation_budget,
            pipeline,
            instances: None,
            batches: Default::default(),
            snapshot: Default::default(),
            pending_instances: None,
            generation: None,
            upload_bytes: 0,
            preparation_counts: None,
        }
    }

    pub fn replacement(
        &self,
        device: &wgpu::Device,
        atlas: &Atlas,
        format: wgpu::TextureFormat,
        samples: u32,
    ) -> Self {
        let mut replacement = Self::new(device, atlas, format, samples, self.screen_budget.clone());
        replacement.generation_budget = self.generation_budget.clone();
        replacement
    }

    #[allow(clippy::too_many_arguments)]
    pub fn prepare<'a, R: IntoIterator<Item = LayoutRun<'a>>>(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        atlas: &mut Atlas,
        fonts: &mut impl crate::text_layout::fonts::Source,
        raster: &mut SwashCache,
        resolution: [u32; 2],
        areas: impl IntoIterator<Item = Area<'a, R>>,
    ) -> anyhow::Result<()> {
        self.preparation_counts = None;
        self.generation = None;
        self.pending_instances = None;
        self.batches.clear();
        self.upload_bytes = 0;
        anyhow::ensure!(!resolution.contains(&0), "zero text target extent");
        let mut counts = GlyphPreparationCounts::default();
        let mut instances = StagingVec::default();
        for area in areas {
            counts.areas += 1;
            let bounds = [
                area.bounds.left.max(0),
                area.bounds.top.max(0),
                area.bounds.right.min(resolution[0] as i32),
                area.bounds.bottom.min(resolution[1] as i32),
            ];
            for row in area.rows {
                counts.layout_rows += 1;
                counts.shaped_instances += row.glyphs.len();
                let row_top = (area.top + row.line_top * area.scale) as i32;
                if row_top > bounds[3]
                    || row_top + ((row.line_height * area.scale) as i32) < bounds[1]
                {
                    counts.row_culled_instances += row.glyphs.len();
                    continue;
                }
                for glyph in row.glyphs {
                    let physical = glyph.physical((area.left, area.top), area.scale);
                    let Some(location) =
                        atlas.glyph(device, queue, fonts, raster, physical.cache_key)?
                    else {
                        counts.without_raster_instances += 1;
                        continue;
                    };
                    let x = physical.x + location.bearing[0];
                    let y =
                        physical.y + (row.line_y * area.scale).round() as i32 - location.bearing[1];
                    let left = x.max(bounds[0]);
                    let top = y.max(bounds[1]);
                    let right = (x + location.size[0] as i32).min(bounds[2]);
                    let bottom = (y + location.size[1] as i32).min(bounds[3]);
                    if left >= right || top >= bottom {
                        counts.clipped_instances += 1;
                        continue;
                    }
                    let index = instances.len() as u32;
                    instances.try_push(
                        Instance {
                            rect: [
                                2.0 * left as f32 / resolution[0] as f32 - 1.0,
                                1.0 - 2.0 * top as f32 / resolution[1] as f32,
                                2.0 * (right - left) as f32 / resolution[0] as f32,
                                -2.0 * (bottom - top) as f32 / resolution[1] as f32,
                            ],
                            tex: [
                                location.origin[0] + (left - x) as u32,
                                location.origin[1] + (top - y) as u32,
                                (right - left) as u32,
                                (bottom - top) as u32,
                            ],
                            color: glyph
                                .metadata
                                .checked_sub(1)
                                .and_then(|index| area.rich_spans.get(index))
                                .map(|span| crate::text_color(span.color))
                                .or(glyph.color_opt)
                                .unwrap_or(area.default_color)
                                .0,
                            is_color: u32::from(location.color),
                        },
                        &atlas.staging_budget,
                    )?;
                    // Only adjacent glyphs are batched; overlapping text retains
                    // the caller's painter order even across mask/color pages.
                    if let Some((_, _, range)) = self
                        .batches
                        .last_mut()
                        .filter(|(page, layer, _)| *page == location.page && *layer == area.layer)
                    {
                        range.end = index + 1;
                    } else {
                        self.batches.try_push(
                            (location.page, area.layer, index..index + 1),
                            &atlas.staging_budget,
                        )?;
                    }
                }
            }
        }
        let required = (instances.len() * std::mem::size_of::<Instance>()) as u64;
        if required == 0 {
            if let Some(buffer) = &self.instances {
                buffer.retire(RetirementReason::Cleared);
            }
            self.instances = None;
            self.snapshot = Default::default();
        } else if self.instances.as_ref().is_none_or(|buffer| {
            required > buffer.size() || buffer.size() > required.saturating_mul(4)
        }) {
            let capacity = required.next_power_of_two();
            let generation_permit = self.generation_budget.reserve(1).map_err(|_| {
                anyhow::anyhow!(
                    "glyph instances have two live GPU allocations; wait for retirement"
                )
            })?;
            let screen_permit = self.screen_budget.reserve(capacity)?;
            let reservation = super::budget::GpuReservation::new(
                capacity,
                vec![generation_permit, screen_permit],
            )?;
            let replacement = atlas.owner.track_reserved(
                device.create_buffer(&wgpu::BufferDescriptor {
                    label: Some("datum-glyph-instances"),
                    size: capacity,
                    usage: wgpu::BufferUsages::VERTEX
                        | wgpu::BufferUsages::COPY_DST
                        | wgpu::BufferUsages::STORAGE,
                    mapped_at_creation: false,
                }),
                atlas.generation,
                Kind::Instances,
                reservation,
            );
            if let Some(buffer) = &self.instances {
                buffer.retire(RetirementReason::Replaced);
            }
            self.instances = Some(replacement);
            self.snapshot = Default::default();
        }
        if let Some(buffer) = &self.instances {
            buffer.set_requested_bytes(required);
        }
        counts.prepared_instances = instances.len();
        counts.draw_batches = self.batches.len();
        self.preparation_counts = Some(counts);
        self.pending_instances = Some(instances);
        self.generation = Some(atlas.generation);
        Ok(())
    }

    /// Share the screen-stream changed-range writer. Updates reach the queue
    /// only at the caller's successful frame submission boundary.
    pub fn has_pending_uploads(&self) -> bool {
        self.pending_instances.is_some()
    }

    pub fn cancel_preparation(&mut self) {
        self.preparation_counts = None;
        self.generation = None;
        self.pending_instances = None;
        self.batches.clear();
    }

    pub fn append_uploads<'a>(
        &'a self,
        out: &mut impl Extend<super::upload::BufferUpload<'a>>,
    ) -> u64 {
        match (&self.pending_instances, &self.instances) {
            (Some(instances), Some(buffer)) => crate::gpu_data::screen_buffer::dirty_ranges(
                bytemuck::cast_slice(&self.snapshot),
                bytemuck::cast_slice(instances),
                std::mem::size_of::<Instance>(),
                |offset, bytes| {
                    out.extend(std::iter::once(super::upload::BufferUpload {
                        target: Some(buffer.upload_target()),
                        buffer,
                        offset,
                        bytes,
                    }))
                },
            ) as u64,
            _ => 0,
        }
    }

    pub fn finish_uploads(&mut self, bytes: u64) {
        self.upload_bytes = bytes;
        if let Some(instances) = self.pending_instances.take() {
            // Move the already admitted CPU allocation into the comparison
            // baseline without another allocation or an uncharged shrink.
            self.snapshot = instances;
        }
    }

    #[cfg(all(test, feature = "visual"))]
    pub fn flush_uploads(&mut self, device: &wgpu::Device, queue: &wgpu::Queue) {
        let mut uploads = Vec::new();
        let bytes = self.append_uploads(&mut uploads);
        super::upload::submit_buffers_for_test(device, queue, &uploads);
        self.finish_uploads(bytes);
    }

    pub(crate) fn cpu_storage_bytes(&self) -> u64 {
        self.batches.allocated_bytes()
            + self.snapshot.allocated_bytes()
            + self
                .pending_instances
                .as_ref()
                .map_or(0, StagingVec::allocated_bytes)
    }

    pub(crate) fn set_consumers(&self, consumers: crate::resource_consumers::Consumers) {
        if let Some(buffer) = &self.instances {
            buffer.set_consumers(consumers);
        }
    }

    pub fn submission_ref(&self) -> Option<SubmissionRef> {
        self.instances.as_ref().map(Tracked::submission_ref)
    }

    #[cfg(feature = "gpu-attribution")]
    pub(crate) fn attribution_commands(
        &self,
        atlas: &Atlas,
        layer: crate::TextLayer,
    ) -> Vec<String> {
        let mut result = Vec::new();
        if let Some(instances) = &self.instances {
            result.push(format!(
                "glyph pipeline={:?};bind1=unrestricted;vertex0={}",
                self.pipeline,
                instances.submission_ref().allocation_id
            ));
            for (page, batch_layer, range) in self.batches.iter() {
                if *batch_layer == layer {
                    result.push(format!(
                        "bind0={:?};draw=0..6;instances={:?}",
                        atlas.pages[*page].bind_group, range
                    ));
                }
            }
        }
        result
    }

    pub fn render(
        &self,
        atlas: &Atlas,
        pass: &mut wgpu::RenderPass<'_>,
        damage: &wgpu::BindGroup,
    ) -> anyhow::Result<()> {
        self.render_layer(atlas, pass, None, damage)
    }

    pub fn render_layer(
        &self,
        atlas: &Atlas,
        pass: &mut wgpu::RenderPass<'_>,
        layer: Option<crate::TextLayer>,
        damage: &wgpu::BindGroup,
    ) -> anyhow::Result<()> {
        anyhow::ensure!(
            self.generation == Some(atlas.generation),
            "stale or failed glyph preparation"
        );
        if let Some(instances) = &self.instances {
            pass.set_pipeline(&self.pipeline);
            pass.set_bind_group(1, damage, &[]);
            pass.set_vertex_buffer(0, instances.slice(..));
            for (page, batch_layer, range) in self.batches.iter() {
                if layer.is_some_and(|layer| layer != *batch_layer) {
                    continue;
                }
                pass.set_bind_group(0, &atlas.pages[*page].bind_group, &[]);
                pass.draw(0..6, range.clone());
            }
        }
        Ok(())
    }
}

#[cfg(all(test, feature = "visual"))]
#[path = "draw_generation_tests.rs"]
mod generation_tests;
