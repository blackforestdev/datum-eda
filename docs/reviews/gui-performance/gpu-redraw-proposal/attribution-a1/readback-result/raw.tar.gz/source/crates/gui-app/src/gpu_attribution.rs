//! Single approved native A1 process. No ordinary executable entry point.
use anyhow::{Context, Result};
use datum_gui_render::Renderer;
use std::{fs::File, io::Write, sync::Arc, time::Instant};
#[path = "gpu_attribution_schedule.rs"]
mod schedule;
struct Writer {
    file: File,
    bytes: usize,
}
impl Writer {
    fn record(&mut self, value: serde_json::Value) -> Result<()> {
        let bytes = serde_json::to_vec(&value)?;
        anyhow::ensure!(
            self.bytes + bytes.len() + 1 <= 16 * 1024 * 1024,
            "A1 numeric output cap"
        );
        self.file.write_all(&bytes)?;
        self.file.write_all(b"\n")?;
        self.file.flush()?;
        self.bytes += bytes.len() + 1;
        Ok(())
    }
}
#[test]
#[ignore = "single owner-approved A1 attribution process, max300s, no retries"]
fn attribution_native_study() {
    let output = std::env::var_os("DATUM_A1_OUTPUT").expect("A1 output path");
    let mut writer = Writer {
        file: File::create(output).unwrap(),
        bytes: 0,
    };
    let storage = datum_gui_render::cpu_alloc::Scope::new("a1-diagnostic-storage");
    let result = storage.with(|| run(&mut writer, &storage));
    if let Err(error) = &result {
        writer
            .record(serde_json::json!({"kind":"stopped","error":format!("{error:#}")}))
            .unwrap();
    }
    result.unwrap();
}
#[allow(deprecated)]
fn run(writer: &mut Writer, storage: &datum_gui_render::cpu_alloc::Scope) -> Result<()> {
    use winit::platform::x11::EventLoopBuilderExtX11;
    let started = Instant::now();
    let event_loop = winit::event_loop::EventLoop::<()>::with_user_event()
        .with_x11()
        .with_any_thread(true)
        .build()?;
    let window = Arc::new(
        event_loop.create_window(
            winit::window::Window::default_attributes()
                .with_title("Datum GPU attribution A1")
                .with_visible(true)
                .with_inner_size(winit::dpi::PhysicalSize::new(1280, 800)),
        )?,
    );
    anyhow::ensure!(window.scale_factor() == 1.0, "A1 scale changed");
    let instance = crate::gui_runtime_support::diagnostic_instance();
    let surface = instance.create_surface(window.clone())?;
    let adapter = pollster::block_on(instance.request_adapter(&wgpu::RequestAdapterOptions {
        power_preference: wgpu::PowerPreference::LowPower,
        compatible_surface: Some(&surface),
        force_fallback_adapter: false,
    }))?;
    let identity = adapter.get_info();
    anyhow::ensure!(
        identity.name.contains("P630") && identity.backend == wgpu::Backend::Vulkan,
        "A1 host/backend differs"
    );
    anyhow::ensure!(
        identity.driver_info.contains("25.0.7"),
        "A1 driver differs: {}",
        identity.driver_info
    );
    let caps = surface.get_capabilities(&adapter);
    let usage = wgpu::TextureUsages::RENDER_ATTACHMENT
        | wgpu::TextureUsages::COPY_DST
        | wgpu::TextureUsages::COPY_SRC;
    anyhow::ensure!(
        caps.usages.contains(usage),
        "A1 native COPY_SRC/COPY_DST capability absent"
    );
    let mut config =
        crate::gui_runtime_support::surface_configuration(&caps, window.inner_size(), None);
    anyhow::ensure!(
        config.width == 1280
            && config.height == 800
            && config.format == wgpu::TextureFormat::Bgra8UnormSrgb
            && config.present_mode == wgpu::PresentMode::Fifo,
        "A1 surface identity differs"
    );
    config.usage |= wgpu::TextureUsages::COPY_SRC;
    anyhow::ensure!(
        adapter
            .get_texture_format_features(config.format)
            .flags
            .sample_count_supported(8),
        "A1 exact8 absent"
    );
    let features = wgpu::Features::TEXTURE_ADAPTER_SPECIFIC_FORMAT_FEATURES
        | wgpu::Features::TIMESTAMP_QUERY
        | wgpu::Features::TIMESTAMP_QUERY_INSIDE_ENCODERS
        | wgpu::Features::TIMESTAMP_QUERY_INSIDE_PASSES;
    anyhow::ensure!(
        adapter.features().contains(features),
        "A1 timestamp features absent"
    );
    let (device, queue) = pollster::block_on(adapter.request_device(&wgpu::DeviceDescriptor {
        required_features: features,
        ..Default::default()
    }))?;
    let health =
        crate::native_device_recovery::DeviceHealth::observe(&device, event_loop.create_proxy());
    let mut transaction =
        crate::native_surface_transaction::SurfaceTransaction::new(&window, &health);
    let mut renderer = Renderer::new(&device, &queue, config.format, 8)?;
    pollster::block_on(renderer.admit_damage_restoration(&device, &adapter));
    writer.record(serde_json::json!({"kind":"identity","adapter":format!("{identity:?}"),"usage":format!("{:?}",config.usage),"format":format!("{:?}",config.format)}))?;
    check_storage(storage)?;
    let mut observations = 0;
    let mut submissions=renderer.attribution_conformance(&device,&queue,|repeat,case,ticks,period| {
        observations+=1;
        writer.record(serde_json::json!({"kind":"conformance","repeat":repeat,"case":case,"ticks":ticks,"period_ns":period}))
    })?;
    let state = datum_gui_protocol::load_board_editor_workspace_state(
        &datum_gui_protocol::LiveReviewRequest {
            project_root: std::env::var_os("DATUM_NATIVE_TEST_PROJECT")
                .context("A1 pinned project missing")?
                .into(),
            board_file: None,
            artifact_path: None,
            net_uuid: None,
            from_anchor_pad_uuid: None,
            to_anchor_pad_uuid: None,
            profile: None,
            kicad_board_source: None,
        },
    )?;
    anyhow::ensure!(state.scene.pads.len() == 81, "A1 fixture differs");
    for (case, correctness) in [(0, true), (1, true), (0, false), (1, false)] {
        let mut fixture = renderer.attribution_case(&device, &queue, &state, case, submissions)?;
        check_storage(storage)?;
        if correctness {
            let root =
                std::env::var_os("DATUM_A1_ARTIFACT_DIR").context("A1 artifact directory")?;
            fixture.save_reference(
                &std::path::Path::new(&root).join(format!("reference-{case}.png")),
            )?;
        }
        writer.record(serde_json::json!({"kind":"command_manifest","case":case,"correctness":correctness,"commands":fixture.manifest}))?;
        for id in schedule::schedule(case, correctness) {
            check_storage(storage)?;
            anyhow::ensure!(
                started.elapsed().as_secs_f64() < 300.0 && observations < 646,
                "A1 process/observation cap"
            );
            device.poll(wgpu::PollType::Poll)?;
            let mut native = crate::native_surface_transaction::NativeRenderTarget::new(
                &mut transaction,
                &surface,
                &device,
                &queue,
                &config,
                &health,
            );
            let acquired = Instant::now();
            let target = native
                .acquire()?
                .context("A1 native acquisition deferred/failed")?;
            let acquire_ms = acquired.elapsed().as_secs_f64() * 1000.0;
            let texture = target
                .copy_destination([1280, 800], config.format)
                .context("A1 target copy capability")?;
            anyhow::ensure!(texture.usage().contains(usage), "A1 acquired usage differs");
            let result = fixture.observe(&mut renderer, &device, &queue, texture, id.condition)?;
            schedule::validate(id, id, &result.ticks)?;
            native.submitted(result.submission);
            let (frame, _) = native.finish(&renderer);
            let presentation = Instant::now();
            transaction.present(frame.context("A1 missing native frame")?, &window)?;
            let present_ms = presentation.elapsed().as_secs_f64() * 1000.0;
            observations += 1;
            writer.record(serde_json::json!({"kind":"sample","case":case,"phase":id.phase,"block":id.block,"cycle":id.cycle,"condition":id.condition.to_string(),"phases_ms":result.phases_ms,"ticks":result.ticks,"period_ns":result.period_ns,"upload_bytes":result.upload_bytes,"image_hash":result.image_hash,"gpu_bytes":result.gpu_bytes,"tiles":result.tiles,"acquire_ms":acquire_ms,"present_ms":present_ms,"submissions":fixture.submissions}))?;
        }
        submissions = fixture.submissions;
        drop(fixture);
    }
    anyhow::ensure!(
        observations == 646 && submissions <= 2200,
        "A1 incomplete or over-cap study"
    );
    drop(renderer);
    device.poll(wgpu::PollType::wait_indefinitely())?;
    anyhow::ensure!(
        started.elapsed().as_secs_f64() < 300.0,
        "A1 cleanup deadline"
    );
    writer.record(serde_json::json!({"kind":"complete","observations":observations,"submissions":submissions,"seconds":started.elapsed().as_secs_f64()}))
}

fn check_storage(storage: &datum_gui_render::cpu_alloc::Scope) -> Result<()> {
    let used = storage.usage();
    anyhow::ensure!(
        used.allocator_installed
            && used.peak_payload_bytes + used.tracking_bytes + used.owner_metadata_bytes
                <= 64 * 1024 * 1024,
        "A1 diagnostic CPU storage cap: {used:?}"
    );
    Ok(())
}
