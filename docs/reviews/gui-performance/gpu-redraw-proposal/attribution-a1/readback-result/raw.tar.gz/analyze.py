"""A1's predeclared descriptive contrasts; no tail-fitting or additional samples."""
import json,statistics,sys
from pathlib import Path
root=Path(__file__).parent
raw=root/'observations.jsonl'
records=[json.loads(line) for line in raw.read_text().splitlines()]
assert raw.stat().st_size<=16*1024*1024
assert records[-1]['kind']=='complete','stopped/incomplete; no completed-study attribution'
assert len([r for r in records if r['kind']=='conformance'])==16
conditions=list('NDMPABC')
expected=[]
for case,correct in [(0,True),(1,True),(0,False),(1,False)]:
 if correct: expected.extend((case,'correctness',0,0,c) for c in conditions)
 else:
  for cycle in range(4):expected.extend((case,'warmup',0,cycle,c) for c in conditions)
  for block in range(5):
   for cycle in range(8):
    offset=(8*block+cycle)%7;order=conditions[offset:]+conditions[:offset]
    if (block+cycle)%2:order.reverse()
    expected.extend((case,'measured',block,cycle,c) for c in order)
samples=[r for r in records if r['kind']=='sample']
actual=[(r['case'],r['phase'],r['block'],r['cycle'],r['condition']) for r in samples]
assert actual==expected and len(set(actual))==630
for r in samples:
 t=r['ticks'];assert (len(t)==0 if r['condition']=='N' else 2<=len(t)<=32 and all(a<=b for a,b in zip(t,t[1:])))
 r['metrics']=dict(r['phases_ms'])|{'acquire':r['acquire_ms'],'present':r['present_ms']}
 if t:r['metrics']['gpu']=(t[-1]-t[0])*r['period_ns']/1e6
 if r['condition']=='M':
  assert len(t)==10
  r['metrics']['legacy_inner']=(t[8]-t[1])*r['period_ns']/1e6
out={'status':'complete diagnostic study; not production or hardware-floor qualification','cases':{}}
median=statistics.median
for case in range(2):
 groups={c:[r for r in samples if r['case']==case and r['phase']=='measured' and r['condition']==c] for c in conditions}
 cells={}
 for c,rows in groups.items():
  assert len(rows)==40
  cells[c]={}
  for metric in rows[0]['metrics']:
   values=[r['metrics'][metric] for r in rows]
   blocks=[median(r['metrics'][metric] for r in rows if r['block']==b) for b in range(5)]
   cells[c][metric]={'block_medians_ms':blocks,'block_median_range_ms':[min(blocks),max(blocks)],'median_ms':median(values),'max_ms':max(values)}
 contrasts={}
 for a,b,metric in [('D','N','completion'),('M','D','gpu'),('M','D','completion'),('D','P','preparation'),('D','A','gpu'),('A','B','gpu'),('B','C','gpu')]:
  differences=[x-y for x,y in zip(cells[a][metric]['block_medians_ms'],cells[b][metric]['block_medians_ms'])]
  effect=median(differences);control_condition=b if (a,b) in [('D','N'),('M','D')] else a;control=cells[control_condition][metric]['median_ms']
  signal=(all(d>0 for d in differences) or all(d<0 for d in differences)) and abs(effect)>.25 and abs(effect)>.05*control
  contrasts[f'{a}-{b}:{metric}']={'block_differences_ms':differences,'median_difference_ms':effect,'control_median_ms':control,'material_signal':signal}
 out['cases'][str(case)]={'cells':cells,'contrasts':contrasts}
(root/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({case:data['contrasts'] for case,data in out['cases'].items()},indent=2))
