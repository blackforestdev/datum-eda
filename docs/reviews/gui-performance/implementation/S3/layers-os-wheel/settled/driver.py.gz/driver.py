import os,subprocess,time,json,re,hashlib,sys
from pathlib import Path
from PIL import Image,ImageChops
root=Path('/home/bfadmin/Documents/datum-eda');binary=root/'target/release/datum-gui';out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
def wait(fn):
 end=time.monotonic()+15
 while time.monotonic()<end:
  assert p.poll() is None,p.returncode
  v=fn()
  if v:return v
  time.sleep(.05)
 raise AssertionError('native predicate timeout')
def lines():
 s=log.read_text();return s.splitlines() if s.endswith('\n') else s.splitlines()[:-1]
def count():return sum('native_surface_lifecycle ' in s and '"reason":"present"' in s for s in lines())
def xdo(*args):subprocess.run(['xdotool',*map(str,args)],check=True)
def capture(name):
 path=out/(name+'.png');subprocess.run(['import','-window',wid,str(path)],check=True);return path
log=out/'native.log';log.write_text('');env=os.environ.copy();env.pop('WAYLAND_DISPLAY',None)
for k in list(env):
 if k.startswith(('DATUM_DIAGNOSTIC_','DATUM_GPU_DIAGNOSTIC_')):env.pop(k)
env.update(EDA_CLI_BIN=str(root/'target/release/datum-eda'),DATUM_GPU_MEASUREMENTS='0',DATUM_GUI_VERBOSE_LOG='1',DATUM_GUI_LOG=str(log),WINIT_UNIX_BACKEND='x11',XDG_CONFIG_HOME=str(out/'config'),XDG_CACHE_HOME=str(out/'cache'))
cmd=[str(binary),'--board','/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb','--window-size','1280x800','--initial-layout','single','--visual-scale-factor','1']
r={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'command':cmd,'steps':[]}
with (out/'stderr.log').open('w') as stream:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stream,stderr=stream)
 try:
  wid=wait(lambda:re.findall(r'surface identity window=WindowId\((\d+)\)',log.read_text()))[0];wait(lambda:count()>0)
  xdo('windowactivate','--sync',wid);xdo('mousemove','--window',wid,100,550);time.sleep(1)
  capture('initial');print('initial capture ready',flush=True)
  def step(name,button,repeats,changed):
   start=len(lines());before=count();xdo('click','--repeat',repeats,'--delay',70,button);wait(lambda:sum('mouse wheel' in s for s in lines()[start:])>=2*repeats);time.sleep(.8)
   after=count();r['steps'].append({'name':name,'before':before,'after':after,'events':[s for s in lines()[start:] if 'mouse wheel' in s]});capture(name);assert (after>before)==changed,(name,before,after)
  step('top-boundary',4,3,False)
  step('down',5,1,True)
  step('to-bottom',5,50,True)
  step('bottom-boundary',5,3,False)
  step('reverse',4,1,True)
  # Editor region excludes Layers, Inspector, bottom dock and pointer.
  box=(400,150,900,500);base=Image.open(out/'top-boundary.png').convert('RGB').crop(box)
  for name in ['top-boundary','down','to-bottom','bottom-boundary','reverse']:
   assert ImageChops.difference(base,Image.open(out/(name+'.png')).convert('RGB').crop(box)).getbbox() is None,('board changed',name)
  r['unchanged_board_crop']=list(box)
  xdo('mousemove','--window',wid,800,350);time.sleep(.4);step('editor-zoom',4,1,True)
  assert ImageChops.difference(base,Image.open(out/'editor-zoom.png').convert('RGB').crop(box)).getbbox() is not None
  xdo('key','Alt+F4');p.wait(timeout=20);assert p.returncode==0;r.update(passed=True,exit=0)
 except Exception as e:r.update(passed=False,error=str(e));print(repr(e),flush=True)
 finally:
  (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
  if p.poll() is None:p.terminate();p.wait(timeout=5)
assert r['passed'],r.get('error')
