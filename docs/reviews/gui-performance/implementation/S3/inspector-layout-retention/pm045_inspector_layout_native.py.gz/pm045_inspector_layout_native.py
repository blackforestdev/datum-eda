import os,subprocess,json
from pathlib import Path
root=Path('/home/bfadmin/Documents/datum-eda');results=[]
for backend,scale in [('x11','1.5'),('wayland','1.5')]:
 label=backend+'-'+scale
 env=os.environ.copy();env.update(DATUM_NATIVE_TEST_BACKEND=backend,DATUM_NATIVE_TEST_SCALE=scale,DATUM_NATIVE_TEST_BOARD='/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb',XDG_CONFIG_HOME='/tmp/pm045-inspector-layout-native-'+label+'-config',XDG_CACHE_HOME='/tmp/pm045-inspector-layout-native-'+label+'-cache',EDA_CLI_BIN=str(root/'target/release/datum-eda'))
 cmd=['python3','scripts/run_cargo_guarded.py','--workload','proof','--','cargo','test','--offline','-p','datum-gui-app','--bin','datum-gui','native_layers_route_preserves_preparation_camera_and_boundary_damage','--','--ignored','--test-threads=1','--nocapture']
 log=Path('/tmp/pm045-inspector-layout-native-'+label+'.log')
 with log.open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
 results.append({'backend':backend,'scale':scale,'exit':r.returncode,'command':cmd});print(label,r.returncode,flush=True)
 Path('/tmp/pm045-inspector-layout-native-results.json').write_text(json.dumps(results,indent=2)+'\n')
 assert r.returncode==0,log.read_text()[-1800:]
