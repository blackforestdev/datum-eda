#!/usr/bin/env bash
set -euo pipefail
# These existing Python gate entry points invoke Cargo internally.
python3() {
    case "${1:-}" in
        scripts/run_terminal_core_proof.py|scripts/check_gui_conformance.py)
            command python3 scripts/run_cargo_guarded.py --workload proof -- python3 "$@" ;;
        *) command python3 "$@" ;;
    esac
}
export -f python3
export CARGO_NET_OFFLINE=true
bash scripts/run_drift_gates.sh
