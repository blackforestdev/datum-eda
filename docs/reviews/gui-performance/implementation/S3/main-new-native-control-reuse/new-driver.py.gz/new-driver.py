import os,subprocess,time,json,re,hashlib,ctypes as C,sys
from pathlib import Path
root=Path('/home/bfadmin/Documents/datum-eda');binary=Path(os.environ.get('PM045_GUI_BIN',root/'target/release/datum-gui'));out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
log=out/'native.log';log.write_text('');env=os.environ.copy();env.pop('WAYLAND_DISPLAY',None)
for k in list(env):
 if k.startswith(('DATUM_DIAGNOSTIC_','DATUM_GPU_DIAGNOSTIC_')):env.pop(k)
env.update(WINIT_UNIX_BACKEND='x11',DATUM_GUI_VERBOSE_LOG='1',DATUM_GUI_LOG=str(log),DATUM_GPU_MEASUREMENTS='0',EDA_CLI_BIN=str(root/'target/release/datum-eda'),XDG_CONFIG_HOME=str(out/'config'),XDG_CACHE_HOME=str(out/'cache'))
x=C.CDLL('libX11.so.6');xt=C.CDLL('libXtst.so.6')
x.XOpenDisplay.argtypes=[C.c_char_p];x.XOpenDisplay.restype=C.c_void_p;x.XCloseDisplay.argtypes=[C.c_void_p];x.XSync.argtypes=[C.c_void_p,C.c_int]
x.XKeysymToKeycode.argtypes=[C.c_void_p,C.c_ulong];x.XKeysymToKeycode.restype=C.c_uint
xt.XTestFakeKeyEvent.argtypes=[C.c_void_p,C.c_uint,C.c_int,C.c_ulong]
display=x.XOpenDisplay(None);assert display;tab=x.XKeysymToKeycode(display,0xff09);assert tab
cmd=[str(binary),'--board','/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb','--window-size','1280x800','--initial-layout','single','--open-new-project','--visual-scale-factor','1']
report={'command':cmd,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'actions':[],'samples':[]}
with (out/'stderr.log').open('w') as stderr:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stderr,stderr=stderr)
 def wait(fn):
  end=time.monotonic()+20
  while time.monotonic()<end:
   assert p.poll() is None,('process exited',p.returncode)
   val=fn()
   if val:return val
   time.sleep(.03)
  raise AssertionError('predicate timeout')
 def records():
  return [json.loads(s.split('native_surface_lifecycle ',1)[1]) for s in log.read_text().splitlines() if 'native_surface_lifecycle ' in s and s.endswith('}')]
 def count(window):return sum(r.get('reason')=='present' and r.get('window')==window for r in records())
 def builds(window):return [int(v) for v in re.findall(r'native control_meshes window='+re.escape(window)+r' builds=(\d+)',log.read_text())]
 def delivered():return sum('window event '+key+' keyboard physical=Code(Tab)' in s and 'state=Released' in s and 'synthetic=false' in s for s in log.read_text().splitlines())
 try:
  ids=wait(lambda:v if len(v:=re.findall(r'surface identity window=WindowId\((\d+)\)',log.read_text()))==2 else None)
  main='WindowId('+ids[0]+')';wid=ids[1];key='WindowId('+wid+')';wait(lambda:count(key)>0)
  subprocess.run(['xdotool','windowactivate','--sync',wid,'windowsize',wid,'760','720','getwindowfocus'],env=env,check=True,stdout=subprocess.PIPE,timeout=8)
  wait(lambda:any(r.get('window')==key and r.get('reason')=='present' and r.get('configured_extent')==[760,720] for r in records()))
  report['presented_extent']=[760,720];main_frames=count(main);main_prepares=len(builds(main))
  subprocess.run(['import','-window',wid,str(out/'initial.png')],env=env,check=True,timeout=8)
  for cycle in range(2):
   for step in range(5):
    before=count(key);released=delivered();report['actions'].append({'key':'Tab','cycle':cycle,'step':step,'wall_time':time.time(),'transport':'persistent XTest'})
    assert xt.XTestFakeKeyEvent(display,tab,1,0);assert xt.XTestFakeKeyEvent(display,tab,0,0);x.XSync(display,0)
    wait(lambda:delivered()>released);wait(lambda:count(key)>before)
    report['samples'].append({'cycle':cycle,'step':step,'builds':builds(key)[-1],'presentations':count(key)})
   time.sleep(.3);subprocess.run(['import','-window',wid,str(out/f'cycle-{cycle}.png')],env=env,check=True,timeout=8)
  steady=[r['builds'] for r in report['samples'] if r['cycle']==1]
  report['main_presentations_during_cycles']=count(main)-main_frames;report['main_preparations_during_cycles']=len(builds(main))-main_prepares
  assert steady[0]>0 and len(set(steady))==1,'warm native NEW focus cycle rebuilt controls'
  assert report['main_presentations_during_cycles']==report['main_preparations_during_cycles']==0,'dialog focus dirtied Main'
  report['passed']=True
 except Exception as e:report.update(passed=False,error=repr(e))
 finally:
  xt.XTestFakeKeyEvent(display,tab,0,0);x.XSync(display,0);x.XCloseDisplay(display)
  if p.poll() is None:p.terminate();p.wait(timeout=10)
  report['cleanup']='Owned process SIGTERM; no teardown qualification';(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
assert report['passed'],report.get('error')
print('NEW native focus-cycle control reuse PASS',flush=True)
