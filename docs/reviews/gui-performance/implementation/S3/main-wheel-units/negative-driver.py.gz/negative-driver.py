from pathlib import Path
import subprocess,os,json,hashlib,difflib,re
root=Path('/home/bfadmin/Documents/datum-eda');copy=Path('/tmp/pm045-pinned-negative-source')
names=[n for n in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','.cargo'],cwd=root,text=True).split('\0') if n]
updated=[];h=hashlib.sha256()
for name in sorted(names):
 p=root/name;q=copy/name
 if not p.is_file():continue
 data=p.read_bytes();h.update(name.encode()+b'\0'+data+b'\0')
 if not q.is_file() or q.read_bytes()!=data:q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);updated.append(name)
 assert q.read_bytes()==data
relative='crates/gui-app/src/native_scroll_input.rs';p=copy/relative;original=p.read_text()
needle='position.y / f64::from(scale)';assert original.count(needle)==1
bad=original.replace(needle,'position.y / f64::from(scale * scale)')
Path('/tmp/pm045-main-wheel-negative.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),bad.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)))
results=[]
def run(label,backend,manifest=None):
 env=os.environ.copy();env.update(DATUM_NATIVE_TEST_BACKEND=backend,DATUM_NATIVE_TEST_SCALE='1.5',DATUM_NATIVE_TEST_BOARD='/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb',XDG_CONFIG_HOME='/tmp/pm045-main-wheel-proof-'+label+'-config',XDG_CACHE_HOME='/tmp/pm045-main-wheel-proof-'+label+'-cache',EDA_CLI_BIN=str(root/'target/release/datum-eda'),CARGO_TARGET_DIR=str(root/'target'))
 cmd=['python3',str(root/'scripts/run_cargo_guarded.py'),'--workload','proof','--','cargo','test','--offline']
 if manifest:cmd+=['--manifest-path',str(manifest)]
 cmd+=['-p','datum-gui-app','--bin','datum-gui','native_layers_route_preserves_preparation_camera_and_boundary_damage','--','--ignored','--test-threads=1','--nocapture']
 log=Path('/tmp/pm045-main-wheel-proof-'+label+'.log')
 with log.open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
 text=log.read_text();match=re.search(r'Running unittests .*?\(([^)]+)\)',text);assert match,'test did not execute'
 binary=Path(match[1]);binary=binary if binary.is_absolute() else root/binary
 results.append({'label':label,'backend':backend,'exit':r.returncode,'command':cmd,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'recompiled_app':'Compiling datum-gui-app' in text})
 return r.returncode,text
try:
 p.write_text(bad)
 for backend in ['x11','wayland']:
  code,log=run('negative-'+backend,backend,copy/'Cargo.toml')
  assert code==101 and 'Layers physical/line disagreement at scale=1.5 lines=-1.25' in log,log[-1800:]
finally:p.write_text(original)
# Force the active source's app rebuild; Cargo shares this owned target cache.
os.utime(root/relative,None)
for backend in ['x11','wayland']:
 code,log=run('restored-'+backend,backend)
 assert code==0 and '1 passed; 0 failed' in log,log[-1800:]
assert results[2]['recompiled_app']
assert p.read_text()==(root/relative).read_text()
Path('/tmp/pm045-main-wheel-negative-result.json').write_text(json.dumps({'compiled_input_digest':h.hexdigest(),'compiled_input_count':len(names),'copy_synced':updated,'source_sha256':hashlib.sha256(original.encode()).hexdigest(),'runs':results},indent=2)+'\n')
print('Both backends detect Layers double scaling; rebuilt root passes both',flush=True)
