from pathlib import Path
import subprocess,os,json,hashlib,difflib,re
root=Path('/home/bfadmin/Documents/datum-eda');copy=Path('/tmp/pm045-pinned-negative-source');p=copy/'crates/gui-app/src/app_native_events.rs';original=p.read_text()
needle='WindowEvent::ScaleFactorChanged { .. } | WindowEvent::Focused(false)'
assert original.count(needle)==1
bad=original.replace(needle,'WindowEvent::ScaleFactorChanged { .. }')
Path('/tmp/pm045-native-cancel-negative.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),bad.splitlines(True),fromfile='a/crates/gui-app/src/app_native_events.rs',tofile='b/crates/gui-app/src/app_native_events.rs')))
env=os.environ.copy();env.pop('WAYLAND_DISPLAY',None);env.update(WINIT_UNIX_BACKEND='x11',DATUM_NATIVE_TEST_BOARD='/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb',XDG_CONFIG_HOME='/tmp/pm045-native-cancel-negative-config',XDG_CACHE_HOME='/tmp/pm045-native-cancel-negative-cache',EDA_CLI_BIN=str(root/'target/release/datum-eda'),CARGO_TARGET_DIR=str(root/'target'))
cmd=['python3',str(root/'scripts/run_cargo_guarded.py'),'--workload','proof','--','cargo','test','--offline','--manifest-path',str(copy/'Cargo.toml'),'-p','datum-gui-app','--bin','datum-gui','native_dialog_scroll_release_cannot_click_through_to_controls','--','--ignored','--test-threads=1','--nocapture']
results=[]
def run(label):
 log=Path('/tmp/pm045-native-cancel-'+label+'.log')
 with log.open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 text=log.read_text();binary=Path(re.search(r'Running unittests .*?\(([^)]+)\)',text)[1]);binary=binary if binary.is_absolute() else root/binary
 results.append({'label':label,'exit':r.returncode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'recompiled_app':'Compiling datum-gui-app' in text})
 return r.returncode,text
try:
 p.write_text(bad);n,nt=run('negative')
finally:p.write_text(original)
r,rt=run('restored')
Path('/tmp/pm045-native-cancel-negative-result.json').write_text(json.dumps({'command':cmd,'runs':results,'restored_source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n')
assert n==101 and 'focus loss must clear capture ownership for host 0' in nt
assert r==0 and '1 passed; 0 failed' in rt
assert results[-1]['recompiled_app'] and results[0]['binary_sha256']!=results[1]['binary_sha256']
assert p.read_text()==original
print('Missing focus-loss cancellation detected; recompiled restored positive passed',flush=True)
