#!/usr/bin/python3
import os,sys,subprocess
from pathlib import Path
cargo='/usr/bin/cargo'
guard='/home/bfadmin/Documents/datum-eda/scripts/run_cargo_guarded.py'
parent=Path('/proc/'+str(os.getppid())+'/cmdline').read_bytes().split(b'\0')
compiles={'build','check','test','clippy','run','rustc'}
if len(sys.argv)<2 or sys.argv[1] not in compiles or any(p.endswith(b'/run_cargo_guarded.py') or p==b'scripts/run_cargo_guarded.py' for p in parent):
 os.execv(cargo,[cargo,*sys.argv[1:]])
result=subprocess.run([sys.executable,guard,'--workload','proof','--',cargo,*sys.argv[1:]],stdout=subprocess.PIPE)
# Guard diagnostics remain visible on stderr; preserve Cargo's JSON stdout.
for line in result.stdout.splitlines(keepends=True):
 stream=sys.stderr.buffer if line.startswith((b'Cargo resource preflight:',b'warning: Cargo target exceeds soft limit:')) else sys.stdout.buffer
 stream.write(line);stream.flush()
sys.exit(result.returncode)
