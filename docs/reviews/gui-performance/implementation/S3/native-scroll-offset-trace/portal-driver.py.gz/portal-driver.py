import gi,json,time,sys,select
from pathlib import Path
from gi.repository import Gio,GLib
out=Path('/tmp/pm045-timed-scroll-portal');out.mkdir(exist_ok=True)
conn=Gio.bus_get_sync(Gio.BusType.SESSION,None);ctx=GLib.MainContext.default();responses={};records=[];session=None
interface='org.freedesktop.portal.RemoteDesktop';dest='org.freedesktop.portal.Desktop';path='/org/freedesktop/portal/desktop'
def record(kind,**fields):
 row={'time':time.time(),'kind':kind,**fields};records.append(row);print(json.dumps(row),flush=True);(out/'result.json').write_text(json.dumps(records,indent=2)+'\n')
def signal(c,s,p,i,n,args,data):responses[p]=args.unpack()
conn.signal_subscribe(dest,'org.freedesktop.portal.Request','Response',None,None,Gio.DBusSignalFlags.NONE,signal,None)
def request(method,signature,args):
 handle=conn.call_sync(dest,path,interface,method,GLib.Variant(signature,args),None,Gio.DBusCallFlags.NONE,10000,None).unpack()[0]
 record('request',method=method,handle=handle)
 end=time.monotonic()+600
 while handle not in responses:
  while ctx.pending():ctx.iteration(False)
  if time.monotonic()>end:raise TimeoutError(method+' consent/response timeout')
  time.sleep(.05)
 code,result=responses.pop(handle);record('response',method=method,code=code,result=result)
 if code:raise RuntimeError(method+' response '+str(code))
 return result
try:
 token='pm045_'+str(int(time.time()))
 session=request('CreateSession','(a{sv})',({'handle_token':GLib.Variant('s',token+'_create'),'session_handle_token':GLib.Variant('s',token+'_session')},))['session_handle']
 request('SelectDevices','(oa{sv})',(session,{'types':GLib.Variant('u',3),'handle_token':GLib.Variant('s',token+'_select')}))
 request('Start','(osa{sv})',(session,'',{'handle_token':GLib.Variant('s',token+'_start')}))
 record('ready',note='Input only; no ScreenCast session or network connection. Awaiting bounded test commands.')
 end=time.monotonic()+600
 while time.monotonic()<end:
  while ctx.pending():ctx.iteration(False)
  if not select.select([sys.stdin],[],[],.1)[0]:continue
  line=sys.stdin.readline()
  if not line:break
  cmd=json.loads(line)
  if cmd['action']=='close':break
  if cmd['action']=='axis_stream':
   duration=float(cmd['duration']);hz=int(cmd['hz']);amplitude=float(cmd['amplitude'])
   assert duration==30 and hz==120 and 0<amplitude<=1
   record('stream_start',command=cmd)
   start=time.monotonic();wall=time.time();count=int(duration*hz);late=[]
   for index in range(count):
    deadline=start+index/hz
    remaining=deadline-time.monotonic()
    if remaining>0:time.sleep(remaining)
    y=amplitude if (index//(2*hz))%2==0 else -amplitude
    actual=time.monotonic();late.append(actual-deadline)
    conn.call_sync(dest,path,interface,'NotifyPointerAxis',GLib.Variant('(oa{sv}dd)',(session,{},0.,y)),None,Gio.DBusCallFlags.NONE,5000,None)
    records.append({'time':time.time(),'kind':'stream_input','index':index,'scheduled_time':wall+index/hz,'lateness_seconds':actual-deadline,'axis_y':y})
   remaining=start+duration-time.monotonic()
   if remaining>0:time.sleep(remaining)
   record('stream_end',count=count,elapsed=time.monotonic()-start,max_lateness_seconds=max(late))
   continue
  methods={'motion':('NotifyPointerMotion','(oa{sv}dd)',('x','y'),float),'axis':('NotifyPointerAxis','(oa{sv}dd)',('x','y'),float),'button':('NotifyPointerButton','(oa{sv}iu)',('button','state'),int),'key':('NotifyKeyboardKeysym','(oa{sv}iu)',('key','state'),int)}
  method,sig,keys,convert=methods[cmd['action']]
  values=[convert(cmd[key]) for key in keys]
  conn.call_sync(dest,path,interface,method,GLib.Variant(sig,(session,{},*values)),None,Gio.DBusCallFlags.NONE,5000,None)
  record('input',command=cmd)
except Exception as error:
 record('error',message=repr(error));raise
finally:
 if session:
  try:conn.call_sync(dest,session,'org.freedesktop.portal.Session','Close',None,None,Gio.DBusCallFlags.NONE,5000,None);record('closed')
  except Exception as error:record('close_error',message=repr(error))
