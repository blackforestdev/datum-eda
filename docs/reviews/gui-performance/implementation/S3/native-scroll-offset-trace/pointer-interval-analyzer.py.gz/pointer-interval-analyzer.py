import gzip,json,re
from pathlib import Path
b=Path('docs/reviews/gui-performance/implementation/S3/native-scroll-offset-trace')
portal=json.loads(gzip.decompress((b/'portal-result.json.gz').read_bytes()))
start=next(r['time'] for r in portal if r['kind']=='stream_start');end=next(r['time'] for r in portal if r['kind']=='stream_end')
lines=[]
for line in gzip.decompress((b/'timed-global-native.log.gz').read_bytes()).decode().splitlines():
 m=re.search(r'tv_sec: (\d+), tv_nsec: (\d+)',line)
 if m:
  t=int(m[1])+int(m[2])*1e-9
  if start<=t<end:lines.append((t-start,line))
moves=[(t,l) for t,l in lines if 'cursor moved' in l]
first,last=moves[0][0],moves[-1][0];stable=[];bins=[0]*15
for t,l in lines:
 if 'native scroll ' not in l:continue
 bins[min(14,int(t//2))]+=1
 if first<=t<=last:continue
 m=re.search(r'y: ([^ }]+).*?scale=(\S+) before=(\S+) after=(\S+) maximum=(\S+) changed=(true|false)',l);assert m,l
 delta,scale,before,after,maximum=map(float,m.groups()[:5]);expected=min(maximum,max(0,before-delta/scale))
 assert abs(after-expected)<0.00001,(t,before,after,expected)
 stable.append(t)
r={'input_artifacts':['portal-result.json.gz','timed-global-native.log.gz'],'two_second_bins_received':bins,'scheduled_per_bin':240,'first_unscripted_motion_seconds':first,'last_unscripted_motion_seconds':last,'stable_pointer_trace_records_checked':len(stable),'stable_pointer_offset_recurrence':'Every checked after offset matches clamp(before - delivered_delta / scale,0,maximum), tolerance0.00001','observed_path':'Pointer traverses Main during the gap, then returns to Global; stationary full2-second bins each contain240 native scroll records. No scroll records in bins4/5/6.','interpretation':'Missing shared-path delivery overlaps unscripted pointer excursion. This does not establish renderer event loss, input origin, or general portal reliability. Delta mismatch remains separate.','disposition':'Failed timed trial remains failed; selected stationary intervals are not complete W-SCROLL, final-state, other-host or performance acceptance.'}
Path('/tmp/pm045-timed-pointer-analysis.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
