import json,re
from pathlib import Path
portal=json.loads(Path('/tmp/pm045-timed-scroll-resumed-portal/result.json').read_text())
starts=[r for r in portal if r['kind']=='stream_start'];ends=[r for r in portal if r['kind']=='stream_end'];assert len(starts)==len(ends)==4
summary=[]
for index,(start_record,end_record) in enumerate(zip(starts,ends)):
 host='global' if index<2 else 'project';root=Path('/tmp/pm045-timed-scroll-resumed-'+host);r=json.loads((root/'result.json').read_text());main,dialog=r['observations'][0]['surface_ids'];start,end=start_record['time'],end_record['time'];lines=[];ledgers=[]
 for line in (root/'native.log').read_text().splitlines():
  match=re.search(r'tv_sec: (\d+), tv_nsec: (\d+)',line)
  if not match:continue
  t=int(match[1])+int(match[2])*1e-9
  if 'native redraw ledger ' in line:
   row=json.loads(line.split('native redraw ledger ',1)[1])
   if row['window']==f'WindowId({main})':ledgers.append((t,row))
  if start<=t<=end:lines.append((t,line))
 scroll=[l for t,l in lines if 'native scroll ' in l];assert len(scroll)==3600
 assert not any('cursor moved' in l for t,l in lines)
 expected=None;initial=None
 for j,line in enumerate(scroll):
  m=re.search(r'y: ([^ }]+).*?scale=(\S+) before=(\S+) after=(\S+) maximum=(\S+) changed=(true|false)',line);assert m
  delta,scale,before,after,maximum=map(float,m.groups()[:5]);assert scale==1 and delta==(0.25 if j//240%2==0 else -0.25)
  if expected is None:initial=before;expected=before
  assert before==expected
  expected=min(maximum,max(0,expected-delta));assert after==expected;assert (after!=before)==(m[6]=='true')
 assert initial==(0 if index%2==0 else maximum)
 assert expected==(0 if index%2==0 else maximum-60)
 before=next(r for t,r in reversed(ledgers) if t<start);after=next(r for t,r in reversed(ledgers) if t<=end)
 changes={k:after['counts'][k]-before['counts'][k] for k in ['requested','coalesced','received','presentations']};assert changes['requested']==changes['coalesced']==0
 summary.append({'host':host,'boundary':'top' if index%2==0 else 'bottom','events':len(scroll),'initial_offset':initial,'final_offset':expected,'maximum':maximum,'exact_delta_and_recurrence':True,'unscripted_pointer_moves':0,'main_counter_deltas':changes,'strict_zero_main_presentations_pass':changes['presentations']==0,'driver':end_record})
idle=[]
for host,i in [('global',0),('project',2)]:
 root=Path('/tmp/pm045-timed-scroll-resumed-'+host);r=json.loads((root/'result.json').read_text());main=r['observations'][0]['surface_ids'][0];start=ends[i]['time'];stop=next(r['time'] for r in portal if r['kind']=='input' and r['time']>start and r['command']['action']=='axis');ledgers=[]
 for line in (root/'native.log').read_text().splitlines():
  if 'native redraw ledger ' not in line:continue
  m=re.search(r'tv_sec: (\d+), tv_nsec: (\d+)',line);t=int(m[1])+int(m[2])*1e-9;r=json.loads(line.split('native redraw ledger ',1)[1])
  if r['window']==f'WindowId({main})':ledgers.append((t,r))
 before=next(r for t,r in reversed(ledgers) if t<start);after=next(r for t,r in reversed(ledgers) if t<stop)
 idle.append({'host':host,'input_free_interval_seconds':stop-start,'main_counter_deltas':{k:after['counts'][k]-before['counts'][k] for k in ['requested','coalesced','received','presentations']}})
result={'trials':summary,'input_free_comparisons':idle,'total_events':sum(r['events'] for r in summary),'attribution':'All four streams induce zero recorded Main requests/coalesced damage. Global bottom contains one additional native received/present event; input-free intervals also contain one with zero requests. Consistent with unsolicited native redraw, not a wheel broadcast; preserve the original strict zero-presentation failure. No compositor/kernel root cause or final pixel claim.'}
Path('/tmp/pm045-resumed-timed-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
