import json,re,sys
from pathlib import Path
portal=json.loads(Path('/tmp/pm045-timed-scroll-resumed-portal/result.json').read_text());starts=[r for r in portal if r['kind']=='stream_start'];ends=[r for r in portal if r['kind']=='stream_end'];trial=int(sys.argv[2]) if len(sys.argv)>2 else -1;start=starts[trial]['time'];end=ends[trial]['time'];assert end>start
root=Path(sys.argv[1]);report=json.loads((root/'result.json').read_text());main,dialog=report['observations'][0]['surface_ids'];rows=[];moves=[];frames=[]
for line in (root/'native.log').read_text().splitlines():
 m=re.search(r'tv_sec: (\d+), tv_nsec: (\d+)',line)
 if not m:continue
 t=int(m[1])+int(m[2])*1e-9
 if not start<=t<=end:continue
 if 'cursor moved' in line:moves.append(line)
 if 'native scroll ' in line:rows.append(line)
 if 'native_surface_lifecycle ' in line:
  row=json.loads(line.split('native_surface_lifecycle ',1)[1])
  if row['reason']=='present':frames.append(row)
assert len(rows)==3600,len(rows)
assert not moves,len(moves)
previous=None
for index,line in enumerate(rows):
 m=re.search(r'y: ([^ }]+).*?scale=(\S+) before=(\S+) after=(\S+) maximum=(\S+) changed=(true|false)',line);assert m
 delta,scale,before,after,maximum=map(float,m.groups()[:5]);assert scale==1 and delta==(0.25 if index//240%2==0 else -0.25)
 if previous is not None:assert before==previous
 assert after==min(maximum,max(0,before-delta)),(index,before,delta,after)
 assert (after!=before)==(m[6]=='true');previous=after
main_count=sum(row['window']==f'WindowId({main})' for row in frames)
result={'host':report['host'],'start':start,'end':end,'input_count':len(rows),'unscripted_pointer_moves':len(moves),'exact_delta_and_offset_recurrence':True,'final_offset':previous,'maximum':maximum,'main_frames':main_count,'locality_pass':main_count==0,'dialog_frames':len(frames)-main_count,'driver':ends[trial]}
print(json.dumps(result));path=root/'timed-analysis.json';out=json.loads(path.read_text()) if path.exists() else [];out.append(result);path.write_text(json.dumps(out,indent=2)+'\n')
