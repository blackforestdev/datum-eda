import os,sys,time,json,re,hashlib,subprocess,select,shutil
from pathlib import Path
records=json.loads(Path('/tmp/pm045-timed-scroll-resumed-portal/result.json').read_text())
assert any(r['kind']=='ready' for r in records), 'KDE input consent not granted'
assert not any(r['kind'] in ('closed','close_error','error') for r in records), 'portal session is not live'
root=Path('/home/bfadmin/Documents/datum-eda');out=Path(sys.argv[1]);host=sys.argv[2];assert host in ('GLOBAL','PROJECT');out.mkdir(exist_ok=False)
shutil.copytree('/tmp/pm045-reduced-motion-native-setup/GLOBAL/config',out/'config')
log=out/'native.log';log.write_text('');env=os.environ.copy();assert env.get('WAYLAND_DISPLAY')
for key in list(env):
 if key.startswith(('DATUM_DIAGNOSTIC_','DATUM_GPU_DIAGNOSTIC_')):env.pop(key)
env.update(EDA_CLI_BIN=str(root/'target/release/datum-eda'),WINIT_UNIX_BACKEND='wayland',DATUM_GUI_LOG=str(log),DATUM_GUI_VERBOSE_LOG='1',DATUM_GPU_MEASUREMENTS='1',DATUM_TRACE_TIMING='1',XDG_CONFIG_HOME=str(out/'config'),XDG_CACHE_HOME=str(out/'cache'))
binary=root/'target/release/datum-gui';flag='--open-global-preferences' if host=='GLOBAL' else '--open-project-preferences'
cmd=[str(binary),'--board','/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb','--initial-layout','single','--window-size','1280x800','--visual-scale-factor','1',flag]
report={'host':host,'command':cmd,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'observations':[]}
def snapshot():
 lines=log.read_text().splitlines();ids=re.findall(r'surface identity window=WindowId\((\d+)\)',log.read_text());rows=[]
 for line in lines:
  if 'native_surface_lifecycle ' in line and line.endswith('}'):
   rows.append(json.loads(line.split('native_surface_lifecycle ',1)[1]))
 return {'time':time.time(),'surface_ids':ids,'identities':[s for s in lines if 'surface identity window=' in s],'presents':{wid:sum(r['reason']=='present' and r['window']=='WindowId('+wid+')' for r in rows) for wid in ids},'extents':{r['window']:r['configured_extent'] for r in rows if r['reason']=='present'},'pointer_events':[s for s in lines if 'window event' in s and any(k in s for k in ('cursor moved','mouse input','mouse wheel','focused'))][-12:]}
with (out/'stderr.log').open('w') as stderr:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stderr,stderr=stderr);report['pid']=p.pid
 try:
  end=time.monotonic()+30
  while True:
   assert p.poll() is None,('process exited',p.returncode)
   s=snapshot()
   if len(s['surface_ids'])==2 and all(v>0 for v in s['presents'].values()):break
   assert time.monotonic()<end,'native startup timeout'
   time.sleep(.05)
  assert all('window_backend=wayland' in line for line in s['identities'])
  report['observations'].append(s);(out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'ready':True,'pid':p.pid,**s}),flush=True)
  end=time.monotonic()+600
  while p.poll() is None and time.monotonic()<end:
   if not select.select([sys.stdin],[],[],.1)[0]:continue
   line=sys.stdin.readline()
   if not line or line.strip()=='close':break
   assert line.strip()=='status'
   s=snapshot();report['observations'].append(s);(out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(s),flush=True)
 finally:
  if p.poll() is None:p.terminate();p.wait(timeout=10)
  report['cleanup']='Owned process SIGTERM; no teardown qualification';(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
