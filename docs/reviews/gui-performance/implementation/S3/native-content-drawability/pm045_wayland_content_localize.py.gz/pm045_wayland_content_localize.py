from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/home/bfadmin/Documents/datum-eda');copy=Path('/tmp/pm045-pinned-negative-source')
for name in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','.cargo'],cwd=root,text=True).split('\0'):
 if not name:continue
 p=root/name;q=copy/name
 if p.is_file() and (not q.is_file() or q.read_bytes()!=p.read_bytes()):q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
p=copy/'crates/gui-app/src/owned_dialog_pointer_tests.rs';original=p.read_text();s=original.replace('if backend == "x11" {','if backend == "x11" || backend == "wayland" {')
for old,label in [('surface(app, index).window.set_visible(true);','visible'),('let physical = surface(app, index).window.inner_size();','inner_size'),('deliver(events, app, id, WindowEvent::RedrawRequested);','redraw_delivery'),('app.dispatch_native_frame_round(active);','dispatch')]:
 assert old in s
 s=s.replace(old,'eprintln!("LOCALIZE '+label+' enter");\n        '+old+'\n        eprintln!("LOCALIZE '+label+' leave");',1)
p.write_text(s)
env=os.environ.copy();env.update(DATUM_NATIVE_TEST_BACKEND='wayland',DATUM_NATIVE_TEST_BOARD='/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb',XDG_CONFIG_HOME='/tmp/pm045-content-localize-config',XDG_CACHE_HOME='/tmp/pm045-content-localize-cache',EDA_CLI_BIN=str(root/'target/release/datum-eda'),CARGO_TARGET_DIR=str(root/'target'),DATUM_GUI_VERBOSE_LOG='1',DATUM_GUI_LOG='/tmp/pm045-content-localize-native.log')
cmd=['timeout','--signal=TERM','--kill-after=5s','45s','python3',str(root/'scripts/run_cargo_guarded.py'),'--workload','proof','--','cargo','test','--offline','--manifest-path',str(copy/'Cargo.toml'),'-p','datum-gui-app','--bin','datum-gui','native_dialog_scroll_release_cannot_click_through_to_controls','--','--ignored','--test-threads=1','--nocapture']
try:
 with Path('/tmp/pm045-content-localize.log').open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 Path('/tmp/pm045-content-localize-result.json').write_text(json.dumps({'command':cmd,'exit':r.returncode,'test_source_sha256':hashlib.sha256(s.encode()).hexdigest()},indent=2)+'\n')
 print('localization exit',r.returncode,flush=True)
finally:p.write_text(original)
