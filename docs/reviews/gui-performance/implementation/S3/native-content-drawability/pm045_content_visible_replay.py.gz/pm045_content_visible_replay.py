from pathlib import Path
import os,subprocess,time,json,signal
root=Path('/home/bfadmin/Documents/datum-eda');env=os.environ.copy();env.update(DATUM_NATIVE_TEST_BACKEND='wayland',DATUM_NATIVE_TEST_BOARD='/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb',XDG_CONFIG_HOME='/tmp/pm045-content-visible-config',XDG_CACHE_HOME='/tmp/pm045-content-visible-cache',EDA_CLI_BIN=str(root/'target/release/datum-eda'))
cmd=['python3',str(root/'scripts/run_cargo_guarded.py'),'--workload','proof','--','cargo','test','--offline','-p','datum-gui-app','--bin','datum-gui','native_dialog_scroll_release_cannot_click_through_to_controls','--','--ignored','--test-threads=1','--nocapture'];records=[]
def children(pid):
 try:return [int(x) for x in Path(f'/proc/{pid}/task/{pid}/children').read_text().split()]
 except FileNotFoundError:return []
def test_pids(pid):
 found=[]
 for child in children(pid):
  try:name=Path(f'/proc/{child}/exe').resolve().name
  except OSError:continue
  if name.startswith('datum_gui-'):found.append(child)
  else:found.extend(test_pids(child))
 return found
with Path('/tmp/pm045-content-visible.log').open('w') as f:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);end=time.monotonic()+75
 try:
  while p.poll() is None and time.monotonic()<end:
   for pid in test_pids(p.pid):
    r=subprocess.run(['/usr/bin/python3','/tmp/pm045_owned_window_geometry.py',str(pid),'--any-title','--activate'],capture_output=True,text=True,timeout=12)
    records.append({'pid':pid,'time':time.time(),'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
   time.sleep(.3)
 finally:
  if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5)
Path('/tmp/pm045-content-visible-result.json').write_text(json.dumps({'command':cmd,'exit':p.returncode,'owned_window_activations':records},indent=2)+'\n');print('visible replay exit',p.returncode,flush=True)
