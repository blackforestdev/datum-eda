import sys,json,time,subprocess
from pathlib import Path
from gi.repository import Gio,GLib
pid=int(sys.argv[1]);title=sys.argv[2];activate='--activate' in sys.argv[3:]
conn=Gio.bus_get_sync(Gio.BusType.SESSION,None);result=[]
xml='<node><interface name="org.datum.PM045Probe"><method name="Result"><arg type="s" direction="in"/></method></interface></node>'
info=Gio.DBusNodeInfo.new_for_xml(xml).interfaces[0]
def receive(c,s,p,i,m,args,reply):result.append(json.loads(args.unpack()[0]));reply.return_value(GLib.Variant('()',()))
registration=conn.register_object('/pm045_probe',info,receive,None,None)
name='pm045_geometry_'+str(time.monotonic_ns());path=Path('/tmp')/(name+'.js')
body='const found = workspace.windowList().filter(w => Number(w.pid) === '+str(pid)+('' if title == '--any-title' else ' && w.caption === '+json.dumps(title))+'); '
body+='const rows = found.map(w => { '+('workspace.activeWindow = w; ' if activate else '')+'const r = w.frameGeometry; const c = w.clientGeometry; const cursor = workspace.cursorPos; return {pid:Number(w.pid),caption:w.caption,x:r.x,y:r.y,width:r.width,height:r.height,client:c ? {x:c.x,y:c.y,width:c.width,height:c.height} : null,cursor:cursor ? {x:cursor.x,y:cursor.y} : null}; }); '
body+='callDBus('+json.dumps(conn.get_unique_name())+', "/pm045_probe", "org.datum.PM045Probe", "Result", JSON.stringify(rows));'
path.write_text(body)
sid=subprocess.check_output(['qdbus6','org.kde.KWin','/Scripting','loadScript',str(path),name],text=True).strip()
try:
 subprocess.run(['qdbus6','org.kde.KWin','/Scripting/Script'+sid,'run'],check=True,stdout=subprocess.DEVNULL)
 end=time.monotonic()+10;context=GLib.MainContext.default()
 while not result:
  while context.pending():context.iteration(False)
  if time.monotonic()>end:raise TimeoutError('owned window geometry response')
  time.sleep(.02)
 print(json.dumps(result[0]))
finally:
 subprocess.run(['qdbus6','org.kde.KWin','/Scripting','unloadScript',name],check=True,stdout=subprocess.DEVNULL)
 conn.unregister_object(registration)
