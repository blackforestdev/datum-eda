from pathlib import Path
import subprocess,os,json,hashlib,difflib,re
root=Path('/home/bfadmin/Documents/datum-eda');copy=Path('/tmp/pm045-pinned-negative-source')
names=set(n for n in subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','.cargo'],cwd=root,text=True).split('\0') if n and (root/n).is_file())
names.add('crates/gui-render/src/side_panels/project_layout.rs');h=hashlib.sha256()
for name in sorted(names):
 p=root/name;q=copy/name;data=p.read_bytes();h.update(name.encode()+b'\0'+data+b'\0');q.parent.mkdir(parents=True,exist_ok=True)
 if not q.is_file() or q.read_bytes()!=data:q.write_bytes(data)
relative='crates/gui-render/src/side_panels/project_layout.rs';p=copy/relative;original=p.read_text();needle='if *previous == key {';assert original.count(needle)==1
bad=original.replace(needle,'if false && *previous == key {')
Path('/tmp/pm045-project-layout-negative.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),bad.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)))
results=[]
def run(label,manifest=None):
 env=os.environ.copy();env['CARGO_TARGET_DIR']=str(root/'target')
 cmd=['python3',str(root/'scripts/run_cargo_guarded.py'),'--workload','proof','--','cargo','test','--offline']
 if manifest:cmd+=['--manifest-path',str(manifest)]
 cmd+=['-p','datum-gui-render','--lib','actual_frame_preparation_reuses_project_geometry','--','--test-threads=1','--nocapture']
 log=Path('/tmp/pm045-project-layout-'+label+'.log')
 with log.open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
 text=log.read_text();match=re.search(r'Running unittests .*?\(([^)]+)\)',text);assert match;binary=Path(match[1]);binary=binary if binary.is_absolute() else root/binary;results.append({'label':label,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'exit':r.returncode,'command':cmd,'renderer_recompiled':'Compiling datum-gui-render' in text});return r.returncode,text
try:
 p.write_text(bad);code,log=run('negative',copy/'Cargo.toml');assert code==101 and 'warm frames must reuse Project layout' in log,log[-2000:]
finally:p.write_text(original)
os.utime(root/relative,None)
code,log=run('restored');assert code==0 and '1 passed; 0 failed' in log,log[-2000:];assert results[1]['renderer_recompiled'];assert p.read_bytes()==(root/relative).read_bytes()
Path('/tmp/pm045-project-layout-negative-result.json').write_text(json.dumps({'compiled_input_digest':h.hexdigest(),'compiled_input_count':len(names),'runs':results},indent=2)+'\n')
print('Production-consumer cache bypass detected; restored root passes',flush=True)
