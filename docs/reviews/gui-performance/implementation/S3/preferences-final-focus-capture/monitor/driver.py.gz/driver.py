import os,subprocess,time,json,re,hashlib,sys
from pathlib import Path
scale=float(os.environ['PM045_TEST_SCALE'])
root=Path('/home/bfadmin/Documents/datum-eda');binary=Path(os.environ.get('PM045_GUI_BIN',str(root/'target/release/datum-gui')));out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
assert os.environ.get('DISPLAY')
import ctypes as C, atexit
from PIL import Image
x=C.CDLL('libX11.so.6')
x.XOpenDisplay.argtypes=[C.c_char_p];x.XOpenDisplay.restype=C.c_void_p
x.XDefaultRootWindow.argtypes=[C.c_void_p];x.XDefaultRootWindow.restype=C.c_ulong
x.XCreateSimpleWindow.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_int,C.c_uint,C.c_uint,C.c_uint,C.c_ulong,C.c_ulong];x.XCreateSimpleWindow.restype=C.c_ulong
x.XMapWindow.argtypes=[C.c_void_p,C.c_ulong];x.XSetInputFocus.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_ulong]
x.XFlush.argtypes=[C.c_void_p];x.XDestroyWindow.argtypes=[C.c_void_p,C.c_ulong];x.XCloseDisplay.argtypes=[C.c_void_p]
d=x.XOpenDisplay(None);assert d
xt=C.CDLL('libXtst.so.6')
xt.XTestFakeMotionEvent.argtypes=[C.c_void_p,C.c_int,C.c_int,C.c_int,C.c_ulong]
xt.XTestFakeButtonEvent.argtypes=[C.c_void_p,C.c_uint,C.c_int,C.c_ulong]
x.XSync.argtypes=[C.c_void_p,C.c_int]
x.XGetInputFocus.argtypes=[C.c_void_p,C.POINTER(C.c_ulong),C.POINTER(C.c_int)]

helper=x.XCreateSimpleWindow(d,x.XDefaultRootWindow(d),20,20,100,80,0,0,0);x.XMapWindow(d,helper);x.XFlush(d)
def retire_helper():
 x.XDestroyWindow(d,helper);x.XFlush(d);x.XCloseDisplay(d)
atexit.register(retire_helper)

# Start from a released pointer for this isolated native trial.
subprocess.run(['xdotool','mouseup','1'],check=True,timeout=8)
report={'display':os.environ['DISPLAY'],'wayland_display':os.environ.get('WAYLAND_DISPLAY'),'topology':'Owner-confirmed idle desktop X11/Xwayland; native adapter functional trial','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'visual_scale_factor':scale,'runs':[]}
for host,flag in [('GLOBAL','--open-global-preferences'),('PROJECT','--open-project-preferences')]:
 if host not in os.environ.get('PM045_HOSTS','GLOBAL PROJECT').split():continue
 case=out/host;case.mkdir();log=case/'native.log';log.write_text('');actions=[]
 env=os.environ.copy()
 for key in list(env):
  if key.startswith(('DATUM_DIAGNOSTIC_','DATUM_GPU_DIAGNOSTIC_')):env.pop(key)
 env.pop('WAYLAND_DISPLAY',None)
 env.update(EDA_CLI_BIN=str(root/'target/release/datum-eda'),DATUM_GPU_MEASUREMENTS='0',DATUM_GUI_VERBOSE_LOG='1',DATUM_GUI_LOG=str(log),WINIT_UNIX_BACKEND='x11',XDG_CONFIG_HOME=str(case/'config'),XDG_CACHE_HOME=str(case/'cache'))
 cmd=[str(binary),'--board','/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb','--window-size','1280x800','--initial-layout','single','--visual-scale-factor',str(scale),flag]
 result={'host':host,'command':cmd,'actions':actions}
 with (case/'stderr.log').open('w') as stderr:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stderr,stderr=stderr)
  def wait(fn):
   end=time.monotonic()+25
   while time.monotonic()<end:
    assert p.poll() is None,('process exited',p.returncode)
    value=fn()
    if value:return value
    time.sleep(.03)
   raise AssertionError('predicate timeout')
  pointer=['0','0']
  def xdo(*args):
   if args[0]=='mousemove':
    pointer[:]=[args[3],args[4]]
   elif args[0] in ('mousedown','mouseup','click'):
    args=('mousemove','--window',wid,*pointer,*args)
   if args[0]=='mousemove' and args[1]=='--window':
    geo=subprocess.check_output(['xdotool','getwindowgeometry','--shell',wid],env=env,text=True)
    position_dims=dict(line.split('=',1) for line in geo.splitlines() if '=' in line)
    args=('mousemove',str(int(position_dims['X'])+int(args[3])),str(int(position_dims['Y'])+int(args[4])),*args[5:])
   action={'xdotool':args,'monotonic':time.monotonic(),'wall_time':time.time()}
   actions.append(action)
   if args[0]=='mousemove':
    assert xt.XTestFakeMotionEvent(d,-1,int(args[1]),int(args[2]),0)
    if len(args)>3:
     assert len(args)==5
     if args[3] in ('click','mousedown'):assert xt.XTestFakeButtonEvent(d,int(args[4]),1,0)
     if args[3] in ('click','mouseup'):assert xt.XTestFakeButtonEvent(d,int(args[4]),0,0)
    x.XSync(d,0)
    focus=C.c_ulong();revert=C.c_int();x.XGetInputFocus(d,C.byref(focus),C.byref(revert))
    action['server_roundtrip_focus']=str(focus.value)
    action['input_transport']='persistent XTest connection'
   else:
    reply=subprocess.run(['xdotool',*args,'getwindowfocus'],env=env,check=True,timeout=8,stdout=subprocess.PIPE,text=True)
    action['server_roundtrip_focus']=reply.stdout.strip()
   action['pointer_after']=subprocess.check_output(['xdotool','getmouselocation','--shell'],env=env,text=True)
  try:
   ids=wait(lambda: (v if len(v)==2 else None) if (v:=re.findall(r'surface identity window=WindowId\((\d+)\)',log.read_text())) else None)
   wid=ids[-1];key='WindowId('+wid+')'
   def count():
    data=log.read_text();lines=data.splitlines() if data.endswith('\n') else data.splitlines()[:-1]
    return sum(json.loads(s.split('native_surface_lifecycle ',1)[1]).get('reason')=='present' and json.loads(s.split('native_surface_lifecycle ',1)[1]).get('window')==key for s in lines if 'native_surface_lifecycle ' in s)
   def event_count(event):return log.read_text().count('window event '+key+' '+event)
   wait(lambda:count()>0);time.sleep(.4)
   xdo('windowactivate','--sync',wid)
   xdo('windowsize',wid,str(round(960*scale)),str(round(720*scale)))
   setup_geometry=subprocess.check_output(['xdotool','getwindowgeometry','--shell',wid],env=env,text=True)
   setup_dims=dict(line.split('=',1) for line in setup_geometry.splitlines() if '=' in line)
   expected_extent=[int(setup_dims['WIDTH']),int(setup_dims['HEIGHT'])]
   def configured_present():
    rows=[json.loads(s.split('native_surface_lifecycle ',1)[1]) for s in log.read_text().splitlines() if 'native_surface_lifecycle ' in s and s.endswith('}')]
    presents=[r for r in rows if r.get('reason')=='present' and r.get('window')==key]
    return presents and presents[-1]['configured_extent']==expected_extent
   wait(configured_present)
   result['setup_presented_extent']=expected_extent
   if host=='GLOBAL':
    before=count();xdo('mousemove','--window',wid,str(round(50*scale)),str(round(107*scale)),'click','1');wait(lambda:count()>before)
   before=count();xdo('mousemove','--window',wid,str(round(900*scale)),str(round(130*scale)),'click','1');wait(lambda:count()>before)
   result['expanded_choice_trigger']='Click current Units control before scrolling; verify captured expansion separately'
   time.sleep(.4)
   geometry=subprocess.check_output(['xdotool','getwindowgeometry','--shell',wid],env=env,text=True)
   dims=dict(line.split('=',1) for line in geometry.splitlines() if '=' in line);width=int(dims['WIDTH']);height=int(dims['HEIGHT'])
   result['geometry']=dims
   xdo('mousemove','--window',wid,str(round(width-6*scale)),str(round(130*scale)));time.sleep(.2)
   subprocess.run(['import','-window',wid,str(case/'before.png')],env=env,check=True,timeout=8)
   before=count();events=event_count('mouse input Left Pressed');xdo('mousedown','1');wait(lambda:event_count('mouse input Left Pressed')>events);time.sleep(.25)
   assert count()==before,('thumb press redrew',before,count())
   result['thumb_press_frames']=0
   moves=event_count('cursor moved')
   xdo('mousemove','--window',wid,str(round(width-6*scale)),str(round(height-12*scale)))
   wait(lambda:event_count('cursor moved')>moves)
   result['drag_delivery_confirmed']=True
   deadline=time.monotonic()+3
   while count()==before and time.monotonic()<deadline:time.sleep(.03)
   assert count()>before,'painted scrollbar did not change dialog after delivered drag'
   time.sleep(.3)
   result['drag_frames']=count()-before
   before=count();lost=event_count('focused false');gained=event_count('focused true')
   actions.append({'XSetInputFocus':'owned helper','wall_time':time.time()})
   x.XSetInputFocus(d,helper,2,0);x.XFlush(d)
   wait(lambda:event_count('focused false')>lost)
   xdo('windowfocus','--sync',wid)
   wait(lambda:event_count('focused true')>gained)
   moves=event_count('cursor moved');xdo('mousemove','--window',wid,str(round(300*scale)),str(round(72*scale)))
   wait(lambda:event_count('cursor moved')>moves)
   time.sleep(.25);assert count()==before,('cancelled grab moved',before,count())
   releases=event_count('mouse input Left Released');xdo('mouseup','1')
   moves=event_count('cursor moved');xdo('mousemove','--window',wid,str(round(302*scale)),str(round(72*scale)))
   wait(lambda:event_count('cursor moved')>moves)
   time.sleep(.3)
   assert count()==before,('cancelled release activated search',before,count())
   assert event_count('mouse input Left Released')==releases,'cancelled release escaped entry-point suppression'
   result['focus_loss_and_gain_delivered']=True
   result['cancelled_motion_and_release_frames']=count()-before
   result['cancelled_release_suppressed_before_event_logging']=True
   xdo('click','1');wait(lambda:event_count('mouse input Left Released')>releases);wait(lambda:count()>before)
   time.sleep(.3);result['fresh_search_click_frames']=count()-before
   assert scale==1 and width==960 and height==720,'pixel oracle is restricted to this profile'
   samples=[];result['semantic_capture_samples']=samples
   deadline=time.monotonic()+12
   while time.monotonic()<deadline:
    sample=len(samples);time.sleep(.5)
    path=case/f'focused-search-{sample}.png'
    subprocess.run(['import','-window',wid,str(path)],env=env,check=True,timeout=8)
    with Image.open(path) as original:
     im=original.convert('RGB')
     points=[(229,70),(300,54),(600,54),(940,70),(954,718),(954,102)]
     pixels=[im.getpixel(point) for point in points]
    matches=(all(pixel==(91,139,208) for pixel in pixels[:4]) and pixels[4]==(178,184,195) and pixels[5]==(24,27,33))
    samples.append({'image':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pixels':pixels,'focused_search_and_bottom_thumb':matches,'wall_time':time.time()})
    if matches:break
   result['semantic_capture_pass']=samples[-1]['focused_search_and_bottom_thumb']
   with (case/'monitor-capture.log').open('w') as capture_log:
    try:
     capture=subprocess.run(['spectacle','--background','--nonotify','--current','--output',str(case/'monitor.png')],stdout=capture_log,stderr=capture_log,timeout=35)
     result['monitor_capture_exit']=capture.returncode
    except subprocess.TimeoutExpired:
     result['monitor_capture_error']='35-second timeout'
   result['monitor_image_exists']=(case/'monitor.png').exists()
   assert result['semantic_capture_pass'],'final focused-search/bottom-thumb pixels not captured'
   result['passed']=True;print(host,'PASS',flush=True)
  except Exception as e:
   result.update(passed=False,error=repr(e));print(host,repr(e),flush=True)
  finally:
   xt.XTestFakeButtonEvent(d,1,0,0);x.XSync(d,0)
   if p.poll() is None:p.terminate();p.wait(timeout=10)
   result['cleanup']='Harness SIGTERM; no teardown qualification'
   report['runs'].append(result);(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(r['passed'] for r in report['runs'])
