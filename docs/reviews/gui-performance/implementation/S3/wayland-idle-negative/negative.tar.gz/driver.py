import os,subprocess,time,re,json,hashlib,sys,shutil
from pathlib import Path
root=Path('/home/bfadmin/Documents/datum-eda');binary=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir()
report={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'runs':[],'interval_seconds':2,'scale':1,'native_backend':'Wayland','setting':'GUI-written reduced_motion=true copied into each owned configuration'}
for host,flag in [('GLOBAL','--open-global-preferences'),('PROJECT','--open-project-preferences')]:
 case=out/host;case.mkdir();shutil.copytree('/tmp/pm045-reduced-motion-native-setup/GLOBAL/config',case/'config');log=case/'native.log';log.write_text('');env=os.environ.copy();assert env.get('WAYLAND_DISPLAY')
 for k in list(env):
  if k.startswith(('DATUM_DIAGNOSTIC_','DATUM_GPU_DIAGNOSTIC_')):env.pop(k)
 env.update(EDA_CLI_BIN=str(root/'target/release/datum-eda'),WINIT_UNIX_BACKEND='wayland',DATUM_GUI_LOG=str(log),DATUM_GUI_VERBOSE_LOG='1',DATUM_GPU_MEASUREMENTS='0',XDG_CONFIG_HOME=str(case/'config'),XDG_CACHE_HOME=str(case/'cache'))
 cmd=[str(binary),'--board','/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb','--initial-layout','single','--window-size','1280x800','--visual-scale-factor','1',flag];r={'host':host,'command':cmd}
 with (case/'stderr.log').open('w') as err:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=err,stderr=err)
  try:
   def rows():return [json.loads(line.split('native_surface_lifecycle ',1)[1]) for line in log.read_text().splitlines() if 'native_surface_lifecycle ' in line and line.endswith('}')]
   deadline=time.monotonic()+30
   while True:
    assert p.poll() is None
    ids=re.findall(r'surface identity window=WindowId\((\d+)\)',log.read_text())
    if len(ids)==2 and any(x['reason']=='present' and x['window']=='WindowId('+ids[-1]+')' for x in rows()):break
    assert time.monotonic()<deadline,'startup timeout'
    time.sleep(.05)
   r['surface_identities']=[line for line in log.read_text().splitlines() if 'surface identity window=' in line]
   assert len(r['surface_identities'])==2 and all('window_backend=wayland' in line for line in r['surface_identities']),r['surface_identities']
   time.sleep(1)
   def counts():
    data=rows();return {name:sum(x['window']=='WindowId('+wid+')' and x['reason']=='present' for x in data) for name,wid in zip(['main','dialog'],ids)}
   r['before']=counts();r['started']=time.time();time.sleep(2);r['after']=counts();r['ended']=time.time();r['idle_frames']={k:r['after'][k]-r['before'][k] for k in r['before']};r['passed']=all(v==0 for v in r['idle_frames'].values());print(host,r['idle_frames'],flush=True)
  except Exception as e:r.update(passed=False,error=repr(e))
  finally:
   if p.poll() is None:p.terminate();p.wait(timeout=10)
   r['cleanup']='SIGTERM, no teardown qualification';report['runs'].append(r);(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(r['passed'] for r in report['runs'])
