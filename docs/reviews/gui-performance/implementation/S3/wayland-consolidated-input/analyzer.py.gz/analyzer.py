import json, re
from pathlib import Path

results = {}
for host, suffix in [('GLOBAL', 'global-replay'), ('PROJECT', 'project')]:
    root = Path('/tmp/pm045-s3-wayland-batch-' + suffix)
    report = json.loads((root / 'result.json').read_text())
    main, dialog = report['observations'][0]['surface_ids']
    log = (root / 'native.log').read_text()
    presents, wheels, keys = [], [], []
    gpu = [json.loads(line.removeprefix('gpu_measurement ')) for line in log.splitlines() if line.startswith('gpu_measurement ')]
    for line in log.splitlines():
        match = re.search(r'tv_sec: (\d+), tv_nsec: (\d+)', line)
        if not match:
            continue
        timestamp = int(match[1]) + int(match[2]) * 1e-9
        if 'mouse wheel delta=' in line:
            wheels.append((timestamp, line.split('mouse wheel ', 1)[1]))
        if 'keyboard physical=' in line and 'state=Pressed' in line:
            keys.append((timestamp, line))
        if 'native_surface_lifecycle ' in line and line.endswith('}'):
            row = json.loads(line.split('native_surface_lifecycle ', 1)[1])
            if row['reason'] == 'present':
                presents.append((timestamp, row))
    stats = [tuple(map(int, pair)) for pair in re.findall(r'dialog renderer=\d+us passes=1 text_cache=(\d+)/(\d+)', (root / 'stderr.log').read_text())]
    dialog_presents = [row for _, row in presents if row['window'] == f'WindowId({dialog})']
    assert len(stats) == len(dialog_presents), (host, len(stats), len(dialog_presents))
    assert len(wheels) == 5
    intervals = []
    for index, (start, event) in enumerate(wheels):
        end = wheels[index+1][0] if index+1 < len(wheels) else start+2
        rows = [row for timestamp, row in presents if start <= timestamp < end]
        main_count = sum(row['window'] == f'WindowId({main})' for row in rows)
        dialog_rows = [row for row in rows if row['window'] == f'WindowId({dialog})']
        assert main_count == 0
        assert len(dialog_rows) == [1, 1, 0, 1, 1][index], (host, index, rows)
        warm = [stats[row['presented']-1] for row in dialog_rows]
        assert all(hits > 0 and misses == 0 for hits, misses in warm), (host, index, warm)
        intervals.append({'start': start, 'end': end, 'received': event, 'main_frames': main_count, 'dialog_frames': len(dialog_rows), 'text_cache_hits_misses': warm})
    snapshots = [row for row in report['observations'] if wheels[-1][0] < row['time'] < next(t for t, _ in keys if t > wheels[-1][0])]
    assert len(snapshots) == 2
    idle_seconds = snapshots[-1]['time'] - snapshots[0]['time']
    assert idle_seconds >= 2 and snapshots[-1]['presents'] == snapshots[0]['presents']
    measured = [row for row in gpu if row['host'] == 2]
    assert len(measured) == len(dialog_presents)
    assert all([name for name, _ in row['passes_ns']] == ['dialog'] for row in measured)
    results[host] = {'binary_sha256': report['binary_sha256'], 'accepted_extents': report['observations'][0]['extents'], 'wheel_intervals': intervals, 'idle_seconds': idle_seconds, 'idle_frame_delta': {'main': 0, 'dialog': 0}, 'dialog_presentations': len(dialog_presents), 'measured_dialog_only_frames': len(measured), 'all_wheel_frames_warm': True}
    if host == 'GLOBAL':
        manifests = [json.loads(p.read_text()) for p in sorted((root/'config/datum/preferences/generations').glob('*/manifest.json'))]
        assert len(manifests) == 2
        values = [m['state']['user']['datum.accessibility.reduced_motion']['value'] for m in manifests]
        assert values == [True, False]
        receipt = manifests[-1]['state']['receipts'][-1]
        assert receipt['affected_keys'] == ['datum.accessibility.reduced_motion']
        results[host]['fresh_target'] = {'search': 'reduced motion', 'action': 'Tab Tab Enter', 'generation_values': values, 'receipt_operation': receipt['operation'], 'receipt_reason': receipt['reason'], 'scope': 'isolated test configuration'}
    else:
        post_scroll_keys = [(t,line) for t,line in keys if t > wheels[-1][0]]
        enter = next(t for t,line in post_scroll_keys if 'logical=Named(Enter)' in line)
        escapes = [t for t,line in post_scroll_keys if t > enter and 'logical=Named(Escape)' in line]
        assert len(escapes) == 2
        assert any(escapes[0] < t < escapes[1] and row['window'] == f'WindowId({dialog})' for t,row in presents)
        close_line = next(line for line in log.splitlines() if '"reason":"closed"' in line and f'WindowId({dialog})' in line)
        assert f'tv_sec: {int(escapes[1])}' in close_line
        assert f'window event WindowId({dialog}) destroyed' in log
        assert f'window event WindowId({main}) focused true' in log[log.index(close_line):]
        results[host]['fresh_target'] = {'search': 'precision', 'action': 'Tab Enter then Escape then Escape', 'first_escape': 'dialog presents and remains open', 'second_escape': 'dialog closes/destroys and Main receives focus', 'limit': 'semantic dismissal oracle, not rendered pixels or proof of exact search text'}
Path('/tmp/pm045-wayland-batch-analysis.json').write_text(json.dumps(results, indent=2)+'\n')
print(json.dumps({host: {k:v for k,v in result.items() if k not in ['wheel_intervals','accepted_extents','binary_sha256']} for host,result in results.items()}, indent=2))
