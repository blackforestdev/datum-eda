import os,subprocess,time,json,re,hashlib,ctypes as C
from pathlib import Path
root=Path('/home/bfadmin/Documents/datum-eda');binary=root/'target/pm045-main-hits-baseline';out=Path('/tmp/pm045-native-main-hit-map-baseline');out.mkdir(exist_ok=True)
class Data(C.Union):_fields_=[('l',C.c_long*5)]
class Client(C.Structure):_fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('message_type',C.c_ulong),('format',C.c_int),('data',Data)]
class Event(C.Union):_fields_=[('client',Client),('pad',C.c_long*24)]
x=C.CDLL('libX11.so.6');x.XOpenDisplay.restype=C.c_void_p;x.XOpenDisplay.argtypes=[C.c_char_p];x.XDefaultRootWindow.restype=C.c_ulong;x.XDefaultRootWindow.argtypes=[C.c_void_p];x.XInternAtom.restype=C.c_ulong;x.XInternAtom.argtypes=[C.c_void_p,C.c_char_p,C.c_int];x.XSendEvent.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_long,C.POINTER(Event)];x.XFlush.argtypes=[C.c_void_p];x.XCloseDisplay.argtypes=[C.c_void_p]
def maximize(wid,on):
 d=x.XOpenDisplay(None);assert d;e=Event();e.client.type=33;e.client.display=d;e.client.window=int(wid);e.client.message_type=x.XInternAtom(d,b'_NET_WM_STATE',0);e.client.format=32;e.client.data.l[:]=[int(on),x.XInternAtom(d,b'_NET_WM_STATE_MAXIMIZED_VERT',0),x.XInternAtom(d,b'_NET_WM_STATE_MAXIMIZED_HORZ',0),1,0];assert x.XSendEvent(d,x.XDefaultRootWindow(d),0,(1<<20)|(1<<19),C.byref(e));x.XFlush(d);x.XCloseDisplay(d)
def records(log):return [json.loads(s.split('native_surface_lifecycle ',1)[1]) for s in log.read_text().splitlines() if 'native_surface_lifecycle ' in s]
def until(fn,p):
 deadline=time.monotonic()+12
 while time.monotonic()<deadline and p.poll() is None:
  val=fn()
  if val:return val
  time.sleep(.05)
 raise AssertionError('native predicate timeout or process exit '+str(p.poll()))
def close_window(wid):
 d=x.XOpenDisplay(None);assert d;e=Event();e.client.type=33;e.client.display=d;e.client.window=int(wid);e.client.message_type=x.XInternAtom(d,b'WM_PROTOCOLS',0);e.client.format=32;e.client.data.l[:]=[x.XInternAtom(d,b'WM_DELETE_WINDOW',0),0,0,0,0];assert x.XSendEvent(d,int(wid),0,0,C.byref(e));x.XFlush(d);x.XCloseDisplay(d)
report={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
case=out/'MAIN';case.mkdir(exist_ok=True);log=case/'native.log';log.write_text('');stderr=case/'stderr.log'
env=os.environ.copy()
for k in list(env):
 if k.startswith('DATUM_DIAGNOSTIC_') or k.startswith('DATUM_GPU_DIAGNOSTIC_'):env.pop(k)
env.pop('WAYLAND_DISPLAY',None)
env.update(EDA_CLI_BIN=str(root/'target/release/datum-eda'),CARGO_NET_OFFLINE='true',DATUM_ACTION_EVIDENCE='1',DATUM_GPU_MEASUREMENTS='0',DATUM_GUI_VERBOSE_LOG='1',DATUM_GUI_LOG=str(log),WINIT_UNIX_BACKEND='x11',XDG_CONFIG_HOME=str(case/'config'),XDG_CACHE_HOME=str(case/'cache'))
with stderr.open('w') as stream:
 p=subprocess.Popen([str(binary),'--board','/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb','--window-size','1280x800'],cwd=root,env=env,stdout=stream,stderr=stream)
 try:
  wid=until(lambda:re.findall(r'surface identity window=WindowId\((\d+)\)',log.read_text()),p)[0]
  until(lambda:any(r['reason']=='present' for r in records(log)),p)
  subprocess.run(['xdotool','windowactivate',wid],check=True)
  time.sleep(1)
  subprocess.run(['xdotool','mousemove','--window',wid,'110','17','click','1'],check=True)
  def states():return [json.loads(line.split('DATUM_ACTION_EVIDENCE ',1)[1]) for line in stderr.read_text().splitlines() if line.startswith('DATUM_ACTION_EVIDENCE ')]
  time.sleep(1.5)
  subprocess.run(['import','-window',wid,str(case/'menu-open.png')],check=True)
  # Queue two pointer transitions against the same presented menu.
  import signal
  os.kill(p.pid,signal.SIGSTOP)
  try:subprocess.run(['xdotool','mousemove','--window',wid,'160','70','mousemove','--window',wid,'160','98'],check=True)
  finally:os.kill(p.pid,signal.SIGCONT)
  time.sleep(1.5)
  subprocess.run(['import','-window',wid,str(case/'menu-hover.png')],check=True)
  # Activate the top menu again to close it, then pan the board.
  subprocess.run(['xdotool','mousemove','--window',wid,'110','17','click','1'],check=True)
  time.sleep(1)
  subprocess.run(['xdotool','mousemove','--window',wid,'410','360','keydown','space','mousedown','1','mousemove','--window',wid,'455','385','mouseup','1','keyup','space'],check=True)
  time.sleep(1.5)
  subprocess.run(['import','-window',wid,str(case/'pan.png')],check=True)
  report['states']=states();report['scope']='Main native menu open, queued hover, dismissal and board pan; screenshots and state trace require inspection'
  close_window(wid);p.wait(timeout=20);assert p.returncode==0
  report['exit']=p.returncode
 finally:
  subprocess.run(['xdotool','keyup','space'],check=False)
  if p.poll() is None:p.terminate();p.wait(timeout=5)
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
