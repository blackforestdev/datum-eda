import os,subprocess,time,json,re,hashlib,ctypes as C
from pathlib import Path
root=Path('/home/bfadmin/Documents/datum-eda');binary=Path(__import__('sys').argv[1]);out=Path('/tmp/pm045-terminal-round')/__import__('sys').argv[2];out.mkdir(parents=True,exist_ok=True)
class Data(C.Union):_fields_=[('l',C.c_long*5)]
class Client(C.Structure):_fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('message_type',C.c_ulong),('format',C.c_int),('data',Data)]
class Event(C.Union):_fields_=[('client',Client),('pad',C.c_long*24)]
x=C.CDLL('libX11.so.6');x.XOpenDisplay.restype=C.c_void_p;x.XOpenDisplay.argtypes=[C.c_char_p];x.XDefaultRootWindow.restype=C.c_ulong;x.XDefaultRootWindow.argtypes=[C.c_void_p];x.XInternAtom.restype=C.c_ulong;x.XInternAtom.argtypes=[C.c_void_p,C.c_char_p,C.c_int];x.XSendEvent.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_long,C.POINTER(Event)];x.XFlush.argtypes=[C.c_void_p];x.XCloseDisplay.argtypes=[C.c_void_p]
def maximize(wid,on):
 d=x.XOpenDisplay(None);assert d;e=Event();e.client.type=33;e.client.display=d;e.client.window=int(wid);e.client.message_type=x.XInternAtom(d,b'_NET_WM_STATE',0);e.client.format=32;e.client.data.l[:]=[int(on),x.XInternAtom(d,b'_NET_WM_STATE_MAXIMIZED_VERT',0),x.XInternAtom(d,b'_NET_WM_STATE_MAXIMIZED_HORZ',0),1,0];assert x.XSendEvent(d,x.XDefaultRootWindow(d),0,(1<<20)|(1<<19),C.byref(e));x.XFlush(d);x.XCloseDisplay(d)
def complete_lines(path):
 data=path.read_text();return data.splitlines() if data.endswith('\n') else data.splitlines()[:-1]
def records(log):return [json.loads(s.split('native_surface_lifecycle ',1)[1]) for s in complete_lines(log) if 'native_surface_lifecycle ' in s]
def until(fn,p):
 deadline=time.monotonic()+12
 while time.monotonic()<deadline and p.poll() is None:
  val=fn()
  if val:return val
  time.sleep(.05)
 raise AssertionError('native predicate timeout or process exit '+str(p.poll()))
def close_window(wid):
 d=x.XOpenDisplay(None);assert d;e=Event();e.client.type=33;e.client.display=d;e.client.window=int(wid);e.client.message_type=x.XInternAtom(d,b'WM_PROTOCOLS',0);e.client.format=32;e.client.data.l[:]=[x.XInternAtom(d,b'WM_DELETE_WINDOW',0),0,0,0,0];assert x.XSendEvent(d,int(wid),0,0,C.byref(e));x.XFlush(d);x.XCloseDisplay(d)

def progress(log):
 return [tuple(map(int,m.groups())) for line in complete_lines(log) if (m:=re.search(r'native queue progress epoch=(\d+) submitted=(\d+) completed=(\d+)',line))]
case=out;log=case/'native.log';log.write_text('');env=os.environ.copy()
for k in list(env):
 if k.startswith('DATUM_DIAGNOSTIC_') or k.startswith('DATUM_GPU_DIAGNOSTIC_'):env.pop(k)
env.pop('WAYLAND_DISPLAY',None)
env.update(EDA_CLI_BIN=str(root/'target/release/datum-eda'),CARGO_NET_OFFLINE='true',DATUM_GPU_MEASUREMENTS='0',DATUM_GUI_VERBOSE_LOG='1',DATUM_GUI_LOG=str(log),WINIT_UNIX_BACKEND='x11',XDG_CONFIG_HOME=str(case/'config'),XDG_CACHE_HOME=str(case/'cache'))
cmd=[str(binary),'--board','/tmp/pm045-readiness-x11/GLOBAL/board.kicad_pcb','--open-global-preferences','--window-size','1280x800','--terminal-session-profile','custom','--terminal-program','/usr/bin/python3','--terminal-arg=-u','--terminal-arg=/tmp/pm045_terminal_flood.py','--terminal-arg='+str(case)]
result={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'command':cmd}
with (case/'stderr.log').open('w') as stream:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stream,stderr=stream)
 try:
  ids=until(lambda:(v if len(v)==2 else None) if (v:=re.findall(r'surface identity window=WindowId\((\d+)\)',log.read_text())) else None,p);wid=ids[-1];key='WindowId('+wid+')'
  until(lambda:next((r for r in records(log) if r['window']==key and r['reason']=='present'),None),p)
  time.sleep(.5);(case/'go').touch()
  until(lambda:(case/'started.json').exists(),p);time.sleep(.15)
  request=time.monotonic();subprocess.run(['xdotool','windowsize',wid,'1200','800'],check=True)
  shown=until(lambda:next((r for r in reversed(records(log)) if r['window']==key and r['reason']=='present' and r['configured_extent']==[1200,800]),None),p)
  observed=time.monotonic();during=not (case/'finished.json').exists()
  result.update({'resize_observed_seconds':observed-request,'resized_while_producer_running':during,'final_present':shown})
  until(lambda:(case/'finished.json').exists(),p);result['producer']=json.loads((case/'finished.json').read_text())
  time.sleep(.5);close_window(wid)
  until(lambda:subprocess.check_output(['xdotool','getwindowfocus'],text=True).strip()==ids[0],p);close_window(ids[0])
  p.wait(timeout=20);result.update({'exit':p.returncode,'completed':p.returncode==0});print(json.dumps(result),flush=True)
 except Exception as error:result.update({'completed':False,'error':str(error)});print(type(error).__name__,str(error),flush=True)
 finally:
  (case/'result.json').write_text(json.dumps(result,indent=2)+'\n')
  if p.poll() is None:p.terminate();p.wait(timeout=5)
