import os,time,json,sys
from pathlib import Path
case=Path(sys.argv[1]);deadline=time.monotonic()+25
while not (case/'go').exists():
 if time.monotonic()>deadline:raise SystemExit(2)
 time.sleep(.01)
start=time.monotonic();(case/'started.json').write_text(json.dumps({'monotonic':start}))
payload=(b'PM045 output flood '+b'x'*60+b'\r\n')*50
sent=0
while time.monotonic()-start<6 and sent<32*1024*1024:
 sent+=os.write(1,payload)
(case/'finished.json').write_text(json.dumps({'monotonic':time.monotonic(),'bytes':sent,'payload_bytes':len(payload)}))
