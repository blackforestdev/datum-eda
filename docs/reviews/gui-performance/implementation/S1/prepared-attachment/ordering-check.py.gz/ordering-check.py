import json
from pathlib import Path
results=[]
for host in ['GLOBAL','PROJECT','NEW','MAIN']:
 root=Path('/tmp/pm045-prepared-attachment-native'+('-main' if host=='MAIN' else ''))
 p=root/host/'native.log'
 seen={};submitted=set();empty=False
 for line in p.read_text().splitlines():
  if 'native attachment ledger ' not in line:continue
  event=json.loads(line.split('native attachment ledger ',1)[1]);ledger=event['attachments'];epoch=event['queue_epoch']
  for a in ledger['allocations']:
   key=(epoch,a['host'],a['owner'],a['allocation'])
   if key not in seen:
    assert a['last_submission']==0,(host,'first observed after submission',a)
    seen[key]=a['payload_bytes']
   if a['last_submission']>0:submitted.add(key)
  empty=not ledger['allocations']
 assert seen and set(seen)==submitted,(host,seen,submitted)
 assert empty,(host,'ledger not empty at teardown')
 report=json.loads((root/'result.json').read_text());run=next(r for r in report['runs'] if r['host']==host)
 assert run['passed'] and run['exit']==0
 results.append({'host':host,'allocations_first_observed_before_submission':len(seen),'same_allocations_later_submitted':len(submitted),'final_ledger_empty':empty,'native_exit':run['exit'],'binary_sha256':report['binary_sha256']})
Path('/tmp/pm045-prepared-attachment-order.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
