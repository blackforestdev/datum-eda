import os,subprocess,time,json,re,hashlib,ctypes as C
from pathlib import Path
root=Path('/home/bfadmin/Documents/datum-eda');binary=root/'target/release/datum-gui';out=Path('/tmp/pm045-native-retry-text');out.mkdir(exist_ok=True)
class Data(C.Union):_fields_=[('l',C.c_long*5)]
class Client(C.Structure):_fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('message_type',C.c_ulong),('format',C.c_int),('data',Data)]
class Event(C.Union):_fields_=[('client',Client),('pad',C.c_long*24)]
x=C.CDLL('libX11.so.6');x.XOpenDisplay.restype=C.c_void_p;x.XOpenDisplay.argtypes=[C.c_char_p];x.XDefaultRootWindow.restype=C.c_ulong;x.XDefaultRootWindow.argtypes=[C.c_void_p];x.XInternAtom.restype=C.c_ulong;x.XInternAtom.argtypes=[C.c_void_p,C.c_char_p,C.c_int];x.XSendEvent.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_long,C.POINTER(Event)];x.XFlush.argtypes=[C.c_void_p];x.XCloseDisplay.argtypes=[C.c_void_p]
def maximize(wid,on):
 d=x.XOpenDisplay(None);assert d;e=Event();e.client.type=33;e.client.display=d;e.client.window=int(wid);e.client.message_type=x.XInternAtom(d,b'_NET_WM_STATE',0);e.client.format=32;e.client.data.l[:]=[int(on),x.XInternAtom(d,b'_NET_WM_STATE_MAXIMIZED_VERT',0),x.XInternAtom(d,b'_NET_WM_STATE_MAXIMIZED_HORZ',0),1,0];assert x.XSendEvent(d,x.XDefaultRootWindow(d),0,(1<<20)|(1<<19),C.byref(e));x.XFlush(d);x.XCloseDisplay(d)
def records(log):return [json.loads(s.split('native_surface_lifecycle ',1)[1]) for s in log.read_text().splitlines() if 'native_surface_lifecycle ' in s]
def until(fn,p):
 deadline=time.monotonic()+12
 while time.monotonic()<deadline and p.poll() is None:
  val=fn()
  if val:return val
  time.sleep(.05)
 raise AssertionError('native predicate timeout or process exit '+str(p.poll()))
def close_window(wid):
 d=x.XOpenDisplay(None);assert d;e=Event();e.client.type=33;e.client.display=d;e.client.window=int(wid);e.client.message_type=x.XInternAtom(d,b'WM_PROTOCOLS',0);e.client.format=32;e.client.data.l[:]=[x.XInternAtom(d,b'WM_DELETE_WINDOW',0),0,0,0,0];assert x.XSendEvent(d,int(wid),0,0,C.byref(e));x.XFlush(d);x.XCloseDisplay(d)
report={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'runs':[]}
for host,flag in [('GLOBAL','--open-global-preferences')]:
 case=out/host;case.mkdir(exist_ok=True);fixture=Path('/tmp/pm045-readiness-x11')/host;log=case/'native.log';log.write_text('');env=os.environ.copy()
 for k in list(env):
  if k.startswith('DATUM_DIAGNOSTIC_') or k.startswith('DATUM_GPU_DIAGNOSTIC_'):env.pop(k)
 env.pop('WAYLAND_DISPLAY',None);env.update(EDA_CLI_BIN=str(root/'target/release/datum-eda'),CARGO_NET_OFFLINE='true',DATUM_GPU_MEASUREMENTS='0',DATUM_GUI_VERBOSE_LOG='1',DATUM_GUI_LOG=str(log),DATUM_DIAGNOSTIC_SURFACE_FAULT='other-once',WINIT_UNIX_BACKEND='x11',XDG_CONFIG_HOME=str(case/'config'),XDG_CACHE_HOME=str(case/'cache'),TMPDIR=str(case))
 cmd=[str(binary),'--board',str(fixture/'board.kicad_pcb'),'--window-size','1280x800']+([flag] if flag else [])
 with (case/'stderr.log').open('w') as stream:
  subprocess.run(['xdotool','keydown','ctrl'],check=True)
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stream,stderr=stream)
  try:
   count=2 if flag else 1
   ids=until(lambda:(v if len(v)==count else None) if (v:=re.findall(r'surface identity window=WindowId\((\d+)\)',log.read_text())) else None,p);wid=ids[-1];key='WindowId('+wid+')'
   until(lambda:'Map State: IsViewable' in subprocess.check_output(['xwininfo','-id',wid],text=True),p)
   subprocess.run(['xdotool','windowactivate',wid],check=True)
   def failures():return log.read_text().count('Rendering paused for native host '+key+':')
   def attempts():return [r for r in records(log) if r['window']==key and r['reason']=='acquire_timeout']
   until(lambda:failures()>=1,p)
   subprocess.run(['xdotool','keyup','ctrl'],check=True)
   subprocess.run(['xdotool','key','F5'],check=True)
   until(lambda:any(r['window']==key and r['reason']=='present' for r in records(log)),p)
   subprocess.run(['xdotool','mousemove','--window',wid,'400','70','click','1'],check=True)
   subprocess.run(['xdotool','type','--delay','15','retry text'],check=True)
   until(lambda:'physical=Code(KeyT)' in log.read_text() and log.read_text().rfind('"reason":"present"')>max((m.start() for m in re.finditer(r'physical=Code\(KeyT\).*state=Pressed',log.read_text())),default=len(log.read_text())),p)
   time.sleep(1.2)
   subprocess.run(['import','-window',wid,str(case/'retry-text.png')],check=True)
   # Deliver native WM_DELETE_WINDOW, never destroy the window directly.
   close_window(wid)
   if flag:
    until(lambda:'close requested' in log.read_text().lower() or 'destroyed' in log.read_text().lower(),p)
    assert p.poll() is None,'auxiliary close ended application'
    until(lambda:subprocess.check_output(['xdotool','getwindowfocus'],text=True).strip()==ids[0],p)
    close_window(ids[0])
   p.wait(timeout=10);assert p.returncode==0,'native close did not exit cleanly'
   report['runs'].append({'host':host,'passed':True,'command':cmd,'window':key,'typed_after_retry':'retry text','failure_reports':failures(),'application_exit':p.returncode,'scope':'one-shot backend Other fault; Ctrl held at launch then released while failed; native F5 successful frame and text input, WM_DELETE_WINDOW Close; final screenshot requires visual review'})
   (out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(host,'bounded timeout, F5, Close pass',flush=True)
  except Exception as e:
   report['runs'].append({'host':host,'passed':False,'error':str(e)});(out/'result.json').write_text(json.dumps(report,indent=2)+'\n');raise
  finally:
   subprocess.run(['xdotool','keyup','ctrl'],check=False)
   if p.poll() is None:
    p.terminate()
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:p.kill();p.wait()
assert hashlib.sha256(binary.read_bytes()).hexdigest()==report['binary_sha256']
