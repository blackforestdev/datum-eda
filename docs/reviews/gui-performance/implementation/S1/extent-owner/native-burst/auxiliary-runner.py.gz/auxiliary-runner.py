import os,subprocess,time,json,re,hashlib,ctypes as C
from pathlib import Path
root=Path('/home/bfadmin/Documents/datum-eda');binary=root/'target/release/datum-gui';out=Path('/tmp/pm045-native-extent-burst');out.mkdir(exist_ok=True)
class Data(C.Union):_fields_=[('l',C.c_long*5)]
class Client(C.Structure):_fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('message_type',C.c_ulong),('format',C.c_int),('data',Data)]
class Event(C.Union):_fields_=[('client',Client),('pad',C.c_long*24)]
x=C.CDLL('libX11.so.6');x.XOpenDisplay.restype=C.c_void_p;x.XOpenDisplay.argtypes=[C.c_char_p];x.XDefaultRootWindow.restype=C.c_ulong;x.XDefaultRootWindow.argtypes=[C.c_void_p];x.XInternAtom.restype=C.c_ulong;x.XInternAtom.argtypes=[C.c_void_p,C.c_char_p,C.c_int];x.XSendEvent.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_long,C.POINTER(Event)];x.XFlush.argtypes=[C.c_void_p];x.XCloseDisplay.argtypes=[C.c_void_p]
def maximize(wid,on):
 d=x.XOpenDisplay(None);assert d;e=Event();e.client.type=33;e.client.display=d;e.client.window=int(wid);e.client.message_type=x.XInternAtom(d,b'_NET_WM_STATE',0);e.client.format=32;e.client.data.l[:]=[int(on),x.XInternAtom(d,b'_NET_WM_STATE_MAXIMIZED_VERT',0),x.XInternAtom(d,b'_NET_WM_STATE_MAXIMIZED_HORZ',0),1,0];assert x.XSendEvent(d,x.XDefaultRootWindow(d),0,(1<<20)|(1<<19),C.byref(e));x.XFlush(d);x.XCloseDisplay(d)
def records(log):return [json.loads(s.split('native_surface_lifecycle ',1)[1]) for s in log.read_text().splitlines() if 'native_surface_lifecycle ' in s]
def until(fn,p):
 deadline=time.monotonic()+12
 while time.monotonic()<deadline and p.poll() is None:
  val=fn()
  if val:return val
  time.sleep(.05)
 raise AssertionError('native predicate timeout or process exit '+str(p.poll()))
def close_window(wid):
 d=x.XOpenDisplay(None);assert d;e=Event();e.client.type=33;e.client.display=d;e.client.window=int(wid);e.client.message_type=x.XInternAtom(d,b'WM_PROTOCOLS',0);e.client.format=32;e.client.data.l[:]=[x.XInternAtom(d,b'WM_DELETE_WINDOW',0),0,0,0,0];assert x.XSendEvent(d,int(wid),0,0,C.byref(e));x.XFlush(d);x.XCloseDisplay(d)
import signal
report={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'runs':[]}
for host,flag in [('GLOBAL','--open-global-preferences'),('PROJECT','--open-project-preferences'),('NEW','--open-new-project')]:
 case=out/host;case.mkdir(exist_ok=True);log=case/'native.log';log.write_text('');env=os.environ.copy()
 for k in list(env):
  if k.startswith('DATUM_DIAGNOSTIC_') or k.startswith('DATUM_GPU_DIAGNOSTIC_'):env.pop(k)
 env.pop('WAYLAND_DISPLAY',None)
 env.update(EDA_CLI_BIN=str(root/'target/release/datum-eda'),CARGO_NET_OFFLINE='true',DATUM_GPU_MEASUREMENTS='0',DATUM_GUI_VERBOSE_LOG='1',DATUM_GUI_LOG=str(log),WINIT_UNIX_BACKEND='x11',XDG_CONFIG_HOME=str(case/'config'),XDG_CACHE_HOME=str(case/'cache'))
 cmd=[str(binary),'--board',str(Path('/tmp/pm045-readiness-x11')/host/'board.kicad_pcb'),'--window-size','1280x800',flag]
 with (case/'stderr.log').open('w') as stream:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stream,stderr=stream)
  result={'host':host,'command':cmd}
  try:
   ids=until(lambda:(v if len(v)==2 else None) if (v:=re.findall(r'surface identity window=WindowId\((\d+)\)',log.read_text())) else None,p);wid=ids[-1];key='WindowId('+wid+')'
   until(lambda:any(r['window']==key and r['reason']=='present' for r in records(log)),p)
   subprocess.run(['xdotool','windowactivate',wid],check=True);time.sleep(1)
   before=records(log);initial=next(r for r in reversed(before) if r['window']==key and r['reason']=='present')
   main_before=sum(r['window']=='WindowId('+ids[0]+')' and r['reason']=='submit' for r in before)
   start=len(log.read_text())
   os.kill(p.pid,signal.SIGSTOP)
   try:
    for width,height in [(1200,900),(1300,950),(1000,800)]:
     subprocess.run(['xdotool','windowsize',wid,str(width),str(height)],check=True)
    info=subprocess.check_output(['xwininfo','-id',wid],text=True)
    assert 'Width: 1000' in info and 'Height: 800' in info,info
   finally:os.kill(p.pid,signal.SIGCONT)
   until(lambda:any(r['window']==key and r['reason']=='present' and r['configured_extent']==[1000,800] for r in records(log)[len(before):]),p)
   after=records(log);last=next(r for r in reversed(after) if r['window']==key and r['reason']=='present')
   delta=last['configure_attempts']-initial['configure_attempts']
   assert delta==1,('queued burst configured more than final extent',delta)
   main_after=sum(r['window']=='WindowId('+ids[0]+')' and r['reason']=='submit' for r in after)
   assert main_after==main_before,'auxiliary resize induced Main submission'
   result.update({'initial_extent':initial['configured_extent'],'final_extent':last['configured_extent'],'configure_delta':delta,'main_submit_delta':main_after-main_before,'native_burst_trace':log.read_text()[start:]})
   close_window(wid)
   until(lambda:subprocess.check_output(['xdotool','getwindowfocus'],text=True).strip()==ids[0],p)
   close_window(ids[0]);p.wait(timeout=20);assert p.returncode==0
   result.update({'passed':True,'exit':p.returncode});print(host,'native burst pass',flush=True)
  except Exception as error:
   result.update({'passed':False,'error':str(error)});raise
  finally:
   report['runs'].append(result);(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
   if p.poll() is None:
    os.kill(p.pid,signal.SIGCONT);p.terminate();p.wait(timeout=5)
