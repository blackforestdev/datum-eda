import os, subprocess, time, json, hashlib
from pathlib import Path
root=Path('/home/bfadmin/Documents/datum-eda')
binary=root/'target/release/datum-gui'
fixture=Path('/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb')
out=Path('/tmp/pm045-idle-main');out.mkdir(exist_ok=True)
hz=os.sysconf('SC_CLK_TCK')
report={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'clock_ticks_per_second':hz,'scope':'current Main X11 application-family CPU and application submission idle control; no baseline-relative or GPU/display qualification','runs':[]}
def family(pid):
    all_rows={}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            row=(p/'stat').read_text().split(') ',1)[1].split()
            all_rows[int(p.name)]={'ppid':int(row[1]),'cpu_ticks':int(row[11])+int(row[12]),'start_ticks':int(row[19])}
        except (FileNotFoundError,ProcessLookupError,PermissionError):pass
    keep={pid}
    while True:
        more={p for p,r in all_rows.items() if r['ppid'] in keep}
        if more<=keep:break
        keep|=more
    return {p:all_rows[p] for p in keep if p in all_rows}
def counts(log):
    rows=[json.loads(l.split('native_surface_lifecycle ',1)[1]) for l in log.read_text().splitlines() if 'native_surface_lifecycle ' in l]
    return {reason:sum(r['reason']==reason for r in rows) for reason in ['submit','present']}
for trial in range(1,4):
    case=out/str(trial);case.mkdir(exist_ok=True);log=case/'native.log';log.write_text('')
    env=os.environ.copy()
    for k in list(env):
        if k.startswith('DATUM_DIAGNOSTIC_') or k.startswith('DATUM_GPU_DIAGNOSTIC_'):env.pop(k)
    env.pop('WAYLAND_DISPLAY',None)
    env.update(EDA_CLI_BIN=str(root/'target/release/datum-eda'),CARGO_NET_OFFLINE='true',DATUM_GPU_MEASUREMENTS='0',DATUM_GUI_VERBOSE_LOG='1',DATUM_GUI_LOG=str(log),WINIT_UNIX_BACKEND='x11',XDG_CONFIG_HOME=str(case/'config'),XDG_CACHE_HOME=str(case/'cache'),TMPDIR=str(case))
    cmd=[str(binary),'--board',str(fixture),'--window-size','1280x800']
    with (case/'stderr.log').open('w') as stream:
        p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stream,stderr=stream)
        try:
            deadline=time.monotonic()+15
            while counts(log)['present']==0:
                assert p.poll() is None and time.monotonic()<deadline,'native readiness failed'
                time.sleep(.1)
            time.sleep(5)
            before=family(p.pid);frames_before=counts(log);start=time.monotonic()
            print('trial',trial,'60-second idle interval started',flush=True)
            while time.monotonic()-start<60:
                assert p.poll() is None,'process exited during idle'
                time.sleep(min(1,60-(time.monotonic()-start)))
            end=time.monotonic();after=family(p.pid);frames_after=counts(log)
            stable=before.keys()==after.keys() and all(before[i]['start_ticks']==after[i]['start_ticks'] for i in before)
            cpu=100*sum(after[i]['cpu_ticks']-before[i]['cpu_ticks'] for i in before)/hz/(end-start) if stable else None
            row={'trial':trial,'command':cmd,'pid':p.pid,'start_monotonic':start,'end_monotonic':end,'before':before,'after':after,'stable_family':stable,'cpu_percent_one_core':cpu,'frames_before':frames_before,'frames_after':frames_after,'passed':stable and cpu<=1 and frames_before==frames_after}
            report['runs'].append(row);(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
            print('trial',trial,'CPU',cpu,'frames',frames_before,frames_after,'pass',row['passed'],flush=True)
            assert row['passed'],'idle CPU/submission gate failed or accounting incomplete'
        finally:
            p.terminate()
            try:p.wait(timeout=5)
            except subprocess.TimeoutExpired:p.kill();p.wait()
assert hashlib.sha256(binary.read_bytes()).hexdigest()==report['binary_sha256']
