import os,subprocess,time,json,re,hashlib,ctypes as C
from pathlib import Path
root=Path('/home/bfadmin/Documents/datum-eda');binary=root/'target/release/datum-gui';out=Path('/tmp/pm045-native-pane-rebind');out.mkdir(exist_ok=True)
class Data(C.Union):_fields_=[('l',C.c_long*5)]
class Client(C.Structure):_fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('message_type',C.c_ulong),('format',C.c_int),('data',Data)]
class Event(C.Union):_fields_=[('client',Client),('pad',C.c_long*24)]
x=C.CDLL('libX11.so.6');x.XOpenDisplay.restype=C.c_void_p;x.XOpenDisplay.argtypes=[C.c_char_p];x.XDefaultRootWindow.restype=C.c_ulong;x.XDefaultRootWindow.argtypes=[C.c_void_p];x.XInternAtom.restype=C.c_ulong;x.XInternAtom.argtypes=[C.c_void_p,C.c_char_p,C.c_int];x.XSendEvent.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_long,C.POINTER(Event)];x.XFlush.argtypes=[C.c_void_p];x.XCloseDisplay.argtypes=[C.c_void_p]
def maximize(wid,on):
 d=x.XOpenDisplay(None);assert d;e=Event();e.client.type=33;e.client.display=d;e.client.window=int(wid);e.client.message_type=x.XInternAtom(d,b'_NET_WM_STATE',0);e.client.format=32;e.client.data.l[:]=[int(on),x.XInternAtom(d,b'_NET_WM_STATE_MAXIMIZED_VERT',0),x.XInternAtom(d,b'_NET_WM_STATE_MAXIMIZED_HORZ',0),1,0];assert x.XSendEvent(d,x.XDefaultRootWindow(d),0,(1<<20)|(1<<19),C.byref(e));x.XFlush(d);x.XCloseDisplay(d)
def complete_lines(path):
 data=path.read_text();return data.splitlines() if data.endswith('\n') else data.splitlines()[:-1]
def records(log):return [json.loads(s.split('native_surface_lifecycle ',1)[1]) for s in complete_lines(log) if 'native_surface_lifecycle ' in s]
def until(fn,p):
 deadline=time.monotonic()+12
 while time.monotonic()<deadline and p.poll() is None:
  val=fn()
  if val:return val
  time.sleep(.05)
 raise AssertionError('native predicate timeout or process exit '+str(p.poll()))
def close_window(wid):
 d=x.XOpenDisplay(None);assert d;e=Event();e.client.type=33;e.client.display=d;e.client.window=int(wid);e.client.message_type=x.XInternAtom(d,b'WM_PROTOCOLS',0);e.client.format=32;e.client.data.l[:]=[x.XInternAtom(d,b'WM_DELETE_WINDOW',0),0,0,0,0];assert x.XSendEvent(d,int(wid),0,0,C.byref(e));x.XFlush(d);x.XCloseDisplay(d)

report={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'steps':[]}
case=out/'MAIN';case.mkdir(exist_ok=True);log=case/'native.log';log.write_text('');stderr=case/'stderr.log';env=os.environ.copy()
for k in list(env):
 if k.startswith('DATUM_DIAGNOSTIC_') or k.startswith('DATUM_GPU_DIAGNOSTIC_'):env.pop(k)
env.pop('WAYLAND_DISPLAY',None)
env.update(EDA_CLI_BIN=str(root/'target/release/datum-eda'),CARGO_NET_OFFLINE='true',DATUM_ACTION_EVIDENCE='1',DATUM_GPU_MEASUREMENTS='0',DATUM_GUI_VERBOSE_LOG='1',DATUM_GUI_LOG=str(log),WINIT_UNIX_BACKEND='x11',XDG_CONFIG_HOME=str(case/'config'),XDG_CACHE_HOME=str(case/'cache'))
cmd=[str(binary),'--board','/tmp/pm045-readiness-x11/MAIN/board.kicad_pcb','--window-size','1280x800','--initial-layout','single','--open-menu','View'];report['command']=cmd
model=json.loads((root/'docs/gui/menu_model.json').read_text());view=next(g for g in model['menubar'] if g['menu']=='View');indices={v['gui_local']:i for i,v in enumerate(view['items']) if 'gui_local' in v}
def states():return [json.loads(l.split('DATUM_ACTION_EVIDENCE ',1)[1])['value'] for l in complete_lines(stderr) if l.startswith('DATUM_ACTION_EVIDENCE ') and json.loads(l.split('DATUM_ACTION_EVIDENCE ',1)[1])['event']=='state']
def camera(state,pane):return next(c['camera'] for c in state['pane_cameras'] if c['pane']==pane)
with stderr.open('w') as stream:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stream,stderr=stream)
 try:
  wid=until(lambda:re.findall(r'surface identity window=WindowId\((\d+)\)',log.read_text()),p)[0]
  until(lambda:any(r['reason']=='present' for r in records(log)),p)
  subprocess.run(['xdotool','windowactivate',wid],check=True);time.sleep(.5)
  def settled():
   entries=[json.loads(line.split('native redraw ledger ',1)[1]) for line in complete_lines(log) if 'native redraw ledger ' in line]
   return entries and entries[-1]['damage']==entries[-1]['presented_damage'] and not entries[-1]['pending']
  until(settled,p)
  menu_x=None
  def action(name):
   global menu_x
   if not states() or states()[-1]['menu']!='View':
    for xcoord in ([menu_x] if menu_x else [170,190,210,230,250]):
     subprocess.run(['xdotool','mousemove','--window',wid,str(xcoord),'17','click','1'],check=True);time.sleep(.4)
     until(settled,p)
     if states() and states()[-1]['menu']=='View':menu_x=xcoord;break
     if states() and states()[-1]['menu'] is not None:subprocess.run(['xdotool','key','Escape'],check=True);time.sleep(.1)
    assert states()[-1]['menu']=='View','could not open View through native menubar'
   index=indices[name];current=states()[-1]['menu_focus_index'];count=(index-current)%len(view['items'])
   if count:subprocess.run(['xdotool','key','--delay','35']+['Down']*count,check=True)
   until(lambda:states()[-1]['menu_focus_index']==index,p)
   n=len(states());subprocess.run(['xdotool','key','Return'],check=True)
   state=until(lambda:states()[-1] if len(states())>n and states()[-1]['menu'] is None else None,p)
   until(settled,p)
   report['steps'].append({'action':name,'state':state});print(name,state['focused_pane'],state['board_camera'],flush=True);time.sleep(.2)
   return state
  original=action('view.zoom_in');a=original['focused_pane'];camera_a=camera(original,a)
  split=action('view.split_vertical');assert camera(split,a)==camera_a
  focus=action('view.focus_next');b=focus['focused_pane'];assert b!=a
  board=action('view.fill_board');assert camera(board,a)==camera_a
  action('view.zoom_in');zoomed=action('view.zoom_in');camera_b=camera(zoomed,b);assert camera_b!=camera_a
  back=action('view.focus_prev');assert camera(back,a)==camera_a and camera(back,b)==camera_b
  rebound=action('view.fill_schematic');assert camera(rebound,b)==camera_b
  restored=action('view.fill_board');assert camera(restored,b)==camera_b;assert camera(restored,a)==camera(board,b),('retargeted pane revived old camera',camera(restored,a),camera(board,b))
  closed=action('view.close_pane');assert closed['focused_pane']==b and closed['focus']=='Editor(PaneId('+str(b)+'))';assert camera(closed,b)==camera_b;assert len(closed['pane_cameras'])==1
  report.update({'passed':True,'camera_a':camera_a,'camera_b':camera_b,'retargeted_camera_after_return':camera(restored,a),'menu_x':menu_x,'retargeted_camera_matches_initial_fit':camera(restored,a)==camera(board,b),'scope':'Native menu split, duplicate Board, independent zoom, focus, content rebind and close; surviving Board camera equality and focus checked. Closed hidden cache entries not exposed by this trace.'})
  close_window(wid);p.wait(timeout=20);assert p.returncode==0;report['exit']=p.returncode
 except Exception as error:report.update({'passed':False,'error':str(error)});raise
 finally:
  (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
  if p.poll() is None:p.terminate();p.wait(timeout=5)
