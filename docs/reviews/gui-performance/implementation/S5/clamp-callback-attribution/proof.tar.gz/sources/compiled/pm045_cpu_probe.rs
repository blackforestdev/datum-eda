//! Temporary first-party diagnostic; never adopted into the production candidate.
use std::{cell::RefCell, sync::OnceLock};
const LIMIT: usize = 65_536;
type Row = [u64; 5];
thread_local! { static ROWS: RefCell<Vec<Row>> = const { RefCell::new(Vec::new()) }; }
fn path() -> Option<&'static std::ffi::OsString> {
    static PATH: OnceLock<Option<std::ffi::OsString>> = OnceLock::new();
    PATH.get_or_init(|| std::env::var_os("PM045_CALLBACK_CPU_PATH"))
        .as_ref()
}
fn now(clock: libc::clockid_t) -> u64 {
    let mut value = libc::timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    // Diagnostic reads of existing Linux monotonic/main-thread CPU clocks only.
    assert_eq!(unsafe { libc::clock_gettime(clock, &mut value) }, 0);
    value.tv_sec as u64 * 1_000_000_000 + value.tv_nsec as u64
}
pub(crate) struct Scope {
    tag: u64,
    mono: u64,
    cpu: u64,
}
impl Scope {
    pub(crate) fn start(tag: u64) -> Option<Self> {
        path()?;
        ROWS.with(|rows| {
            let mut rows = rows.borrow_mut();
            if rows.capacity() == 0 {
                rows.reserve_exact(LIMIT);
            }
        });
        Some(Self {
            tag,
            mono: now(libc::CLOCK_MONOTONIC),
            cpu: now(libc::CLOCK_THREAD_CPUTIME_ID),
        })
    }
}
impl Drop for Scope {
    fn drop(&mut self) {
        let cpu = now(libc::CLOCK_THREAD_CPUTIME_ID);
        let mono = now(libc::CLOCK_MONOTONIC);
        ROWS.with(|rows| {
            let mut rows = rows.borrow_mut();
            assert!(rows.len() < LIMIT, "CPU diagnostic capacity exceeded");
            rows.push([self.tag, self.mono, mono, self.cpu, cpu]);
        });
    }
}
pub(crate) fn finish() {
    let Some(path) = path() else { return };
    ROWS.with(|rows| {
        let file = std::fs::File::options()
            .write(true)
            .create_new(true)
            .open(path)
            .expect("create CPU diagnostic");
        serde_json::to_writer(file, &*rows.borrow()).expect("write CPU diagnostic");
    });
}
