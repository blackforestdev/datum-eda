
struct SceneUniform { resolution: vec4<f32>, viewport_origin: vec4<f32>, viewport_size: vec4<f32>, camera_center_scale: vec4<f32> };
@group(0) @binding(0) var<uniform> scene: SceneUniform;
struct In { @builtin(vertex_index) vertex: u32, @location(0) point_a: vec2<f32>, @location(1) point_b: vec2<f32>, @location(2) color_min_px: vec4<f32>, @location(3) nominal_nm: f32 };
struct Out {
 @builtin(position) position: vec4<f32>,
 @location(0) color: vec3<f32>,
 @location(1) local_px: vec2<f32>,
 @location(2) capsule_px: vec2<f32>,
};
@vertex fn vs_main(i: In) -> Out {
 let endpoint_b = i.vertex == 1u || i.vertex == 2u || i.vertex == 4u;
 let positive = i.vertex == 0u || i.vertex == 1u || i.vertex == 3u;
 let center = select(i.point_a, i.point_b, endpoint_b); let d = i.point_b - i.point_a;
 let tangent = d / max(length(d), 1.0); let normal = vec2<f32>(-tangent.y, tangent.x);
 let width = max(i.nominal_nm * scene.camera_center_scale.z, i.color_min_px.w);
 let radius = width * 0.5;
 let half_length = length(d) * scene.camera_center_scale.z * 0.5;
 let sc = scene.viewport_origin.xy + scene.viewport_size.xy * 0.5
     + (center - scene.camera_center_scale.xy) * scene.camera_center_scale.z
     + tangent * select(-1.0, 1.0, endpoint_b) * radius;
 let across = select(-1.0, 1.0, positive) * radius;
 let along = select(-1.0, 1.0, endpoint_b) * (half_length + radius);
 let p = sc + normal * across; var o: Out;
 o.position = vec4<f32>((p.x / scene.resolution.x) * 2.0 - 1.0, 1.0 - (p.y / scene.resolution.y) * 2.0, 0.0, 1.0);
 o.color = i.color_min_px.xyz;
 o.local_px = vec2<f32>(along, across);
 o.capsule_px = vec2<f32>(half_length, radius);
 return o;
}
fn srgb_to_linear(c: vec3<f32>) -> vec3<f32> { return select(pow((c + vec3<f32>(0.055)) / 1.055, vec3<f32>(2.4)), c / 12.92, c <= vec3<f32>(0.04045)); }
@fragment fn fs_main(i: Out, @builtin(sample_index) sample_index: u32) -> @location(0) vec4<f32> {
 // The six vertices form the capsule's bounding rectangle. Reject its four
 // square corners analytically so every retained segment has true round caps.
 // Adjacent segment capsules overlap at their shared endpoint, restoring the
 // round, gap-free joins used by imported two-point KiCad tracks. Requesting
 // sample_index makes this test run per sample, preserving antialiasing at the
 // analytic edge when the renderer's multisampled target is active.
 let cap_distance = max(abs(i.local_px.x) - i.capsule_px.x, 0.0);
 let distance_squared = cap_distance * cap_distance + i.local_px.y * i.local_px.y;
 if distance_squared > i.capsule_px.y * i.capsule_px.y { discard; }
 return vec4<f32>(srgb_to_linear(i.color), 1.0);
}
