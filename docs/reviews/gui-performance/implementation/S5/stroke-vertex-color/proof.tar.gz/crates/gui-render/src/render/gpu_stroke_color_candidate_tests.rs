//! Exact GPU comparison against the pre-optimization stroke shader.
use super::*;
use crate::WorldStrokeInstance;

fn pipeline(
    device: &wgpu::Device,
    layout: &wgpu::PipelineLayout,
    format: wgpu::TextureFormat,
    samples: u32,
    source: &str,
) -> wgpu::RenderPipeline {
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("datum-world-stroke-shader"),
        source: wgpu::ShaderSource::Wgsl(source.into()),
    });
    device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("datum-world-stroke-pipeline"),
        layout: Some(layout),
        vertex: wgpu::VertexState {
            module: &shader,
            entry_point: Some("vs_main"),
            buffers: &[WorldStrokeInstance::layout()],
            compilation_options: Default::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format,
                blend: Some(wgpu::BlendState::REPLACE),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState {
            count: samples,
            mask: !0,
            alpha_to_coverage_enabled: false,
        },
        multiview_mask: None,
        cache: None,
    })
}

#[test]
#[ignore = "requires local GPU; stroke color placement regression"]
fn stroke_vertex_color_matches_previous_shader() {
    let native_root = std::env::var_os("PM045_STROKE_NATIVE_PROJECT");
    let (width, height) = if native_root.is_some() {
        (1280, 800)
    } else {
        (960, 720)
    };
    let reference = include_str!("../../testdata/stroke-color-before.wgsl");
    let candidate = crate::gpu_strokes::WORLD_STROKE_SHADER;
    assert_ne!(candidate, reference);
    let mut renderer = hardware_renderer_with_features(
        width,
        height,
        wgpu::Features::TIMESTAMP_QUERY | wgpu::Features::TEXTURE_ADAPTER_SPECIFIC_FORMAT_FEATURES,
    );
    renderer.renderer = Renderer::new(&renderer.device, &renderer.queue, OUTPUT_FORMAT, 8).unwrap();
    let layout = renderer
        .device
        .create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("stroke-color-placement-proof"),
            bind_group_layouts: &[&renderer.renderer.scene_bind_group_layout],
            immediate_size: 0,
        });
    let old = pipeline(&renderer.device, &layout, OUTPUT_FORMAT, 8, reference);
    let new = renderer.renderer.world_stroke_pipeline.clone();
    let wrong = pipeline(
        &renderer.device,
        &layout,
        OUTPUT_FORMAT,
        8,
        &candidate.replace(
            "return vec4<f32>(i.color, 1.0);",
            "return vec4<f32>(0.0, 0.0, 0.0, 1.0);",
        ),
    );
    let native = native_root.is_some();
    let state = if let Some(root) = native_root {
        datum_gui_protocol::load_board_editor_workspace_state(
            &datum_gui_protocol::LiveReviewRequest {
                project_root: root.into(),
                board_file: None,
                artifact_path: None,
                net_uuid: None,
                from_anchor_pad_uuid: None,
                to_anchor_pad_uuid: None,
                profile: None,
                kicad_board_source: None,
            },
        )
        .unwrap()
    } else {
        crate::gpu_surface_pass::board_fixture_state()
    };
    let mut retained = RetainedScene::from_workspace(&state, 960, 720);
    assert!(!retained.world_strokes.is_empty());
    // Include dark, transfer-function threshold and saturated per-instance colors.
    let palette = [
        [0.0, 0.04045, 1.0],
        [0.04, 0.5, 0.75],
        [1.0, 0.0, 0.5],
        [0.1, 0.2, 0.3],
    ];
    let mut strokes = retained.world_strokes.to_vec();
    if !native {
        for (i, stroke) in strokes.iter_mut().enumerate() {
            stroke.color_min_px[..3].copy_from_slice(&palette[i % palette.len()]);
        }
    }
    eprintln!(
        "stroke candidate native={native} instances={}",
        strokes.len()
    );
    retained.world_strokes = strokes.into();
    let original_camera = CameraState::fit_to_bounds(&state.scene.bounds);
    let warm = PreparedScene::from_workspace_for_surface(
        &state,
        width,
        height,
        1.0,
        original_camera,
        &retained,
    )
    .unwrap();
    capture_retained(&mut renderer, &warm, &retained);
    renderer
        .renderer
        .enable_gpu_measurements(
            &renderer.device,
            &renderer.queue,
            191,
            1,
            Box::new(|r| panic!("unexpected timestamp cancellation: {r:?}")),
        )
        .unwrap();

    for scale in [1.0, 1.5, 2.0] {
        for zoom in [0.65, 1.0, 1.7] {
            let mut camera = original_camera;
            camera.zoom *= zoom;
            camera.center_x_nm += 12345.0;
            let prepared = PreparedScene::from_workspace_for_surface(
                &state, width, height, scale, camera, &retained,
            )
            .unwrap();
            renderer.renderer.world_stroke_pipeline = old.clone();
            renderer.renderer.surface_world_bundles.clear();
            let expected = capture_retained(&mut renderer, &prepared, &retained);
            let old_gpu = renderer
                .renderer
                .poll_gpu_measurements(&renderer.device)
                .unwrap();
            renderer.renderer.world_stroke_pipeline = new.clone();
            renderer.renderer.surface_world_bundles.clear();
            let actual = capture_retained(&mut renderer, &prepared, &retained);
            let new_gpu = renderer
                .renderer
                .poll_gpu_measurements(&renderer.device)
                .unwrap();
            let different = expected
                .pixels()
                .zip(actual.pixels())
                .filter(|(a, b)| a != b)
                .count();
            eprintln!(
                "stroke color scale={scale} zoom={zoom} pixels_different={different} old_gpu={old_gpu:?} new_gpu={new_gpu:?}"
            );
            assert_eq!(
                different, 0,
                "color relocation must preserve every RGBA pixel"
            );
            renderer.renderer.world_stroke_pipeline = wrong.clone();
            renderer.renderer.surface_world_bundles.clear();
            assert!(
                expected != capture_retained(&mut renderer, &prepared, &retained),
                "wrong stroke color must fail pixel oracle"
            );
            renderer
                .renderer
                .poll_gpu_measurements(&renderer.device)
                .unwrap();
        }
    }
}
