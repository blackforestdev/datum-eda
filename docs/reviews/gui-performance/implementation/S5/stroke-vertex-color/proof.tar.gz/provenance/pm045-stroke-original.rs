use super::{Output, PointNm};
use std::ops::Range;

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, bytemuck::Pod, bytemuck::Zeroable)]
pub(crate) struct WorldStrokeInstance {
    pub(crate) from: [f32; 2],
    pub(crate) to: [f32; 2],
    pub(crate) color_min_px: [f32; 4],
    pub(crate) nominal_nm: f32,
    pub(crate) _pad: [f32; 3],
}

impl WorldStrokeInstance {
    pub(crate) fn segment(
        from: PointNm,
        to: PointNm,
        color: [f32; 3],
        nominal_nm: i64,
        min_px: f32,
    ) -> Self {
        Self {
            from: [from.x as f32, from.y as f32],
            to: [to.x as f32, to.y as f32],
            color_min_px: [color[0], color[1], color[2], min_px],
            nominal_nm: nominal_nm.max(1) as f32,
            _pad: [0.0; 3],
        }
    }
    #[cfg(test)]
    pub(crate) fn resolved_width_px(self, live_scale: f32) -> f32 {
        (self.nominal_nm * live_scale).max(self.color_min_px[3])
    }
    pub(crate) fn layout<'a>() -> wgpu::VertexBufferLayout<'a> {
        wgpu::VertexBufferLayout {
            array_stride: std::mem::size_of::<Self>() as u64,
            step_mode: wgpu::VertexStepMode::Instance,
            attributes: &[
                wgpu::VertexAttribute {
                    offset: 0,
                    shader_location: 0,
                    format: wgpu::VertexFormat::Float32x2,
                },
                wgpu::VertexAttribute {
                    offset: 8,
                    shader_location: 1,
                    format: wgpu::VertexFormat::Float32x2,
                },
                wgpu::VertexAttribute {
                    offset: 16,
                    shader_location: 2,
                    format: wgpu::VertexFormat::Float32x4,
                },
                wgpu::VertexAttribute {
                    offset: 32,
                    shader_location: 3,
                    format: wgpu::VertexFormat::Float32,
                },
            ],
        }
    }
}

pub(crate) fn push_world_stroke_path(
    out: &mut impl Output<WorldStrokeInstance>,
    path: &[PointNm],
    color: [f32; 3],
    nominal_nm: i64,
    min_px: f32,
) {
    out.extend(
        path.windows(2)
            .filter(|e| e[0] != e[1])
            .map(|e| WorldStrokeInstance::segment(e[0], e[1], color, nominal_nm, min_px)),
    );
}

pub(crate) fn push_world_stroke_loop(
    out: &mut impl Output<WorldStrokeInstance>,
    path: &[PointNm],
    color: [f32; 3],
    nominal_nm: i64,
    min_px: f32,
) {
    push_world_stroke_path(out, path, color, nominal_nm, min_px);
    if let (Some(first), Some(last)) = (path.first(), path.last())
        && first != last
    {
        out.push(WorldStrokeInstance::segment(
            *last, *first, color, nominal_nm, min_px,
        ));
    }
}

pub(crate) fn push_board_graphic_semantic_stroke(
    out: &mut impl Output<super::Quad>,
    strokes: &mut impl Output<WorldStrokeInstance>,
    graphic: &super::BoardGraphicPrimitive,
    color: [f32; 3],
) {
    if graphic.primitive_kind == "polygon" && graphic.path.len() >= 3 {
        super::push_world_polygon_fill_contours(out, &graphic.path, &graphic.holes, color);
        if graphic.width_nm.is_none() {
            return;
        }
    }
    let (nominal_nm, min_px) =
        super::semantic_graphic_kind(&graphic.object_id, &graphic.layer_id, graphic.width_nm)
            .nominal_and_floor();
    if graphic.primitive_kind == "polygon" {
        push_world_stroke_loop(strokes, &graphic.path, color, nominal_nm, min_px);
    } else {
        push_world_stroke_path(strokes, &graphic.path, color, nominal_nm, min_px);
    }
}

pub(crate) const WORLD_STROKE_SHADER: &str = r#"
struct SceneUniform { resolution: vec4<f32>, viewport_origin: vec4<f32>, viewport_size: vec4<f32>, camera_center_scale: vec4<f32> };
@group(0) @binding(0) var<uniform> scene: SceneUniform;
struct In { @builtin(vertex_index) vertex: u32, @location(0) point_a: vec2<f32>, @location(1) point_b: vec2<f32>, @location(2) color_min_px: vec4<f32>, @location(3) nominal_nm: f32 };
struct Out {
 @builtin(position) position: vec4<f32>,
 @location(0) color: vec3<f32>,
 @location(1) local_px: vec2<f32>,
 @location(2) capsule_px: vec2<f32>,
};
@vertex fn vs_main(i: In) -> Out {
 let endpoint_b = i.vertex == 1u || i.vertex == 2u || i.vertex == 4u;
 let positive = i.vertex == 0u || i.vertex == 1u || i.vertex == 3u;
 let center = select(i.point_a, i.point_b, endpoint_b); let d = i.point_b - i.point_a;
 let tangent = d / max(length(d), 1.0); let normal = vec2<f32>(-tangent.y, tangent.x);
 let width = max(i.nominal_nm * scene.camera_center_scale.z, i.color_min_px.w);
 let radius = width * 0.5;
 let half_length = length(d) * scene.camera_center_scale.z * 0.5;
 let sc = scene.viewport_origin.xy + scene.viewport_size.xy * 0.5
     + (center - scene.camera_center_scale.xy) * scene.camera_center_scale.z
     + tangent * select(-1.0, 1.0, endpoint_b) * radius;
 let across = select(-1.0, 1.0, positive) * radius;
 let along = select(-1.0, 1.0, endpoint_b) * (half_length + radius);
 let p = sc + normal * across; var o: Out;
 o.position = vec4<f32>((p.x / scene.resolution.x) * 2.0 - 1.0, 1.0 - (p.y / scene.resolution.y) * 2.0, 0.0, 1.0);
 o.color = i.color_min_px.xyz;
 o.local_px = vec2<f32>(along, across);
 o.capsule_px = vec2<f32>(half_length, radius);
 return o;
}
fn srgb_to_linear(c: vec3<f32>) -> vec3<f32> { return select(pow((c + vec3<f32>(0.055)) / 1.055, vec3<f32>(2.4)), c / 12.92, c <= vec3<f32>(0.04045)); }
@fragment fn fs_main(i: Out, @builtin(sample_index) sample_index: u32) -> @location(0) vec4<f32> {
 // The six vertices form the capsule's bounding rectangle. Reject its four
 // square corners analytically so every retained segment has true round caps.
 // Adjacent segment capsules overlap at their shared endpoint, restoring the
 // round, gap-free joins used by imported two-point KiCad tracks. Requesting
 // sample_index makes this test run per sample, preserving antialiasing at the
 // analytic edge when the renderer's multisampled target is active.
 let cap_distance = max(abs(i.local_px.x) - i.capsule_px.x, 0.0);
 let distance_squared = cap_distance * cap_distance + i.local_px.y * i.local_px.y;
 if distance_squared > i.capsule_px.y * i.capsule_px.y { discard; }
 return vec4<f32>(srgb_to_linear(i.color), 1.0);
}
"#;

pub(crate) fn create_world_stroke_pipeline(
    device: &wgpu::Device,
    layout: &wgpu::PipelineLayout,
    format: wgpu::TextureFormat,
    samples: u32,
) -> wgpu::RenderPipeline {
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("datum-world-stroke-shader"),
        source: wgpu::ShaderSource::Wgsl(WORLD_STROKE_SHADER.into()),
    });
    device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("datum-world-stroke-pipeline"),
        layout: Some(layout),
        vertex: wgpu::VertexState {
            module: &shader,
            entry_point: Some("vs_main"),
            buffers: &[WorldStrokeInstance::layout()],
            compilation_options: Default::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format,
                blend: Some(wgpu::BlendState::REPLACE),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState {
            count: samples,
            mask: !0,
            alpha_to_coverage_enabled: false,
        },
        multiview_mask: None,
        cache: None,
    })
}

pub(crate) fn draw_world_strokes<'a>(
    pass: &mut wgpu::RenderPass<'a>,
    pipeline: &'a wgpu::RenderPipeline,
    bind_group: &'a wgpu::BindGroup,
    buffer: &'a wgpu::Buffer,
    viewport: super::RectPx,
    ranges: &[Range<u32>],
) {
    if ranges.is_empty() {
        return;
    }
    pass.set_pipeline(pipeline);
    pass.set_bind_group(0, bind_group, &[]);
    pass.set_scissor_rect(
        viewport.x.max(0.0).floor() as u32,
        viewport.y.max(0.0).floor() as u32,
        viewport.width.max(1.0).ceil() as u32,
        viewport.height.max(1.0).ceil() as u32,
    );
    pass.set_vertex_buffer(0, buffer.slice(..));
    for range in ranges {
        pass.draw(0..6, range.clone());
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn capsule_contains(local_px: [f32; 2], half_length: f32, radius: f32) -> bool {
        let cap_distance = (local_px[0].abs() - half_length).max(0.0);
        cap_distance * cap_distance + local_px[1] * local_px[1] <= radius * radius
    }

    #[test]
    fn retained_stroke_uses_live_scale_and_px_floor() {
        let s = WorldStrokeInstance::segment(
            PointNm { x: 0, y: 0 },
            PointNm { x: 1_000_000, y: 0 },
            [1.0; 3],
            152_400,
            1.0,
        );
        let retained = s;
        assert_eq!(s.resolved_width_px(1e-9), 1.0);
        assert!((s.resolved_width_px(1e-4) - 15.24).abs() < 0.001);
        assert_eq!(
            s, retained,
            "camera changes must not mutate/rebuild retained strokes"
        );
    }

    #[test]
    fn round_caps_reject_square_corners_and_cover_shared_endpoints() {
        let (half_length, radius) = (10.0, 4.0);
        assert!(
            capsule_contains([10.0, 0.0], half_length, radius),
            "the endpoint center must be covered"
        );
        assert!(
            capsule_contains([14.0, 0.0], half_length, radius),
            "the radial cap edge must be covered"
        );
        assert!(
            capsule_contains([10.0, 4.0], half_length, radius),
            "a second capsule sharing the endpoint must overlap without a gap"
        );
        assert!(
            !capsule_contains([14.0, 4.0], half_length, radius),
            "a round cap must reject the old square projecting corner"
        );
        assert!(
            !capsule_contains([14.01, 0.0], half_length, radius),
            "coverage must stop beyond the cap radius"
        );
    }

    #[test]
    fn world_stroke_shader_contains_analytic_capsule_rejection() {
        assert!(WORLD_STROKE_SHADER.contains("let cap_distance ="));
        assert!(WORLD_STROKE_SHADER.contains("distance_squared >"));
        assert!(WORLD_STROKE_SHADER.contains("discard;"));
        assert!(WORLD_STROKE_SHADER.contains("@builtin(sample_index)"));
    }
}
