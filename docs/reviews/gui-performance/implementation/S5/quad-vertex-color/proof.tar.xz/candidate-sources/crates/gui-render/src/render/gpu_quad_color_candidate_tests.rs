//! Diagnostic-only candidate: production shaders stay unchanged until qualified.
use super::*;

fn pipeline(
    device: &wgpu::Device,
    binding: &wgpu::BindGroupLayout,
    source: &str,
) -> wgpu::RenderPipeline {
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("quad-color-candidate"),
        source: wgpu::ShaderSource::Wgsl(source.into()),
    });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("quad-color-candidate"),
        bind_group_layouts: &[binding],
        immediate_size: 0,
    });
    device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("quad-color-candidate"),
        layout: Some(&layout),
        vertex: wgpu::VertexState {
            module: &shader,
            entry_point: Some("vs_main"),
            buffers: &[crate::gpu_data::Vertex::layout()],
            compilation_options: Default::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format: OUTPUT_FORMAT,
                blend: Some(wgpu::BlendState::REPLACE),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState {
            count: 8,
            mask: !0,
            alpha_to_coverage_enabled: false,
        },
        multiview_mask: None,
        cache: None,
    })
}

fn candidate(source: &str) -> String {
    source
        .replace(
            "out.color = in.color;",
            "out.color = srgb_to_linear(in.color);",
        )
        .replace("srgb_to_linear(in.color), 1.0", "in.color, 1.0")
        .replace(
            "@location(0) color: vec3<f32>",
            "@location(0) @interpolate(flat) color: vec3<f32>",
        )
}

#[test]
#[ignore = "requires local GPU and pinned native project; diagnostic candidate only"]
fn quad_vertex_color_matches_production_shader() {
    let root = std::env::var_os("PM045_QUAD_NATIVE_PROJECT").expect("pinned project required");
    let state = datum_gui_protocol::load_board_editor_workspace_state(
        &datum_gui_protocol::LiveReviewRequest {
            project_root: root.into(),
            board_file: None,
            artifact_path: None,
            net_uuid: None,
            from_anchor_pad_uuid: None,
            to_anchor_pad_uuid: None,
            profile: None,
            kicad_board_source: None,
        },
    )
    .unwrap();
    let (width, height) = (1280, 800);
    let mut renderer = hardware_renderer_with_features(
        width,
        height,
        wgpu::Features::TIMESTAMP_QUERY | wgpu::Features::TEXTURE_ADAPTER_SPECIFIC_FORMAT_FEATURES,
    );
    renderer.renderer = Renderer::new(&renderer.device, &renderer.queue, OUTPUT_FORMAT, 8).unwrap();
    let sources: Vec<_> = include_str!("gpu_init.rs")
        .split("r#\"")
        .skip(1)
        .map(|s| s.split("\"#").next().unwrap())
        .take(2)
        .collect();
    assert_eq!(sources.len(), 2);
    let screen_binding = renderer.renderer.pipeline.get_bind_group_layout(0);
    let old_screen = pipeline(
        &renderer.device,
        &screen_binding,
        include_str!("../../testdata/quad-screen-before.wgsl"),
    );
    let old_world = pipeline(
        &renderer.device,
        &renderer.renderer.scene_bind_group_layout,
        include_str!("../../testdata/quad-world-before.wgsl"),
    );
    assert_eq!(
        sources[0],
        candidate(include_str!("../../testdata/quad-screen-before.wgsl"))
    );
    assert_eq!(
        sources[1],
        candidate(include_str!("../../testdata/quad-world-before.wgsl"))
    );
    let new_screen = pipeline(&renderer.device, &screen_binding, &candidate(sources[0]));
    let new_world = pipeline(
        &renderer.device,
        &renderer.renderer.scene_bind_group_layout,
        &candidate(sources[1]),
    );
    let wrong_world = pipeline(
        &renderer.device,
        &renderer.renderer.scene_bind_group_layout,
        &candidate(sources[1]).replace(
            "return vec4<f32>(in.color, 1.0);",
            "return vec4<f32>(0.0, 0.0, 0.0, 1.0);",
        ),
    );
    let retained = RetainedScene::from_workspace(&state, width, height);
    assert!(!retained.world_vertices().is_empty());
    assert!(
        retained
            .world_vertices()
            .chunks_exact(3)
            .all(|t| t[0].color == t[1].color && t[0].color == t[2].color)
    );
    let original = CameraState::fit_to_bounds(&state.scene.bounds);
    let warm =
        PreparedScene::from_workspace_for_surface(&state, width, height, 1.0, original, &retained)
            .unwrap();
    capture_retained(&mut renderer, &warm, &retained);
    renderer
        .renderer
        .enable_gpu_measurements(
            &renderer.device,
            &renderer.queue,
            192,
            1,
            Box::new(|r| panic!("unexpected timestamp cancellation: {r:?}")),
        )
        .unwrap();
    for scale in [1.0, 1.5, 2.0] {
        for zoom in [0.65, 1.0, 1.7] {
            let mut camera = original;
            camera.zoom *= zoom;
            camera.center_x_nm += 12345.0;
            let prepared = PreparedScene::from_workspace_for_surface(
                &state, width, height, scale, camera, &retained,
            )
            .unwrap();
            renderer.renderer.pipeline = old_screen.clone();
            renderer.renderer.world_pipeline = old_world.clone();
            renderer.renderer.surface_world_bundles.clear();
            let expected = capture_retained(&mut renderer, &prepared, &retained);
            let old_gpu = renderer
                .renderer
                .poll_gpu_measurements(&renderer.device)
                .unwrap();
            renderer.renderer.pipeline = new_screen.clone();
            renderer.renderer.world_pipeline = new_world.clone();
            renderer.renderer.surface_world_bundles.clear();
            let actual = capture_retained(&mut renderer, &prepared, &retained);
            let new_gpu = renderer
                .renderer
                .poll_gpu_measurements(&renderer.device)
                .unwrap();
            let different = expected
                .pixels()
                .zip(actual.pixels())
                .filter(|(a, b)| a != b)
                .count();
            eprintln!(
                "quad color scale={scale} zoom={zoom} pixels_different={different} old_gpu={old_gpu:?} new_gpu={new_gpu:?}"
            );
            assert_eq!(
                different, 0,
                "all RGBA pixels must match; no golden refresh"
            );
            renderer.renderer.world_pipeline = wrong_world.clone();
            renderer.renderer.surface_world_bundles.clear();
            let wrong = capture_retained(&mut renderer, &prepared, &retained);
            assert!(
                expected.pixels().zip(wrong.pixels()).any(|(a, b)| a != b),
                "wrong-color negative must be detected"
            );
            renderer
                .renderer
                .poll_gpu_measurements(&renderer.device)
                .unwrap();
        }
    }
}
