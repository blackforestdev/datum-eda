
#[test]
#[ignore = "requires local GPU; native dialog palettes against frozen shader"]
fn quad_vertex_color_preserves_dialogs_and_transfer_thresholds() {
    let mut host = hardware_renderer_with_features(960, 720,
        wgpu::Features::TEXTURE_ADAPTER_SPECIFIC_FORMAT_FEATURES);
    host.renderer = Renderer::new(&host.device, &host.queue, OUTPUT_FORMAT, 8).unwrap();
    let binding = host.renderer.pipeline.get_bind_group_layout(0);
    let reference = pipeline(&host.device, &binding, include_str!("../../testdata/quad-screen-before.wgsl"));
    let actual = host.renderer.pipeline.clone();
    let wrong = pipeline(&host.device, &binding,
        &candidate(include_str!("../../testdata/quad-screen-before.wgsl"))
            .replace("return vec4<f32>(in.color, 1.0);", "return vec4<f32>(0.0, 0.0, 0.0, 1.0);"));
    let mut state = crate::global_preferences_dialog_tests::state_with_preferences_open();
    state.ui.project_preferences.open = true;
    state.ui.new_project.open = true;
    for scale in [1.0, 1.5, 2.0] {
        for kind in 0..4 {
            let mut prepared = match kind {
                0 => PreparedScene::from_native_preferences(&state.ui.global_preferences,960,720,scale).unwrap(),
                1 => PreparedScene::from_native_preferences(&state.ui.project_preferences,960,720,scale).unwrap(),
                _ => host.renderer.prepare_native_new_project(&state.ui.new_project,960,720,scale).unwrap(),
            };
            if kind == 3 {
                // Unit geometry only: one constant sRGB color per quad, including
                // threshold neighbors and every eight-bit channel value.
                let mut quads = Vec::new();
                for i in 0..256 {
                    let v = i as f32 / 255.0;
                    let threshold = [0.0, 0.040449, 0.04045, 0.040451][i % 4];
                    quads.push(crate::Quad::from_rect(crate::RectPx {
                        x: (i % 16) as f32 * 57.0 + 0.375,
                        y: (i / 16) as f32 * 43.0 + 0.625,
                        width: 55.25, height: 41.5,
                    }, [v, threshold, 1.0-v]));
                }
                prepared.menu_overlay_vertices = crate::gpu_data::quads_to_vertices(&quads);
            }
            host.renderer.pipeline = reference.clone();
            let expected = capture(&mut host,&prepared);
            host.renderer.pipeline = actual.clone();
            let image = capture(&mut host,&prepared);
            let differences = expected.pixels().zip(image.pixels()).filter(|(a,b)|a!=b).count();
            eprintln!("quad dialogs kind={kind} scale={scale} pixels_different={differences}");
            assert_eq!(differences,0);
            host.renderer.pipeline = wrong.clone();
            let negative = capture(&mut host,&prepared);
            assert!(expected.pixels().zip(negative.pixels()).any(|(a,b)|a!=b));
        }
    }
}
