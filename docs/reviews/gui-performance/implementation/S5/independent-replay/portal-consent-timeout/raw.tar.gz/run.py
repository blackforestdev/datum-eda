import os
from pathlib import Path
import subprocess
import sys
root=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(root/'scripts'))
import run_cargo_guarded as guard
raw=Path(__file__).resolve().parent
env=os.environ.copy()
env.update(PM045_REPLAY_OUTPUT_ROOT=str(raw),PM045_REPLAY_PROJECT='/tmp/pm045-independent-replay-fixture/project')
policy=guard.load_policy()
with guard.acquire_lock(policy.lock_path,policy.lock_timeout_seconds):
    result=subprocess.run([sys.executable,str(raw/'native_pointer.py')],env=env,cwd=root)
raise SystemExit(result.returncode)
