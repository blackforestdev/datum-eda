"""Single-session controller for the preserved portal pointer method."""
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import time

class Portal:
    def __init__(self, root):
        self.root = root
        self.output = root / 'portal'
        self.log = (root / 'portal-stderr.log').open('w')
        self.process = subprocess.Popen([sys.executable, str(Path(__file__).with_name('portal_pointer.py')), '--serve', str(self.output)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.log)
        self.buffer = b''

    def response(self, timeout):
        deadline = time.monotonic() + timeout
        while b'\n' not in self.buffer:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not select.select([self.process.stdout], [], [], remaining)[0]:
                raise TimeoutError('portal response timeout')
            chunk = os.read(self.process.stdout.fileno(), 4096)
            if not chunk:
                raise RuntimeError(('portal exited before response', self.process.poll()))
            self.buffer += chunk
            if len(self.buffer) > 8192:
                raise RuntimeError('portal response exceeds bound')
        line, self.buffer = self.buffer.split(b'\n', 1)
        return json.loads(line)

    def start(self):
        assert self.response(310).get('ready') is True

    def run(self):
        self.process.stdin.write(b'{"action":"pointer_stream","output_scale":1,"initial_position_verified":true}\n')
        self.process.stdin.flush()
        assert self.response(40).get('stream_finished') is True
        rows = [json.loads(line) for line in (self.output/'events.jsonl').read_text().splitlines()]
        requests = [r for r in rows if r['kind']=='request_returned']
        assert len(requests) == 3600
        assert not any(r['kind'] in ('error','deadline_missed','deadline_missed_before_call') for r in rows)
        for r in requests:
            assert r['sent_ns'] >= r['due_ns'] and r['returned_ns'] - r['due_ns'] < round(1e9/120)
        (self.root/'pointer-input.json').write_text(json.dumps({'scheduled_count':3600,'rows':requests},indent=2)+'\n')

    def close(self):
        errors = []
        if self.process.poll() is None:
            try:
                self.process.stdin.write(b'{"action":"close"}\n')
                self.process.stdin.flush()
            except BaseException as error:
                errors.append(repr(error))
            for operation, timeout in ((None, 5), (self.process.terminate, 5), (self.process.kill, 5)):
                if self.process.poll() is not None:
                    break
                try:
                    if operation is not None:
                        errors.append('forced portal cleanup')
                        operation()
                    self.process.wait(timeout=timeout)
                except BaseException as error:
                    errors.append(repr(error))
        try:
            self.process.stdin.close()
            self.process.stdout.close()
        except BaseException as error:
            errors.append(repr(error))
        self.log.close()
        if self.process.poll() is None or self.process.returncode != 0 or errors:
            raise RuntimeError(('portal cleanup incomplete or failed', self.process.poll(), errors))
