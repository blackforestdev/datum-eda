set pagination off
set debuginfod enabled off
python
import gdb,json
displays=['0x557dd76ca4d0', '0x557dd7d5dac0', '0x557dd82d38c0']
offsets={'qlen': 136, 'head': 120, 'qevent_event': 8, 'qevent_next': 0, 'event_type': 0, 'event_window': 32, 'event_message_type': 40, 'event_data': 56}
def read(a,n): return int.from_bytes(bytes(gdb.selected_inferior().read_memory(a,n)),"little")
records=[]
for value in displays:
 d=int(value,16); row={"display":value,"events":[]}
 try:
  row["qlen"]=read(d+offsets["qlen"],4); node=read(d+offsets["head"],8); seen=set()
  while node and node not in seen and len(seen)<1024:
   seen.add(node); e=node+offsets["qevent_event"]; row["events"].append({"type":read(e+offsets["event_type"],4),"window":read(e+offsets["event_window"],8),"message_type":read(e+offsets["event_message_type"],8),"data0":read(e+offsets["event_data"],8)});node=read(node+offsets["qevent_next"],8)
 except Exception as error: row["error"]=repr(error)
 records.append(row)
open('/tmp/pm045-x11-close-v3-eiuhwbsr/queue-memory.json',"w").write(json.dumps(records,indent=2)+"\n")
end
thread apply all bt
detach
