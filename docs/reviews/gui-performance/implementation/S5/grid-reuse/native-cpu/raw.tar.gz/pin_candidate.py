import hashlib,json,platform,shutil,subprocess
from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
bindings=json.loads((out/'source-bindings.json').read_text())
assert all(sha(root/p)==h for p,h in bindings.items()), 'source changed during build'
assert not subprocess.check_output(['git','status','--porcelain'],text=True), 'checkout dirty'
log=Path('/tmp/pm045-grid-cpu-release.log');assert 'Finished `release` profile' in log.read_text()
source=root/'target/release/datum-gui';digest=sha(source)
path=root/'target/pm045-independent-replay-artifacts'/f'candidate-grid-reuse-{digest[:12]}-datum-gui'
assert not path.exists();shutil.copy2(source,path);assert sha(path)==digest
candidate={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'binary':str(path.relative_to(root)),'binary_sha256':digest,'source_bindings_sha256':sha(out/'source-bindings.json'),'build_command':'python3 scripts/run_cargo_guarded.py --workload proof -- cargo build --release --locked --offline -p datum-gui-app --bin datum-gui','kernel':platform.release(),'status':'Affected quiet CPU measurement candidate; not final replay ready'}
(out/'candidate.json').write_text(json.dumps(candidate,indent=2)+'\n');shutil.copy2(log,out/'build.log');print(json.dumps(candidate))
