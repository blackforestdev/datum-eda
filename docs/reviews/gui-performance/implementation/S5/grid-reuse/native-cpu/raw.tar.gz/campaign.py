"""Three fixed quiet pointer/clamp trials; no failed-run replacement."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], text=True).strip())
sys.path.insert(0, str(ROOT/'scripts'))
import run_cargo_guarded as guard

raw_root = Path(__file__).resolve().parent
out = Path(tempfile.mkdtemp(prefix='campaign-', dir=raw_root))
print(out, flush=True)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
candidate = json.loads((raw_root/'candidate.json').read_text())
paths = [Path(__file__).resolve()] + [raw_root/name for name in ('native_combined.py','candidate.json','source-bindings.json','pointer-stream.py','pointer-reference.png')]
paths += [ROOT/candidate['binary'], ROOT/'target/pm045-independent-replay-artifacts/datum-eda']
paths += [ROOT/'docs/reviews/gui-performance/implementation/S5/clamp-matched-batch/tools'/name for name in ('pm045-wheel-stream.py','pm045-wheel-edges.py')]
paths += [ROOT/'docs/reviews/gui-performance/implementation/S5/resource-snapshots/tools/pm045_wm_close.py']
fixed = {str(p):sha(p) for p in paths}
assert fixed[str(ROOT/candidate['binary'])] == candidate['binary_sha256']
declaration = {'candidate':candidate,'fixed_files_sha256':fixed,'order':[1,2,3],
    'purpose':'Determine whether current grid/camera corrections leave quiet X11/1x pointer or clamp CPU failures. No relative or full qualification claim.',
    'schedule':'Each fresh process: pointer at300,150,exact pinned reference,5swarmup,30s rectangle at120scheduled positions/s,5stail; then minimum and maximum clamp30s each at60alternating wheel edges/s with untimed setup and5stails plus inward reversal.',
    'cpu_limits_percent_one_core':{'pointer':10,'clamp':1},
    'stop':'Exactly three unless infrastructure/output failure; no retries or replacements. Numerical failure is retained and does not stop remaining declared trials.',
    'limits':'Quiet family CPU includes helper startup/scheduling duration but helper CPU is outside family cgroup. No received semantic-action denominator, full work-count/GPU/resource/backend-scale/independent or owner acceptance.'}
(out/'declaration.json').write_text(json.dumps(declaration,indent=2)+'\n')
env=os.environ.copy()
env.update(PM045_REPLAY_OUTPUT_ROOT=str(raw_root),PM045_REPLAY_PROJECT='/tmp/pm045-independent-replay-fixture/project')
results=[]
policy=guard.load_policy()
with guard.acquire_lock(policy.lock_path, policy.lock_timeout_seconds):
    for trial in declaration['order']:
        assert all(sha(p)==h for p,h in fixed.items()), 'campaign files changed before trial'
        with (out/f'trial-{trial}.log').open('w') as log:
            result=subprocess.run([sys.executable,str(raw_root/'native_combined.py')],env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        lines=(out/f'trial-{trial}.log').read_text().splitlines()
        row={'trial':trial,'returncode':result.returncode,'raw':lines[0] if lines else None,'fixed_files_unchanged':all(sha(p)==h for p,h in fixed.items())}
        results.append(row)
        (out/'result.json').write_text(json.dumps(results,indent=2)+'\n')
        print(json.dumps(row),flush=True)
        if result.returncode or not row['fixed_files_unchanged']:break
raise SystemExit(0 if len(results)==3 and all(r['returncode']==0 and r['fixed_files_unchanged'] for r in results) else 1)
