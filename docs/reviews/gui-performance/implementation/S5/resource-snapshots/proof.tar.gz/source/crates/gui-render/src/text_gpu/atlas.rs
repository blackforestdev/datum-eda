//! Datum-owned glyph texture pages. Rasterization remains an existing public API.
//!
//! Shared by workspace and overlay drawing. Full PM045 accounting also requires
//! CPU/font scratch, aggregate staging and cross-host qualification.
use super::staging_vec::StagingVec;

use super::raster::Raster as SwashCache;
use glyphon::{CacheKey, SwashContent};

use super::lifetime::{Kind, Owner, SubmissionRef, Tracked};
#[path = "atlas/chunks.rs"]
mod chunks;
#[path = "atlas/cpu_images.rs"]
mod cpu_images;
#[path = "atlas/glyph_map.rs"]
mod glyph_map;
#[path = "atlas/pending_metadata.rs"]
mod pending_metadata;
pub(crate) use cpu_images::UploadRequired;
const RETAINED_LIMIT: u64 = 32 * 1024 * 1024;

#[derive(Clone, Copy, Debug)]
pub(super) struct GlyphLocation {
    pub page: usize,
    pub origin: [u32; 2],
    pub size: [u32; 2],
    pub bearing: [i32; 2],
    pub color: bool,
}

/// Append-only shelves preserve every prepared glyph address until reset.
#[derive(Default)]
struct Shelves {
    x: u32,
    y: u32,
    row_height: u32,
}

impl Shelves {
    fn reserve(&mut self, size: [u32; 2], extent: u32) -> Option<[u32; 2]> {
        if size.contains(&0) || size[0] > extent || size[1] > extent {
            return None;
        }
        let (x, y, row_height) = if self.x + size[0] > extent {
            (0, self.y + self.row_height, 0)
        } else {
            (self.x, self.y, self.row_height)
        };
        if y + size[1] > extent {
            return None;
        }
        self.x = x + size[0];
        self.y = y;
        self.row_height = row_height.max(size[1]);
        Some([x, y])
    }
}

pub(super) struct Page {
    // Release the page's binding reference before its charged texture owner.
    pub bind_group: wgpu::BindGroup,
    pub texture: Tracked<wgpu::Texture>,
    extent: u32,
    color: bool,
    shelves: Shelves,
}

#[derive(Default, Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct Uploads {
    pub bytes: u64,
    pub writes: u64,
    pub rasterizations: u64,
}

struct PendingUpload {
    uploaded_rows: u32,
    page: usize,
    origin: [u32; 2],
    size: [u32; 2],
    stride: u32,
    pixels: super::raster::Pixels,
}

pub(crate) struct Atlas {
    pub owner: Owner,
    pub layout: wgpu::BindGroupLayout,
    pub(super) pages: StagingVec<Page>,
    pub generation: u64,
    pub(super) uploads: Uploads,
    scatter: super::sparse_upload::Scatter,
    glyphs: glyph_map::GlyphMap,
    pending_uploads: StagingVec<PendingUpload>,
    pending_copy_bytes: u64,
    local_budget: std::sync::Arc<super::budget::Budget>,
    page_generations: std::sync::Arc<super::budget::Budget>,
    page_generation: std::sync::Weak<super::budget::Permit>,
    pub(crate) staging_budget: std::sync::Arc<super::budget::Budget>,
    texture_budget: std::sync::Arc<super::budget::Budget>,
}

impl Atlas {
    #[cfg(all(test, feature = "visual"))]
    pub fn new(device: &wgpu::Device) -> Self {
        Self::with_staging_budget(device, super::budget::Budget::new(16 * 1024 * 1024))
    }

    pub fn with_staging_budget(
        device: &wgpu::Device,
        staging_budget: std::sync::Arc<super::budget::Budget>,
    ) -> Self {
        Self {
            owner: Owner::new(),
            staging_budget,
            layout: device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: Some("datum-glyph-page-layout"),
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: false },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                }],
            }),
            pages: Default::default(),
            generation: 1,
            uploads: Uploads::default(),
            scatter: super::sparse_upload::Scatter::default(),
            glyphs: glyph_map::GlyphMap::default(),
            pending_uploads: Default::default(),
            pending_copy_bytes: 0,
            local_budget: super::budget::Budget::new(RETAINED_LIMIT),
            page_generations: super::budget::Budget::new(2),
            page_generation: std::sync::Weak::new(),
            texture_budget: super::budget::process(),
        }
    }

    /// Recreate device objects while old pages remain charged to this host.
    pub fn replacement(&self, device: &wgpu::Device) -> Self {
        let mut replacement = Self::with_staging_budget(device, self.staging_budget.clone());
        replacement.local_budget = self.local_budget.clone();
        replacement.page_generations = self.page_generations.clone();
        replacement.texture_budget = self.texture_budget.clone();
        replacement.owner = self.owner.clone();
        replacement.generation = self.generation.wrapping_add(1);
        replacement
    }

    /// Flush immediately before the frame submission. Failed preparation and
    /// close can discard pending CPU images without leaving unsubmitted writes.
    pub fn has_pending_uploads(&self) -> bool {
        !self.pending_uploads.is_empty()
    }

    /// Copy capacity and both planning/retirement vectors overlap during encoding.
    pub(crate) fn required_staging_bytes(
        &self,
        buffers: &[super::upload::BufferUpload<'_>],
    ) -> anyhow::Result<u64> {
        if self.pending_uploads.is_empty() && buffers.is_empty() {
            return Ok(0);
        }
        Ok(self.pending_staging_bytes()
            + super::upload::required_bytes(&[], buffers)
            + super::staging_vec::StagingVec::<super::upload::TextureUpload<'_>>::capacity_bytes(
                self.pending_uploads.len(),
            )?
            + super::upload::retention_metadata_bytes(buffers, true)?
            + super::upload::destination_metadata_bytes(self.pending_uploads.len())?)
    }

    pub fn flush_uploads(
        &mut self,
        device: &wgpu::Device,
        buffers: &[super::upload::BufferUpload<'_>],
    ) -> anyhow::Result<Option<super::upload::Batch>> {
        let mut uploads =
            super::staging_vec::StagingVec::new(self.pending_uploads.len(), &self.staging_budget)?;
        for upload in self.pending_uploads.iter() {
            uploads.push(super::upload::TextureUpload {
                target: Some(self.pages[upload.page].texture.upload_target()),
                texture: &self.pages[upload.page].texture,
                origin: [upload.origin[0], upload.origin[1] + upload.uploaded_rows],
                size: [upload.size[0], upload.size[1] - upload.uploaded_rows],
                stride: upload.stride,
                pixels: &upload.pixels[(upload.uploaded_rows * upload.stride) as usize..],
            });
        }
        let batch = super::upload::batch_with_scatter(
            device,
            &self.owner,
            self.generation,
            &self.staging_budget,
            &uploads,
            buffers,
            Some(&self.scatter),
        )?;
        drop(uploads);
        self.pending_copy_bytes = 0;
        for upload in self.pending_uploads.drain_all() {
            self.uploads.writes += 1;
            self.uploads.bytes +=
                u64::from(upload.size[1] - upload.uploaded_rows) * u64::from(upload.stride);
        }
        self.release_empty_pending_metadata();
        Ok(batch)
    }

    #[cfg(all(test, feature = "visual"))]
    pub fn flush_for_test(&mut self, device: &wgpu::Device, queue: &wgpu::Queue) {
        if let Some(mut batch) = self.flush_uploads(device, &[]).unwrap() {
            queue.submit([batch.command()]);
            batch.hold(queue);
        }
    }

    pub(crate) fn set_consumers(&self, consumers: crate::resource_consumers::Consumers) {
        for page in self.pages.iter() {
            page.texture.set_consumers(consumers);
        }
    }

    pub fn submission_refs(&self) -> Vec<SubmissionRef> {
        self.pages
            .iter()
            .map(|page| page.texture.submission_ref())
            .collect()
    }

    /// Reuse physical pages in queue order; all prepared address references
    /// become stale. Pending CPU uploads have not reached the queue and cancel.
    pub fn repack(&mut self) {
        self.glyphs.clear();
        self.pending_uploads.clear();
        self.release_empty_pending_metadata();
        self.pending_copy_bytes = 0;
        self.generation = self
            .generation
            .checked_add(1)
            .expect("atlas epoch exhausted");
        for page in self.pages.iter_mut() {
            page.shelves = Shelves::default();
        }
    }

    #[cfg(all(test, feature = "visual"))]
    pub(crate) fn set_test_limit(&mut self, bytes: u64) {
        assert_eq!(
            self.local_budget.used(),
            0,
            "test limit requires an empty atlas"
        );
        self.local_budget = super::budget::Budget::new(bytes);
    }

    pub(crate) fn texture_reservation_budget(&self) -> std::sync::Arc<super::budget::Budget> {
        self.local_budget.clone()
    }

    pub fn reserved_texture_bytes(&self) -> u64 {
        self.local_budget.used()
    }

    #[cfg(all(test, feature = "visual"))]
    fn retained_texture_bytes(&self) -> u64 {
        self.pages
            .iter()
            .map(|page| {
                page.texture.width() as u64
                    * page.texture.height() as u64
                    * page.texture.format().block_copy_size(None).unwrap() as u64
            })
            .sum()
    }

    /// Invalidate ALL prepared references. The caller owns retirement of returned
    /// pages through completion of their last submission (including queued writes).
    /// A CPU reset alone is not GPU release, and these bytes must remain charged.
    #[cfg(all(test, feature = "visual"))]
    pub(super) fn reset(&mut self) -> StagingVec<Page> {
        self.glyphs = glyph_map::GlyphMap::default();
        self.pending_uploads.clear();
        self.release_empty_pending_metadata();
        self.pending_copy_bytes = 0;
        self.generation = self
            .generation
            .checked_add(1)
            .expect("atlas epoch exhausted");
        self.page_generation = std::sync::Weak::new();
        std::mem::take(&mut self.pages)
    }

    pub(super) fn glyph(
        &mut self,
        device: &wgpu::Device,
        _queue: &wgpu::Queue,
        fonts: &mut impl crate::text_layout::fonts::Source,
        raster: &mut SwashCache,
        key: CacheKey,
    ) -> anyhow::Result<Option<GlyphLocation>> {
        if let Some(location) = self.glyphs.get(&key) {
            return Ok(*location);
        }
        if self.pending_staging_bytes() >= cpu_images::CHUNK_BYTES {
            return Err(UploadRequired.into());
        }
        match self.glyphs.reserve_one(&self.staging_budget) {
            Err(_) if self.has_pending_uploads() => return Err(UploadRequired.into()),
            result => result?,
        }
        if self.has_pending_uploads()
            && (self.staging_budget.available() == 0
                || super::budget::staging_process().available() == 0)
        {
            return Err(UploadRequired.into());
        }
        self.uploads.rasterizations += 1;
        let Some((image, pixels)) = raster.image(fonts, key, &self.staging_budget)? else {
            self.glyphs.insert(key, None);
            return Ok(None);
        };
        let size = [image.placement.width, image.placement.height];
        if size.contains(&0) {
            self.glyphs.insert(key, None);
            return Ok(None);
        }
        let color = match image.content {
            SwashContent::Mask => false,
            SwashContent::Color => true,
            SwashContent::SubpixelMask => anyhow::bail!("unsupported subpixel glyph image"),
        };
        let bytes_per_pixel = if color { 4 } else { 1 };
        anyhow::ensure!(
            pixels.len() as u64 == size[0] as u64 * size[1] as u64 * bytes_per_pixel,
            "glyph raster payload does not match its extent"
        );
        let padded = u64::from(
            (size[0] * bytes_per_pixel as u32).next_multiple_of(wgpu::COPY_BYTES_PER_ROW_ALIGNMENT),
        ) * u64::from(size[1]);
        if self.reserve_pending_metadata().is_err() {
            raster.clear();
            self.reserve_pending_metadata()?;
        }
        raster.release_for(
            (self.pending_staging_bytes() + padded).min(cpu_images::CHUNK_BYTES),
            &self.staging_budget,
        );
        if let Err(error) = self.reserve_copy_headroom(padded) {
            self.release_empty_pending_metadata();
            return Err(error);
        }
        let mut slot = None;
        for (index, page) in self.pages.iter_mut().enumerate() {
            if page.color == color
                && let Some(origin) = page.shelves.reserve(size, page.extent)
            {
                slot = Some((index, origin));
                break;
            }
        }
        let (page_index, origin) = match slot {
            Some(slot) => slot,
            None => {
                let limit = device.limits().max_texture_dimension_2d;
                let extent = 1024.min(limit).max(size[0]).max(size[1]);
                anyhow::ensure!(extent <= limit, "glyph exceeds device texture extent");
                let bytes = extent as u64 * extent as u64 * bytes_per_pixel;
                let generation_permit = match self.page_generation.upgrade() {
                    Some(permit) => permit,
                    None => {
                        std::sync::Arc::new(self.page_generations.reserve(1).map_err(|_| {
                            anyhow::anyhow!(
                                "atlas has two live page generations; wait for retirement"
                            )
                        })?)
                    }
                };
                self.reserve_page_metadata()?;
                let local_permit = self.local_budget.reserve(bytes)?;
                let permit = self.texture_budget.reserve(bytes)?;
                let reservation =
                    super::budget::GpuReservation::new(bytes, vec![local_permit, permit])?;
                let texture = device.create_texture(&wgpu::TextureDescriptor {
                    label: Some("datum-glyph-page"),
                    size: wgpu::Extent3d {
                        width: extent,
                        height: extent,
                        depth_or_array_layers: 1,
                    },
                    mip_level_count: 1,
                    sample_count: 1,
                    dimension: wgpu::TextureDimension::D2,
                    format: if color {
                        wgpu::TextureFormat::Rgba8UnormSrgb
                    } else {
                        wgpu::TextureFormat::R8Unorm
                    },
                    usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
                    view_formats: &[],
                });
                let view = texture.create_view(&Default::default());
                let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
                    label: Some("datum-glyph-page-binding"),
                    layout: &self.layout,
                    entries: &[wgpu::BindGroupEntry {
                        binding: 0,
                        resource: wgpu::BindingResource::TextureView(&view),
                    }],
                });
                let mut shelves = Shelves::default();
                let origin = shelves
                    .reserve(size, extent)
                    .expect("validated glyph extent");
                let index = self.pages.len();
                self.page_generation = std::sync::Arc::downgrade(&generation_permit);
                self.pages.push(Page {
                    texture: self
                        .owner
                        .track_reserved(texture, self.generation, Kind::Texture, reservation)
                        .with_shared_permit(generation_permit),
                    bind_group,
                    extent,
                    color,
                    shelves,
                });
                (index, origin)
            }
        };
        self.pending_copy_bytes += padded;
        self.pending_uploads.push(PendingUpload {
            uploaded_rows: 0,
            page: page_index,
            origin,
            size,
            stride: size[0] * bytes_per_pixel as u32,
            pixels,
        });
        let location = GlyphLocation {
            page: page_index,
            origin,
            size,
            bearing: [image.placement.left, image.placement.top],
            color,
        };
        self.glyphs.insert(key, Some(location));
        Ok(Some(location))
    }
}

#[cfg(all(test, feature = "visual"))]
#[path = "atlas/tests.rs"]
mod tests;
