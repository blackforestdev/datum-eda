"""Completion-bounded callback attribution; never performance acceptance."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parent
rows=json.loads((root/'campaign-v4_z1qcy/result.json').read_text());assert len(rows)==1 and rows[0]['returncode']==0 and rows[0]['fixed_files_unchanged']
run=Path(rows[0]['raw']);r=json.loads((run/'result.json').read_text());assert r['normal_exit_code']==0 and not r.get('error') and not r.get('cleanup_errors')
assert not r['remaining_before_cleanup'] and not r['remaining_after_cleanup'] and r['display_restore_returncode']==0
raw=(run/'native.log').read_bytes();pattern=re.compile(rb'cpu_probe phase=(\w+) wall_ns=(\d+) process_ns=(\d+) thread_ns=(\d+)')
intervals=[]
for name,trial in [('pointer',r['pointer_trial'])]+[(x['bound'],x) for x in r['clamp_trials']]:
 a,b=[r['samples'][trial[k]] for k in ['first_sample','last_sample']]
 phases={}
 for match in pattern.finditer(raw[a['log_bytes']:b['log_bytes']]):
  phase=match[1].decode();v=phases.setdefault(phase,{'count':0,'wall_ms':0.,'process_ms':0.,'thread_ms':0.});v['count']+=1
  for field,n in [('wall_ms',2),('process_ms',3),('thread_ms',4)]:v[field]+=int(match[n])/1e6
 gui_ms=(b['gui_cpu_ns']-a['gui_cpu_ns'])/1e6
 top=sum(v['thread_ms'] for k,v in phases.items() if k.startswith('window_') or k=='event_round')
 intervals.append({'name':name,'elapsed_seconds':trial['elapsed_seconds'],'gui_process_cpu_ms':gui_ms,'family_cpu_ms':trial['cpu_ms'],'phases':phases,'disjoint_top_level_thread_ms':top,'unattributed_gui_process_cpu_ms':gui_ms-top,'limit':'Top-level means observed window callbacks plus event_round. Residual includes probe output, uninstrumented callbacks, backend and other GUI threads; boundary skew is not removed. Nested phases must not be added.'})
result={'diagnostic_only':True,'qualification_pass':False,'run':str(run),'intervals':intervals,'normal_exit':True,'display_restored':True,'limits':['Scope-exit records selected by log byte offsets include completion-boundary skew. Not exact interval accounting.','Probe clock reads and output add substantial cost; outer phases include nested probe logging while own final logging is outside their end timestamp. No overhead subtraction from quiet qualification.','No statistical profile, backend-exclusive cost, performance pass or independent native replay.']}
(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
for v in intervals:print(v['name'], 'GUIms',round(v['gui_process_cpu_ms'],3),'topms',round(v['disjoint_top_level_thread_ms'],3),'phases', {k:(x['count'],round(x['thread_ms'],3)) for k,x in v['phases'].items()})
