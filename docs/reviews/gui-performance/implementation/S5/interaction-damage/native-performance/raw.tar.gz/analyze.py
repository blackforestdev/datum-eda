"""Consolidate the fixed campaign; no new application execution or sample retries."""
import collections
import hashlib
import json
import math
from pathlib import Path
import re

root=Path(__file__).resolve().parent
campaign=root/'campaign-9gg4ltot'
rows=json.loads((campaign/'result.json').read_text())
assert [(r['trial'],r['mode']) for r in rows]==[(n,m) for n in (1,2,3) for m in ('quiet','gpu')]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
declaration=json.loads((campaign/'declaration.json').read_text())
assert all(sha(p)==h for p,h in declaration['fixed_files_sha256'].items())
def quantiles(values):
    values=sorted(values)
    return {'count':len(values),'mean':sum(values)/len(values),'p95':values[math.ceil(len(values)*.95)-1],
            'p99':values[math.ceil(len(values)*.99)-1],'max':values[-1]}

def drm_delta(a,b,elapsed):
    key=lambda v:(v['driver'],v['pdev'],v['client_id'])
    left={key(c['first_sample']):c['first_sample'] for c in a['clients']}
    right={key(c['first_sample']):c['first_sample'] for c in b['clients']}
    engines=collections.Counter(); details=[]
    for identity in left.keys() & right.keys():
        x,y=left[identity],right[identity]
        assert (x['pid'],x['starttime_ticks'])==(y['pid'],y['starttime_ticks'])
        counters={}
        for name,value in x['raw_drm'].items():
            if not name.startswith('drm-engine-'): continue
            assert re.fullmatch(r'\d+ ns',value),value
            after=y['raw_drm'][name];assert re.fullmatch(r'\d+ ns',after),after
            delta=int(after.split()[0])-int(value.split()[0]);assert delta>=0
            counters[name]=delta;engines[name]+=delta
        details.append({'driver_pdev_client':identity,'pid':x['pid'],'starttime_ticks':x['starttime_ticks'],
                        'engine_deltas_ns':counters,'begin_read_bounds_ns':[x['started_ns'],x['finished_ns']],
                        'end_read_bounds_ns':[y['started_ns'],y['finished_ns']]})
    return {'complete_endpoint_enumerations':a['complete_enumeration'] and b['complete_enumeration'],
            'same_endpoint_client_set':left.keys()==right.keys(),'matched_clients':details,
            'matched_engine_percent_over_cpu_window':{k:v/(elapsed*1e9)*100 for k,v in engines.items()},
            'limit':'Endpoint-only matched clients, no full intervening client lifecycle or reset exclusion. Not full GPU-DUTY/ACC-03 acceptance.'}

results=[]
for row in rows:
    assert row['returncode']==0 and row['fixed_files_unchanged']
    raw=Path(row['raw']);r=json.loads((raw/'result.json').read_text())
    for field in ('error','cleanup_errors','persistence_errors','forced_cleanup','forced_descendant_cleanup',
                  'remaining_before_cleanup','remaining_after_cleanup'):
        assert not r.get(field),(raw,field,r.get(field))
    assert r['normal_exit_code']==0 and r['display_restore_returncode']==0
    for field in ('binary_unchanged','engine_unchanged','fixture_unchanged','pinned_assets_unchanged','production_source_unchanged'):
        assert r[field]
    p=r['pointer_trial']; assert p['endpoint_returncode']==0 and p['final_focus']==r['main_window']
    a,b=r['samples'][p['first_sample']],r['samples'][p['last_sample']]
    elapsed=(b['monotonic_ns']-a['monotonic_ns'])/1e9
    cpu=(b['group']['usage_usec']-a['group']['usage_usec'])/1e6/elapsed*100
    assert math.isclose(cpu,p['cpu_percent_one_core'],abs_tol=1e-9)
    schedule=json.loads((raw/'pointer-input.json').read_text());assert schedule['scheduled_count']==len(schedule['rows'])==3600
    for index,item in enumerate(schedule['rows']):
        edge=index//900;u=(index%900)/900
        point=[(300+400*u,150),(700,150+240*u),(700-400*u,390),(300,390-240*u)][edge]
        assert item['index']==index and item['scheduled_ns']==schedule['started_ns']+round(index*1e9/120)
        assert item['physical_position']==[round(v) for v in point]
    result={'trial':row['trial'],'mode':row['mode'],'raw':str(raw),'cpu_percent_one_core':cpu,
            'cpu_window_seconds':elapsed,'input_seconds':(schedule['finished_ns']-schedule['started_ns'])/1e9,
            'input_max_lateness_ms':max(v['sent_ns']-v['scheduled_ns'] for v in schedule['rows'])/1e6,
            'endpoint_AE':p['endpoint_AE'],'normal_exit_and_clean_restore':True}
    if row['mode']=='quiet': result['cpu_limit_pass']=cpu<=10
    else:
        samples=r['gpu_samples'];assert samples
        identities=set()
        for s in samples:
            identity=(s['host'],s['device_epoch'],s['frame'],s['submission']);assert identity not in identities;identities.add(identity)
            ticks=s['raw_ticks'];period=s['timestamp_period_ns'];assert period>0 and s['scene_marker_ticks'] is None
            assert len(ticks)==2*len(s['passes_ns']) and all(y>=x for x,y in zip(ticks,ticks[1:]))
            assert math.isclose((ticks[-1]-ticks[0])*period,s['frame_span_ns'],abs_tol=1)
            assert math.isclose(sum((ticks[i+1]-ticks[i])*period for i in range(0,len(ticks),2)),s['own_pass_sum_ns'],abs_tol=1)
        result['gpu_frame_ms']=quantiles([s['frame_span_ns']/1e6 for s in samples])
        result['gpu_pass_ms']={name:quantiles([v/1e6 for s in samples for n,v in s['passes_ns'] if n==name]) for name in sorted({n for s in samples for n,v in s['passes_ns']})}
        result['gpu_frame_limit_pass']=result['gpu_frame_ms']['p95']<=4 and result['gpu_frame_ms']['p99']<=8
        assert r['pointer_receipts']['all_changed_received'];result['pointer_receipts']=r['pointer_receipts']
        result['drm_endpoint_deltas']=drm_delta(a['drm_clients'],b['drm_clients'],elapsed)
        result['gpu_scope']=r['gpu_sample_scope']
    results.append(result)
summary={'candidate':declaration['candidate'],'trials':results,'qualification_pass':False,
         'quiet_cpu_passes':sum(r.get('cpu_limit_pass',False) for r in results),
         'gpu_frame_passes':sum(r.get('gpu_frame_limit_pass',False) for r in results),
         'fixed_files_unchanged':True,'all_six_native_runs_normal_exact_output':True,
         'limits':['Quiet runs lack semantic per-action acknowledgments and full work-count attribution.',
                   'GPU mode enables timestamps and verbose input receipts; its CPU values are not quiet CPU qualification.',
                   'GPU sample scope includes completion records through final drain; no display latency or exclusive shader attribution.',
                   'DRM samples cover matched endpoint clients only; no complete client lifecycle or observer overhead certification.',
                   'Historical pre-change measurements are unpaired; no formal relative-effect claim. Clamp failures carried forward without rerun.',
                   'No full backend/scale/resource/endurance/independent or owner acceptance.']}
(root/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'quiet_cpu':[r['cpu_percent_one_core'] for r in results if r['mode']=='quiet'],
                  'gpu_p95_p99':[[r['gpu_frame_ms']['p95'],r['gpu_frame_ms']['p99']] for r in results if r['mode']=='gpu'],
                  'quiet_cpu_passes':summary['quiet_cpu_passes'],'gpu_frame_passes':summary['gpu_frame_passes']}))
