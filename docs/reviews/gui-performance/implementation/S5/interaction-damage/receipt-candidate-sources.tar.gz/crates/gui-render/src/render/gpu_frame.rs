//! Full-frame GPU encoding and submission; resource lifetime lives on Renderer.
use super::*;
#[path = "gpu_frame_target.rs"]
pub(crate) mod target;

#[path = "composition_revision.rs"]
pub(crate) mod composition_revision;

#[path = "interaction_damage.rs"]
pub(crate) mod interaction_damage;

#[path = "preserved_interaction.rs"]
pub(crate) mod preserved_interaction;

#[path = "clipped_pass.rs"]
pub(crate) mod clipped_pass;

#[path = "damage_reset.rs"]
pub(crate) mod damage_reset;

impl Renderer {
    #[allow(clippy::too_many_arguments)]
    pub(super) fn render_submission_inner(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        target: &mut dyn target::Target,
        prepared: &PreparedScene,
        retained: &RetainedScene,
        schematic_retained: Option<&RetainedScene>,
        width: u32,
        height: u32,
    ) -> anyhow::Result<bool> {
        self.damage_regions = 0;
        let previous_composition = self.preserved_interaction.take();
        let world_unchanged =
            self.world_upload_sources_match(prepared, retained, schematic_retained);
        if self.resume_glyph_upload(device, queue, &mut |submission| {
            target.submitted(submission)
        })? {
            return Ok(false);
        }
        if self.cold_world.active
            && self.world_upload_sources_match(prepared, retained, schematic_retained)
        {
            self.submit_world_upload_chunk(device, queue, &mut |submission| {
                target.submitted(submission)
            })?;
            return Ok(false);
        }
        self.cold_world.active = false;
        // Encodings of replaced CPU geometry are no longer reusable. Retire
        // their CPU holds before admission; actual submissions keep their own.
        if !self.world_upload_sources_match(prepared, retained, schematic_retained) {
            self.surface_world_bundles.clear();
        }
        self.cancel_vertex_uploads();
        self.cancel_uniform_uploads();
        if prepared.is_overlay_only() {
            return self.render_overlay_only(device, queue, target, prepared, width, height);
        }
        self.prepare_world_pipelines(device);
        let render_started = std::time::Instant::now();
        let panel_vertices = prepared.panel_vertices();
        let viewport_underlay_vertices = prepared.viewport_underlay_vertices();
        let viewport_overlay_vertices = prepared.viewport_overlay_vertices();
        let board_interaction_vertices = prepared.board_interaction_vertices();
        let console_overlay_vertices = prepared.console_overlay_vertices();
        let menu_overlay_vertices = prepared.menu_overlay_vertices();
        let world_vertices = prepared
            .requires_board_world()
            .then_some(&retained.world_vertices);
        let world_strokes = retained.world_strokes();
        let schematic_pass = gpu_surface_pass::prepare_schematic_pass(prepared, schematic_retained);
        // S4 grid and interaction overlays remain immediate screen-space geometry;
        // offscreen captures supply neither cursor nor hover quads.
        let schematic_underlay_vertices = prepared.schematic_underlay_vertices();
        let schematic_overlay_vertices = prepared.schematic_overlay_vertices();
        self.surface_grids
            .prepare(prepared.surface_passes(), &self.atlas.staging_budget)?;
        self.observe_surface_grids()?;
        self.prepare_surface_uniforms(device, queue, prepared, width, height)?;
        self.uniform_buffer.sync(
            queue,
            ScreenUniform {
                resolution: [width as f32, height as f32],
                _pad: [0.0, 0.0],
            },
        );
        let upload_started = std::time::Instant::now();
        self.upload_frame_vertices(
            device,
            queue,
            panel_vertices,
            viewport_underlay_vertices,
            viewport_overlay_vertices,
            board_interaction_vertices,
            console_overlay_vertices,
            menu_overlay_vertices,
            world_vertices,
            schematic_pass.as_ref().map(|(_, _, _, scene)| *scene),
            schematic_underlay_vertices,
            schematic_overlay_vertices,
        )?;
        self.surface_grid_gpu.sync(
            device,
            queue,
            "datum-surface-grid-vertex-buffer",
            &self.surface_grids.vertices,
        )?;
        if world_vertices.is_some() {
            self.world_strokes_gpu
                .sync(device, queue, "datum-world-strokes", world_strokes)?;
        }
        if let Some((_, _, _, scene)) = schematic_pass.as_ref() {
            self.schematic_world_strokes_gpu.sync(
                device,
                queue,
                "datum-schematic-world-strokes",
                scene.world_strokes(),
            )?;
        }
        if self.pending_world_upload_bytes() != 0 {
            self.submit_world_upload_chunk(device, queue, &mut |submission| {
                target.submitted(submission)
            })?;
            return Ok(false);
        }
        self.sync_terminal_graphics(device, queue, prepared, width, height)?;
        if self.submit_terminal_upload_chunk(device, queue, &mut |submission| {
            target.submitted(submission)
        })? {
            return Ok(false);
        }
        let upload_elapsed = upload_started.elapsed();
        let text_prepare_started = std::time::Instant::now();
        let on_submitted = &mut |submission| target.submitted(submission);
        let Some((text_cache_stats, skipped_text_prepare)) =
            self.prepare_text_uploads(device, queue, prepared, width, height, false, on_submitted)?
        else {
            return Ok(false);
        };
        let text_prepare_elapsed = text_prepare_started.elapsed();
        let Some(view) = target.acquire()? else {
            return Ok(false);
        };
        let mut measurement = self.begin_gpu_measurement()?;
        let encode_started = std::time::Instant::now();
        let msaa_view = self.ensure_msaa(device, width, height)?.clone();
        let (next_composition, regions, partial) = self.prepare_interaction_damage(
            device,
            prepared,
            schematic_pass.is_some(),
            world_unchanged,
            previous_composition,
            width,
            height,
        );
        self.publish_resource_consumers();
        self.prepare_surface_world_bundles(device, prepared, schematic_retained);
        // Every layer loads the same preserved MSAA samples. Nothing reads the
        // resolved target until submission, so only the last active layer needs
        // to resolve it. Keep physical passes and painter order unchanged.
        let final_resolve = if !menu_overlay_vertices.is_empty() {
            if prepared.has_overlay_text() {
                ResolvePass::MenuText
            } else {
                ResolvePass::MenuBackground
            }
        } else if self.terminal_graphics.has_layer(true) {
            ResolvePass::TerminalForeground
        } else if prepared.has_workspace_text() {
            ResolvePass::Text
        } else if self.terminal_graphics.has_layer(false) {
            ResolvePass::TerminalBackground
        } else {
            ResolvePass::Scene
        };
        let mut encoder = device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("datum-gui-render-encoder"),
        });
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("datum-gui-render-pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &msaa_view,
                    resolve_target: (final_resolve == ResolvePass::Scene).then_some(&view),
                    depth_slice: None,
                    ops: wgpu::Operations {
                        load: if partial {
                            wgpu::LoadOp::Load
                        } else {
                            wgpu::LoadOp::Clear(wgpu::Color {
                                r: APP_BG[0] as f64,
                                g: APP_BG[1] as f64,
                                b: APP_BG[2] as f64,
                                a: 1.0,
                            })
                        },
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                occlusion_query_set: None,
                timestamp_writes: measurement.as_mut().map(|m| m.pass("scene")).transpose()?,
                multiview_mask: None,
            });
            for (region_index, region) in regions.as_slice().iter().enumerate() {
                let mut pass = clipped_pass::ClippedPass::new(&mut pass, *region, region_index);
                if partial {
                    pass.set_pipeline(self.damage_reset.get().expect("partial reset prepared"));
                    pass.draw(0..3, 0..1);
                }
                pass.set_pipeline(&self.pipeline);
                pass.set_bind_group(0, &self.uniform_bind_group, &[]);
                if !panel_vertices.is_empty() {
                    pass.set_vertex_buffer(
                        0,
                        self.panel_gpu
                            .buffer()
                            .expect("panel vertex buffer should exist")
                            .slice(..),
                    );
                    pass.draw(0..panel_vertices.len() as u32, 0..1);
                    self.observe_screen_draw_clipped(
                        immediate_admission::screen_admission::ScreenGroup::Panel,
                        panel_vertices.len() as u32,
                        pass.current_scissor(),
                    );
                }
                if prepared.surface_passes().is_empty() && !viewport_underlay_vertices.is_empty() {
                    pass.set_scissor_rect(
                        prepared.scene_viewport.x.max(0.0).floor() as u32,
                        prepared.scene_viewport.y.max(0.0).floor() as u32,
                        prepared.scene_viewport.width.max(1.0).ceil() as u32,
                        prepared.scene_viewport.height.max(1.0).ceil() as u32,
                    );
                    pass.set_vertex_buffer(
                        0,
                        self.viewport_underlay_gpu
                            .buffer()
                            .expect("viewport underlay vertex buffer should exist")
                            .slice(..),
                    );
                    pass.draw(0..viewport_underlay_vertices.len() as u32, 0..1);
                    self.observe_screen_draw_clipped(
                        immediate_admission::screen_admission::ScreenGroup::Underlay,
                        viewport_underlay_vertices.len() as u32,
                        pass.current_scissor(),
                    );
                }
                if !partial
                    && !prepared.surface_passes().is_empty()
                    && let Some(m) = &mut measurement
                {
                    m.mark_scene(&mut pass, 0)?;
                }
                self.draw_surface_grids(&mut pass, &self.surface_grids.batches);
                if !partial
                    && !prepared.surface_passes().is_empty()
                    && let Some(m) = &mut measurement
                {
                    m.mark_scene(&mut pass, 1)?;
                }
                self.draw_surface_world_passes(&mut pass, prepared);
                if !partial
                    && !prepared.surface_passes().is_empty()
                    && let Some(m) = &mut measurement
                {
                    m.mark_scene(&mut pass, 2)?;
                }
                pass.set_pipeline(&self.pipeline);
                pass.set_bind_group(0, &self.uniform_bind_group, &[]);
                if prepared.surface_passes().is_empty() {
                    for command in prepared.visible_draw_commands() {
                        match command {
                            RetainedDrawCommand::Quads { range, .. } => {
                                let Some(buffer) = self.world_vertices_gpu.buffer() else {
                                    continue;
                                };
                                pass.set_pipeline(
                                    &self
                                        .world_pipelines
                                        .get()
                                        .expect("general pipelines prepared")
                                        .quads,
                                );
                                pass.set_bind_group(0, &self.scene_bind_group.bind_group, &[]);
                                pass.set_scissor_rect(
                                    prepared.scene_viewport.x.max(0.0).floor() as u32,
                                    prepared.scene_viewport.y.max(0.0).floor() as u32,
                                    prepared.scene_viewport.width.max(1.0).ceil() as u32,
                                    prepared.scene_viewport.height.max(1.0).ceil() as u32,
                                );
                                pass.set_vertex_buffer(0, buffer.slice(..));
                                pass.draw(range.clone(), 0..1);
                            }
                            RetainedDrawCommand::Strokes { range, .. } => {
                                let Some(buffer) = self.world_strokes_gpu.buffer() else {
                                    continue;
                                };
                                draw_world_strokes(
                                    &mut pass,
                                    &self
                                        .world_pipelines
                                        .get()
                                        .expect("general pipelines prepared")
                                        .strokes,
                                    &self.scene_bind_group.bind_group,
                                    buffer,
                                    prepared.scene_viewport,
                                    std::slice::from_ref(range),
                                );
                            }
                        }
                    }
                    pass.set_pipeline(&self.pipeline);
                    pass.set_bind_group(0, &self.uniform_bind_group, &[]);
                }
                // Keep the schematic grid screen-space so zoom cannot thicken it.
                if prepared.surface_passes().is_empty()
                    && !schematic_underlay_vertices.is_empty()
                    && let Some((scene_viewport, _, _, _)) = schematic_pass.as_ref()
                    && let Some(buffer) = self.schematic_underlay_gpu.buffer()
                {
                    pass.set_scissor_rect(
                        scene_viewport.x.max(0.0).floor() as u32,
                        scene_viewport.y.max(0.0).floor() as u32,
                        scene_viewport.width.max(1.0).ceil() as u32,
                        scene_viewport.height.max(1.0).ceil() as u32,
                    );
                    pass.set_vertex_buffer(0, buffer.slice(..));
                    pass.draw(0..schematic_underlay_vertices.len() as u32, 0..1);
                    self.observe_screen_draw_clipped(
                        immediate_admission::screen_admission::ScreenGroup::SchematicUnderlay,
                        schematic_underlay_vertices.len() as u32,
                        pass.current_scissor(),
                    );
                }
                // The companion pass uses its own camera uniforms and pane scissor.
                if prepared.surface_passes().is_empty()
                    && let Some((scene_viewport, _, _, sr)) = schematic_pass.as_ref()
                {
                    for command in sr.all_draw_commands() {
                        match command {
                            RetainedDrawCommand::Quads { range, .. } => {
                                let Some(buffer) = self.schematic_world_vertices_gpu.buffer()
                                else {
                                    continue;
                                };
                                pass.set_pipeline(
                                    &self
                                        .world_pipelines
                                        .get()
                                        .expect("general pipelines prepared")
                                        .quads,
                                );
                                pass.set_bind_group(
                                    0,
                                    &self.schematic_scene_bind_group.bind_group,
                                    &[],
                                );
                                pass.set_scissor_rect(
                                    scene_viewport.x.max(0.0).floor() as u32,
                                    scene_viewport.y.max(0.0).floor() as u32,
                                    scene_viewport.width.max(1.0).ceil() as u32,
                                    scene_viewport.height.max(1.0).ceil() as u32,
                                );
                                pass.set_vertex_buffer(0, buffer.slice(..));
                                pass.draw(range.clone(), 0..1);
                            }
                            RetainedDrawCommand::Strokes { range, .. } => {
                                let Some(buffer) = self.schematic_world_strokes_gpu.buffer() else {
                                    continue;
                                };
                                draw_world_strokes(
                                    &mut pass,
                                    &self
                                        .world_pipelines
                                        .get()
                                        .expect("general pipelines prepared")
                                        .strokes,
                                    &self.schematic_scene_bind_group.bind_group,
                                    buffer,
                                    *scene_viewport,
                                    std::slice::from_ref(range),
                                );
                            }
                        }
                    }
                    pass.set_pipeline(&self.pipeline);
                    pass.set_bind_group(0, &self.uniform_bind_group, &[]);
                }
                // Interaction chrome stays above schematic world geometry.
                if !schematic_overlay_vertices.is_empty()
                    && let Some(scene_viewport) =
                        prepared.interaction_viewport(SceneSurface::Schematic)
                    && let Some(buffer) = self.schematic_overlay_gpu.buffer()
                {
                    pass.set_scissor_rect(
                        scene_viewport.x.max(0.0).floor() as u32,
                        scene_viewport.y.max(0.0).floor() as u32,
                        scene_viewport.width.max(1.0).ceil() as u32,
                        scene_viewport.height.max(1.0).ceil() as u32,
                    );
                    pass.set_vertex_buffer(0, buffer.slice(..));
                    pass.draw(0..schematic_overlay_vertices.len() as u32, 0..1);
                    self.observe_screen_draw_clipped(
                        immediate_admission::screen_admission::ScreenGroup::SchematicOverlay,
                        schematic_overlay_vertices.len() as u32,
                        pass.current_scissor(),
                    );
                }
                if !viewport_overlay_vertices.is_empty() {
                    pass.set_scissor_rect(
                        prepared.scene_viewport.x.max(0.0).floor() as u32,
                        prepared.scene_viewport.y.max(0.0).floor() as u32,
                        prepared.scene_viewport.width.max(1.0).ceil() as u32,
                        prepared.scene_viewport.height.max(1.0).ceil() as u32,
                    );
                    pass.set_vertex_buffer(
                        0,
                        self.viewport_overlay_gpu
                            .buffer()
                            .expect("viewport overlay vertex buffer should exist")
                            .slice(..),
                    );
                    pass.draw(0..viewport_overlay_vertices.len() as u32, 0..1);
                    self.observe_screen_draw_clipped(
                        immediate_admission::screen_admission::ScreenGroup::Overlay,
                        viewport_overlay_vertices.len() as u32,
                        pass.current_scissor(),
                    );
                }
                if !board_interaction_vertices.is_empty() {
                    let interaction_viewport = prepared
                        .interaction_viewport(SceneSurface::Board)
                        .unwrap_or(prepared.scene_viewport);
                    pass.set_scissor_rect(
                        interaction_viewport.x.max(0.0).floor() as u32,
                        interaction_viewport.y.max(0.0).floor() as u32,
                        interaction_viewport.width.max(1.0).ceil() as u32,
                        interaction_viewport.height.max(1.0).ceil() as u32,
                    );
                    pass.set_vertex_buffer(
                        0,
                        self.board_interaction_gpu
                            .buffer()
                            .expect("board interaction vertex buffer should exist")
                            .slice(..),
                    );
                    pass.draw(0..board_interaction_vertices.len() as u32, 0..1);
                    self.observe_screen_draw_clipped(
                        immediate_admission::screen_admission::ScreenGroup::BoardInteraction,
                        board_interaction_vertices.len() as u32,
                        pass.current_scissor(),
                    );
                }
                self.draw_console(&mut pass, console_overlay_vertices, prepared);
                // NOTE: the menu dropdown card is intentionally NOT drawn here. It is
                // composited AFTER the main text pass (below) so it occludes not only
                // the work-pane quads but every underlying text_run too; its own text
                // then draws in a final pass on top of the card.
            }
        }
        self.encode_terminal_graphics(
            &mut encoder,
            &msaa_view,
            (final_resolve == ResolvePass::TerminalBackground).then_some(&view),
            false,
            measurement.as_mut(),
            regions.as_slice(),
        )?;
        let encode_elapsed = encode_started.elapsed();
        let text_encode_started = std::time::Instant::now();
        // Empty text does not introduce a physical pass; the preceding or
        // following active layer owns the single final resolve.
        if prepared.has_workspace_text() {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("datum-gui-text-pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &msaa_view,
                    resolve_target: (final_resolve == ResolvePass::Text).then_some(&view),
                    depth_slice: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Load,
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                occlusion_query_set: None,
                timestamp_writes: measurement.as_mut().map(|m| m.pass("text")).transpose()?,
                multiview_mask: None,
            });
            for region in regions.as_slice() {
                region.set(&mut pass);
                self.text_renderer
                    .render(&self.atlas, &mut pass)
                    .map_err(|error| anyhow::anyhow!("render GUI text: {error}"))?;
            }
        }
        let text_encode_elapsed = text_encode_started.elapsed();

        self.encode_terminal_graphics(
            &mut encoder,
            &msaa_view,
            (final_resolve == ResolvePass::TerminalForeground).then_some(&view),
            true,
            measurement.as_mut(),
            regions.as_slice(),
        )?;

        // Composite the menu card and its text after the main text pass.
        if !menu_overlay_vertices.is_empty() {
            // Pass C: the dropdown card background/rows. Base pipeline + screen
            // uniform; full-window scissor so the drop below the menu bar is not
            // re-clipped to the scene viewport.
            {
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: Some("datum-gui-menu-overlay-pass"),
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &msaa_view,
                        resolve_target: (final_resolve == ResolvePass::MenuBackground)
                            .then_some(&view),
                        depth_slice: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Load,
                            store: wgpu::StoreOp::Store,
                        },
                    })],
                    depth_stencil_attachment: None,
                    occlusion_query_set: None,
                    timestamp_writes: measurement
                        .as_mut()
                        .map(|m| m.pass("menu-background"))
                        .transpose()?,
                    multiview_mask: None,
                });
                for (region_index, region) in regions.as_slice().iter().enumerate() {
                    let mut pass = clipped_pass::ClippedPass::new(&mut pass, *region, region_index);
                    pass.set_pipeline(&self.pipeline);
                    pass.set_bind_group(0, &self.uniform_bind_group, &[]);
                    pass.set_scissor_rect(0, 0, width, height);
                    pass.set_vertex_buffer(
                        0,
                        self.menu_overlay_gpu
                            .buffer()
                            .expect("menu overlay vertex buffer should exist")
                            .slice(..),
                    );
                    pass.draw(0..menu_overlay_vertices.len() as u32, 0..1);
                    self.observe_screen_draw_clipped(
                        immediate_admission::screen_admission::ScreenGroup::Menu,
                        menu_overlay_vertices.len() as u32,
                        pass.current_scissor(),
                    );
                }
            }

            // Pass D: the dropdown's own text, on top of the card. Uses the
            // dedicated overlay text renderer so the main renderer's prepared
            // state/caching is untouched. The content-keyed text_buffer_cache is
            // shared, so overlay glyph buffers reuse the same atlas.
            if prepared.has_overlay_text() {
                {
                    let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                        label: Some("datum-gui-menu-overlay-text-pass"),
                        color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                            view: &msaa_view,
                            resolve_target: (final_resolve == ResolvePass::MenuText)
                                .then_some(&view),
                            depth_slice: None,
                            ops: wgpu::Operations {
                                load: wgpu::LoadOp::Load,
                                store: wgpu::StoreOp::Store,
                            },
                        })],
                        depth_stencil_attachment: None,
                        occlusion_query_set: None,
                        timestamp_writes: measurement
                            .as_mut()
                            .map(|m| m.pass("menu-text"))
                            .transpose()?,
                        multiview_mask: None,
                    });
                    for region in regions.as_slice() {
                        region.set(&mut pass);
                        self.menu_overlay_text_renderer
                            .render(&self.atlas, &mut pass)
                            .map_err(|error| {
                                anyhow::anyhow!("render menu overlay text: {error}")
                            })?;
                    }
                }
            }
        }

        let trace_enabled = std::env::var_os("DATUM_TRACE_TIMING").is_some();
        let finish_started = trace_enabled.then(std::time::Instant::now);
        self.resolve_gpu_measurement(&mut measurement, &mut encoder)?;
        let command_buffer = encoder.finish();
        let finish_elapsed = finish_started.map(|started| started.elapsed());
        let submit_started = std::time::Instant::now();
        let mut uploads = self.flush_frame_uploads(device, queue)?;
        let submission = queue.submit(
            uploads
                .as_mut()
                .map(|batch| batch.command())
                .into_iter()
                .chain([command_buffer]),
        );
        self.hold_frame_submission(queue);
        if let Some(batch) = uploads {
            batch.hold(queue);
        }
        target.submitted(submission);
        self.text_buffers.finish_frame();
        self.submit_gpu_measurement(queue, measurement)?;
        let submit_elapsed = submit_started.elapsed();
        if let Some(finish_elapsed) = finish_elapsed {
            trace_render_timing(format!(
                "renderer total={}ms upload={}ms encode={}ms text_prepare={}ms text_encode={}ms submit={}ms finish_us={} submit_us={} vertices panel={} underlay={} world={} overlay={} text_runs={} text_cache={}/{} text_prepare_skipped={}",
                render_started.elapsed().as_millis(),
                upload_elapsed.as_millis(),
                encode_elapsed.as_millis(),
                text_prepare_elapsed.as_millis(),
                text_encode_elapsed.as_millis(),
                submit_elapsed.as_millis(),
                finish_elapsed.as_micros(),
                submit_elapsed.as_micros(),
                panel_vertices.len(),
                viewport_underlay_vertices.len(),
                world_vertices.map_or(0, |vertices| vertices.len()),
                viewport_overlay_vertices.len(),
                prepared.text_runs.len(),
                text_cache_stats.hits,
                text_cache_stats.misses,
                skipped_text_prepare,
            ));
        }
        self.preserved_interaction = next_composition;
        Ok(true)
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ResolvePass {
    Scene,
    TerminalBackground,
    Text,
    TerminalForeground,
    MenuBackground,
    MenuText,
}
